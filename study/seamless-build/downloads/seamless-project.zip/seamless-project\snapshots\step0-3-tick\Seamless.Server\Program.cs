// ── STEP 0 · 삽 3 — 틱(심장): 세상이 '스스로' 흐른다. + 게임 로직을 '한 스레드'로 모아 동시성 정리. ──
//    구조: 네트워크(async, 여러 스레드)는 받은 걸 '큐'에 넣기만 → 틱 루프(한 스레드)가 꺼내 처리.
//    그래서 world/conns는 '틱 스레드 혼자'만 만짐 → 평범한 Dictionary로 충분 (ConcurrentDictionary·락 불필요!)

using System.Collections.Concurrent;   // ConcurrentQueue — 네트워크→틱 사이 '유일한' 스레드 안전 지점
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int Port = 9001;
const int TickMs = 500;   // 데모라 느리게(초당 2번). 진짜 게임은 60~100ms.

var inbox = new ConcurrentQueue<GameCmd>();             // 네트워크 스레드들이 '할 일'을 넣는 곳
var world = new Dictionary<int, (float X, float Y)>();  // 플레이어 위치 — 틱 스레드 전용 (평범한 Dictionary!)
var conns = new Dictionary<int, ClientConn>();          // 접속들 — 틱 스레드 전용

var listener = new TcpListener(IPAddress.Loopback, Port);
listener.Start();
Console.WriteLine($"[S0] listen :{Port}, tick {TickMs}ms");

// 접속 받기: 이 루프는 world/conns를 '직접 안 만지고' inbox에 Join만 넣는다.
int nextId = 1;
_ = Task.Run(async () =>
{
    while (true)
    {
        var tcp = await listener.AcceptTcpClientAsync();
        var conn = new ClientConn(nextId++, tcp);
        inbox.Enqueue(new GameCmd(CmdKind.Join, conn.PlayerId, conn, 0, 0));  // "얘 들어옴"을 틱에게 알림
        _ = RecvLoopAsync(conn, inbox);                                       // 얘의 수신 루프 시작
    }
});

// ★ 틱 루프 = 심장. 여기가 '단일 스레드 게임 로직' (당신 회사 서버의 그 구조).
long tick = 0;
while (true)
{
    tick++;

    // 1) 그동안 쌓인 할 일을 전부 꺼내 처리 (여기선 나 혼자라 락이 필요 없다)
    while (inbox.TryDequeue(out var cmd))
    {
        if (cmd.Kind == CmdKind.Join)
        {
            conns[cmd.PlayerId] = cmd.Conn!;
            world[cmd.PlayerId] = (0, 0);
            Console.WriteLine($"[S0] +P{cmd.PlayerId} 입장 ({conns.Count}명)");
        }
        else if (cmd.Kind == CmdKind.Move && world.ContainsKey(cmd.PlayerId))
        {
            world[cmd.PlayerId] = (cmd.X, cmd.Y);
            Console.WriteLine($"[S0] P{cmd.PlayerId} → ({cmd.X},{cmd.Y}) 적용");
        }
        else if (cmd.Kind == CmdKind.Leave)
        {
            conns.Remove(cmd.PlayerId);
            world.Remove(cmd.PlayerId);
            Console.WriteLine($"[S0] -P{cmd.PlayerId} 퇴장 ({conns.Count}명)");
        }
    }

    // 2) 현재 월드 상태를 방송 (틱 스레드 혼자 보내니 SemaphoreSlim도 필요 없다)
    foreach (var (id, pos) in world)
    {
        var sm = Codec.Serialize(new SM_MOVE(id, pos.X, pos.Y, 0));
        foreach (var c in conns.Values)
            if (c.PlayerId != id)                                    // 본인에겐 본인 위치 안 보냄
                try { await c.SendAsync(PacketType.SM_MOVE, sm); } catch { /* 그새 끊긴 클라 무시 */ }
    }

    Console.WriteLine($"[S0] tick #{tick} | {conns.Count}명");       // 심장박동: 아무도 안 움직여도 계속 뛴다
    await Task.Delay(TickMs);                                        // 다음 틱까지 쉼
}

// 네트워크 수신: world를 '직접 안 만지고' 받은 이동을 inbox에 넣기만 한다.
static async Task RecvLoopAsync(ClientConn conn, ConcurrentQueue<GameCmd> inbox)
{
    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(conn.Stream);
            if (type == PacketType.CM_MOVE)
            {
                var m = Codec.Deserialize<CM_MOVE>(data);
                inbox.Enqueue(new GameCmd(CmdKind.Move, conn.PlayerId, null, m.X, m.Y));  // 틱에게 넘김
            }
        }
    }
    catch { /* 연결 끊김 등 */ }
    finally { inbox.Enqueue(new GameCmd(CmdKind.Leave, conn.PlayerId, null, 0, 0)); conn.Dispose(); }
}

// 틱에게 넘기는 '할 일' 한 건. (누가 들어왔다/움직였다/나갔다)
enum CmdKind { Join, Move, Leave }
readonly record struct GameCmd(CmdKind Kind, int PlayerId, ClientConn? Conn, float X, float Y);

// 한 클라 연결. 이제 보내기는 틱 혼자 하므로 락(SemaphoreSlim)이 없다.
sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    public ClientConn(int id, TcpClient tcp) { PlayerId = id; _tcp = tcp; Stream = tcp.GetStream(); }
    public Task SendAsync(PacketType t, byte[] d) => Framing.SendFramedAsync(Stream, t, d);
    public void Dispose() => _tcp.Dispose();
}
