// ── STEP 5 게이트 — STEP 4 히스테리시스 그대로, 단 '모든 패킷'을 백엔드로 전달한다. ──
//    STEP 2/4 게이트는 CM_MOVE만 다뤘다. STEP 5는 CM_ATTACK(공격)도 백엔드로 보내야 라우팅이 시작된다.
//    그래서 send를 CM_MOVE 판정 블록 '바깥'에 둔다 → 이동이든 공격이든 현재 담당 서버로 그대로 전달.

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, GatePort = 9000, ZonePort0 = 9001;
int H = args.Length > 0 ? int.Parse(args[0]) : 2;   // 히스테리시스 폭 (0이면 없음)
int ZoneOf(float x, float y) => ((int)y / CellSize) * Cols + ((int)x / CellSize);

int NextZone(int cur, float x, float y)
{
    int nz = ZoneOf(x, y);
    if (nz == cur) return cur;
    int cc = cur % Cols, cr = cur / Cols, nc = nz % Cols, nr = nz / Cols;
    if (nr == cr) { if (nc == cc + 1) return x >= (cc + 1) * CellSize + H ? nz : cur; if (nc == cc - 1) return x <= cc * CellSize - H ? nz : cur; }
    if (nc == cc) { if (nr == cr + 1) return y >= (cr + 1) * CellSize + H ? nz : cur; if (nr == cr - 1) return y <= cr * CellSize - H ? nz : cur; }
    return nz;
}

var listener = new TcpListener(IPAddress.Loopback, GatePort);
listener.Start();
Console.WriteLine($"[GATE] listen :{GatePort}  히스테리시스 H={H} · 모든 패킷(이동·공격) 전달");

int nextId = 1;
while (true)
{
    var client = await listener.AcceptTcpClientAsync();
    int cid = nextId++;
    _ = HandleClientAsync(client, cid, NextZone, ZonePort0);
}

static async Task HandleClientAsync(TcpClient client, int cid, Func<int, float, float, int> NextZone, int zonePort0)
{
    NetworkStream cli = client.GetStream();
    int zone = 0, switches = 0;
    TcpClient backend = await ConnectBackend(zonePort0 + zone);
    var downCts = new CancellationTokenSource();
    _ = Pump(backend.GetStream(), cli, downCts.Token);
    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(cli);
            if (type == PacketType.CM_MOVE)
            {
                var m = Codec.Deserialize<CM_MOVE>(data);
                int nz = NextZone(zone, m.X, m.Y);
                if (nz != zone)
                {
                    switches++;
                    Console.WriteLine($"[GATE] C{cid} 이주! zone {zone} → {nz} (위치 {m.X:0.0},{m.Y:0.0})  [누적 교체 {switches}회]");
                    downCts.Cancel(); backend.Dispose();
                    zone = nz;
                    backend = await ConnectBackend(zonePort0 + zone);
                    downCts = new CancellationTokenSource();
                    _ = Pump(backend.GetStream(), cli, downCts.Token);
                }
            }
            await Framing.SendFramedAsync(backend.GetStream(), type, data);   // ★ 모든 패킷(이동·공격…)을 현재 백엔드로 전달
        }
    }
    catch { }
    finally { downCts.Cancel(); backend.Dispose(); client.Dispose(); Console.WriteLine($"[GATE] C{cid} 종료 — 총 백엔드 교체 {switches}회"); }
}

static async Task Pump(NetworkStream from, NetworkStream to, CancellationToken ct)
{
    try { while (!ct.IsCancellationRequested) { var (t, d) = await Framing.ReadFramedAsync(from, ct); await Framing.SendFramedAsync(to, t, d, ct); } } catch { }
}
static async Task<TcpClient> ConnectBackend(int port)
{
    for (int a = 1; ; a++) { var c = new TcpClient(); try { await c.ConnectAsync(IPAddress.Loopback, port); return c; } catch (SocketException) when (a < 30) { c.Dispose(); await Task.Delay(150); } }
}
