@echo off
rem STEP 0: 서버 + 3D 뷰어(WASD/마우스로 조종) 함께 실행.
rem (서버가 이미 떠 있으면 두 번째 서버는 포트 충돌로 즉시 종료됨 — 무시)
cd /d "%~dp0"
start "SeamlessServer" dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll"
timeout /t 2 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
