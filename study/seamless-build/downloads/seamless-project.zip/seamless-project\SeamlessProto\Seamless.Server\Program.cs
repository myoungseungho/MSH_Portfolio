// ── STEP 5 · 위치 투명 라우팅 (★두 번째 마법) — 경계 너머를 때린다. ──
//    클라는 "저 대상(targetId)에게 데미지"만 보낸다. 어느 서버로 보낼지는 모른다.
//    받은 서버는 대상의 '주인'을 찾아(액터ID→주인 매핑) 자기면 판정, 아니면 주인 서버로 전달.
//    판정은 '주인'만 한다 → 데미지 로그는 주인 서버 콘솔에 뜬다. STEP 3 고스팅 위에 얹었다.

using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, ClientPort0 = 9001, PeerPort0 = 9101, TickMs = 500, N = 3;
int zoneIdx = args.Length > 0 ? int.Parse(args[0]) : 0;
int col = zoneIdx % Cols, row = zoneIdx / Cols;
float zx0 = col * CellSize, zy0 = row * CellSize;
int OwnerOf(int actorId) => actorId - 100;   // 몬스터 M10X 의 주인 = zone X (액터ID→주인 매핑)

var neighbors = new List<int>();
if (col > 0) neighbors.Add(zoneIdx - 1);
if (col < Cols - 1) neighbors.Add(zoneIdx + 1);
if (row > 0) neighbors.Add(zoneIdx - Cols);
if (row < Cols - 1) neighbors.Add(zoneIdx + Cols);

var inbox = new ConcurrentQueue<GameCmd>();
var ghostInbox = new ConcurrentQueue<Ghost>();
var killInbox = new ConcurrentQueue<int>();
var peerOut = new ConcurrentDictionary<int, NetworkStream>();
var world = new Dictionary<int, (float X, float Y)>();
var conns = new Dictionary<int, ClientConn>();
var monsters = new Dictionary<int, (float X, float Y, float VX, float VY, int HP)> { [100 + zoneIdx] = (zx0 + 5, zy0 + 5, 1, 0, 30) };
var ghosts = new Dictionary<int, (float X, float Y, int Src, long Tick)>();

bool NearBoundary(float x, float y, int nb)
{
    if (nb == zoneIdx + 1) return x >= zx0 + CellSize - N;
    if (nb == zoneIdx - 1) return x < zx0 + N;
    if (nb == zoneIdx + Cols) return y >= zy0 + CellSize - N;
    if (nb == zoneIdx - Cols) return y < zy0 + N;
    return false;
}

var listener = new TcpListener(IPAddress.Loopback, ClientPort0 + zoneIdx); listener.Start();
var peerListener = new TcpListener(IPAddress.Loopback, PeerPort0 + zoneIdx); peerListener.Start();
Console.WriteLine($"[Z{zoneIdx}] client:{ClientPort0 + zoneIdx} peer:{PeerPort0 + zoneIdx} 이웃={string.Join(",", neighbors)} 몬스터=M{100 + zoneIdx}(HP30)");

int nextId = 1;
_ = Task.Run(async () => { while (true) { var tcp = await listener.AcceptTcpClientAsync(); var conn = new ClientConn(zoneIdx * 100 + nextId++, tcp); inbox.Enqueue(new GameCmd(CmdKind.Join, conn.PlayerId, conn, 0, 0)); _ = ClientRecvAsync(conn, inbox); } });
_ = Task.Run(async () => { while (true) { var pc = await peerListener.AcceptTcpClientAsync(); _ = PeerRecvAsync(pc, ghostInbox, inbox, killInbox); } });
foreach (var nb in neighbors) _ = Task.Run(async () => { var s = await ConnectPeer(PeerPort0 + nb); peerOut[nb] = s; });

async Task Broadcast(PacketType t, byte[] d) { foreach (var c in conns.Values) try { await c.SendAsync(t, d); } catch { } }
async Task PushNeighbors(PacketType t, byte[] d) { foreach (var nb in neighbors) if (peerOut.TryGetValue(nb, out var ps)) try { await Framing.SendFramedAsync(ps, t, d); } catch { } }

long tick = 0;
while (true)
{
    tick++;
    while (inbox.TryDequeue(out var cmd))
    {
        if (cmd.Kind == CmdKind.Join) { conns[cmd.PlayerId] = cmd.Conn!; world[cmd.PlayerId] = (zx0 + 1, zy0 + 1); }
        else if (cmd.Kind == CmdKind.Move && world.ContainsKey(cmd.PlayerId)) world[cmd.PlayerId] = (cmd.X, cmd.Y);
        else if (cmd.Kind == CmdKind.Leave) { conns.Remove(cmd.PlayerId); world.Remove(cmd.PlayerId); }
        else if (cmd.Kind == CmdKind.Attack)
        {
            int target = cmd.PlayerId, owner = OwnerOf(target);
            if (owner == zoneIdx && monsters.TryGetValue(target, out var mo))
            {
                int hp = mo.HP - cmd.Damage;
                Console.WriteLine($"[Z{zoneIdx}] ← 데미지! M{target} HP {mo.HP}→{Math.Max(0, hp)}  (판정=주인 Z{zoneIdx})");
                if (hp <= 0) { monsters.Remove(target); Console.WriteLine($"[Z{zoneIdx}] 💥 M{target} 격추! (주인 Z{zoneIdx} 콘솔)"); var km = Codec.Serialize(new SM_MOVE(target, 0, 0, (byte)zoneIdx)); await Broadcast(PacketType.SM_KILL, km); await PushNeighbors(PacketType.SM_KILL, km); }
                else monsters[target] = (mo.X, mo.Y, mo.VX, mo.VY, hp);
            }
            else if (owner != zoneIdx && peerOut.TryGetValue(owner, out var ps))
            {
                Console.WriteLine($"[Z{zoneIdx}] 라우팅: M{target}은 Z{owner} 소유 → Z{owner}로 데미지 전달 (나는 판정 안 함)");
                try { await Framing.SendFramedAsync(ps, PacketType.CM_ATTACK, Codec.Serialize(new AttackMsg(target, cmd.Damage))); } catch { }
            }
        }
    }
    while (ghostInbox.TryDequeue(out var g)) ghosts[g.Id] = (g.X, g.Y, g.Src, tick);
    while (killInbox.TryDequeue(out var kid)) { ghosts.Remove(kid); monsters.Remove(kid); Console.WriteLine($"[Z{zoneIdx}] (전파받음) M{kid} 격추 → 내 클라에 알림"); await Broadcast(PacketType.SM_KILL, Codec.Serialize(new SM_MOVE(kid, 0, 0, (byte)zoneIdx))); }
    foreach (var k in ghosts.Where(kv => tick - kv.Value.Tick > 2).Select(kv => kv.Key).ToList()) ghosts.Remove(k);

    foreach (var id in monsters.Keys.ToList()) { var mo = monsters[id]; float vx = mo.VX, nx = mo.X + vx; if (nx < zx0 || nx >= zx0 + CellSize) { vx = -vx; nx = mo.X + vx; } monsters[id] = (nx, mo.Y, vx, mo.VY, mo.HP); }

    foreach (var nb in neighbors)
    {
        if (!peerOut.TryGetValue(nb, out var ps)) continue;
        foreach (var (id, mo) in monsters) if (NearBoundary(mo.X, mo.Y, nb)) try { await Framing.SendFramedAsync(ps, PacketType.SM_MOVE, Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, (byte)zoneIdx))); } catch { }
        foreach (var (id, p) in world) if (NearBoundary(p.X, p.Y, nb)) try { await Framing.SendFramedAsync(ps, PacketType.SM_MOVE, Codec.Serialize(new SM_MOVE(id, p.X, p.Y, (byte)zoneIdx))); } catch { }
    }

    foreach (var (id, pos) in world) { var sm = Codec.Serialize(new SM_MOVE(id, pos.X, pos.Y, (byte)zoneIdx)); foreach (var c in conns.Values) if (c.PlayerId != id) try { await c.SendAsync(PacketType.SM_MOVE, sm); } catch { } }
    foreach (var (id, mo) in monsters) { var sm = Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, (byte)zoneIdx)); await Broadcast(PacketType.SM_MONSTER, sm); }
    foreach (var (id, g) in ghosts) { var sm = Codec.Serialize(new SM_MOVE(id, g.X, g.Y, (byte)g.Src)); await Broadcast(PacketType.SM_GHOST, sm); }

    if (tick % 6 == 1) Console.WriteLine($"[Z{zoneIdx}] tick #{tick} | {conns.Count}명 | 몬스터 {monsters.Count} | 고스트 {ghosts.Count}");
    await Task.Delay(TickMs);
}

static async Task ClientRecvAsync(ClientConn conn, ConcurrentQueue<GameCmd> inbox)
{
    try { while (true) { var (type, data) = await Framing.ReadFramedAsync(conn.Stream);
        if (type == PacketType.CM_MOVE) { var m = Codec.Deserialize<CM_MOVE>(data); inbox.Enqueue(new GameCmd(CmdKind.Move, conn.PlayerId, null, m.X, m.Y)); }
        else if (type == PacketType.CM_ATTACK) { var a = Codec.Deserialize<AttackMsg>(data); inbox.Enqueue(new GameCmd(CmdKind.Attack, a.TargetId, null, 0, 0, a.Damage)); } } }
    catch { } finally { inbox.Enqueue(new GameCmd(CmdKind.Leave, conn.PlayerId, null, 0, 0)); conn.Dispose(); }
}
static async Task PeerRecvAsync(TcpClient pc, ConcurrentQueue<Ghost> gi, ConcurrentQueue<GameCmd> inbox, ConcurrentQueue<int> ki)
{
    try { using var s = pc.GetStream(); while (true) { var (type, d) = await Framing.ReadFramedAsync(s);
        if (type == PacketType.SM_MOVE) { var m = Codec.Deserialize<SM_MOVE>(d); gi.Enqueue(new Ghost(m.PlayerId, m.X, m.Y, m.AuthorityServerId)); }
        else if (type == PacketType.CM_ATTACK) { var a = Codec.Deserialize<AttackMsg>(d); inbox.Enqueue(new GameCmd(CmdKind.Attack, a.TargetId, null, 0, 0, a.Damage)); }
        else if (type == PacketType.SM_KILL) { var m = Codec.Deserialize<SM_MOVE>(d); ki.Enqueue(m.PlayerId); } } }
    catch { }
}
static async Task<NetworkStream> ConnectPeer(int port)
{
    for (int a = 1; ; a++) { var c = new TcpClient(); try { await c.ConnectAsync(IPAddress.Loopback, port); return c.GetStream(); } catch (SocketException) when (a < 40) { c.Dispose(); await Task.Delay(150); } }
}

enum CmdKind { Join, Move, Leave, Attack }
readonly record struct GameCmd(CmdKind Kind, int PlayerId, ClientConn? Conn, float X, float Y, int Damage = 0);
readonly record struct Ghost(int Id, float X, float Y, int Src);

sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    public ClientConn(int id, TcpClient tcp) { PlayerId = id; _tcp = tcp; Stream = tcp.GetStream(); }
    public Task SendAsync(PacketType t, byte[] d) => Framing.SendFramedAsync(Stream, t, d);
    public void Dispose() => _tcp.Dispose();
}
