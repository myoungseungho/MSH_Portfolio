// ── STEP 4 · 클라 — 경계(x=10) 근처에서 왔다갔다(9↔11) 반복한다.
//    히스테리시스 없으면 매번 백엔드가 갈아타는 '이주 폭풍'이, 있으면 잠잠해지는 걸 게이트 로그로 본다. ──

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int GatePort = 9000;

TcpClient client = new();
for (int a = 1; ; a++) { try { await client.ConnectAsync(IPAddress.Loopback, GatePort); break; } catch (SocketException) when (a < 30) { client.Dispose(); client = new(); await Task.Delay(150); } }
var stream = client.GetStream();
var cts = new CancellationTokenSource();
_ = RecvLoopAsync(stream, cts.Token);

// 경계(x=10)를 사이에 두고 9↔11 진동
float[] xs = { 9, 11, 9, 11, 9, 11, 9, 11 };
foreach (var x in xs)
{
    await Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(x, 5)));
    Console.WriteLine($"[C] → 위치 ({x},5)  (경계 근처 진동)");
    await Task.Delay(500);
}
cts.Cancel(); client.Dispose();
Console.WriteLine("[C] 끝 — 게이트 로그의 '교체 횟수'를 보라");

static async Task RecvLoopAsync(NetworkStream s, CancellationToken ct)
{
    try { while (!ct.IsCancellationRequested) { var (_, _) = await Framing.ReadFramedAsync(s, ct); } } catch { }
}
