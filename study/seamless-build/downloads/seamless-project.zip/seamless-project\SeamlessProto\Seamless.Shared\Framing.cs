// 이 파일은 "선(TCP) 위에서 편지 한 통의 경계를 어떻게 긋고, 종류를 어떻게 표시하나"를 담당한다.
//   TCP는 바이트가 끝없이 이어지는 물줄기라 '여기까지가 한 통'이라는 표시가 없다 → 우리가 [길이][타입]을 앞에 붙여 경계를 만든다.

using System.Buffers.Binary;   // 숫자를 '정해진 바이트 순서로' 쓰고 읽는 도구(BinaryPrimitives)
using System.Net.Sockets;      // 네트워크 연결 통로(NetworkStream)

namespace Seamless.Shared;

// static = 상태 없는 함수 모음. 서버든 클라든 방향 안 가리고 그냥 이름으로 가져다 쓴다.
public static class Framing
{
    // 편지 한 통을 [길이][타입][데이터] 모양으로 감싸 보낸다. async = 안에 '기다림(await)'이 있어 멈췄다 이어질 수 있다는 표시.
    public static async Task SendFramedAsync(NetworkStream s, PacketType type, byte[] data, CancellationToken ct = default)
    {
        int len = 1 + data.Length;   // 몸통 길이 = 타입 1바이트 + 데이터. 받는 쪽이 "여기까지가 한 통"임을 알 숫자.
        var head = new byte[5];      // 머리 5칸 준비: [길이 4칸] + [타입 1칸]
        BinaryPrimitives.WriteInt32LittleEndian(head.AsSpan(0), len);  // 머리 앞 4칸에 길이를 적는다 (바이트 순서를 리틀엔디안으로 고정)
        head[4] = (byte)type;        // 머리 5번째 칸에 종류번호를 적는다 (CM_MOVE → 1). (byte)로 enum을 그 숫자값으로 바꿈.
        await s.WriteAsync(head, ct);   // 머리 5바이트를 연결로 내보낸다. (속: OS 송신버퍼에 복사, 자리 없으면 날 때까지 기다림)
        await s.WriteAsync(data, ct);   // 이어서 몸통(데이터)을 내보낸다. 이제 선엔 [길이][타입][데이터] 순으로 흐른다.
    }

    // 편지 한 통을 온전히 읽어 (종류, 데이터)로 돌려준다. Task<(...)> = 끝나면 그 한 쌍을 주는 '진행 중인 일'.
    public static async Task<(PacketType type, byte[] data)> ReadFramedAsync(NetworkStream s, CancellationToken ct = default)
    {
        var lenBuf = await ReadExactlyAsync(s, 4, ct);            // 먼저 앞 4바이트(길이)만 '정확히' 읽는다
        int len = BinaryPrimitives.ReadInt32LittleEndian(lenBuf); // 그 4바이트를 다시 숫자로 해석 = 몸통 길이
        var body = await ReadExactlyAsync(s, len, ct);            // 그 길이만큼 '정확히' 더 읽는다 = [타입][데이터]를 통째로
        return ((PacketType)body[0], body[1..]);                 // 첫 바이트=종류, 나머지=데이터. 둘을 한 쌍(튜플)으로 돌려준다.
    }

    // "정확히 n바이트가 다 올 때까지 모으는" 도우미. private = 이 파일 안에서만 쓰는 내부용이라 밖에 안 보인다.
    //   왜 필요? TCP는 '요청한 만큼'이 아니라 '지금 도착한 만큼'만 준다 → 한 번에 안 오면 여러 번 받아 채워야 한다.
    private static async Task<byte[]> ReadExactlyAsync(NetworkStream s, int n, CancellationToken ct)
    {
        var buf = new byte[n];   // n칸짜리 받을 통
        int off = 0;             // 지금까지 채운 개수(0에서 시작)
        while (off < n)          // 아직 n개를 다 못 채웠으면 계속 반복
        {
            int read = await s.ReadAsync(buf.AsMemory(off, n - off), ct);  // 도착한 바이트를 off자리부터 담고, 이번에 몇 개 왔는지(read) 받는다
            if (read == 0) throw new IOException("연결이 끊겼습니다(0바이트)");  // 0개가 왔다 = 상대가 연결을 닫았다는 신호 → 예외로 중단
            off += read;         // 채운 만큼 자리(off)를 앞으로 민다
        }
        return buf;              // n개를 다 모았으면 통째로 돌려준다
    }
}
