// ── STEP 2 · 게이트(리버스 프록시) — 클라는 여기 1개에만 붙는다. ──
//    게이트가 클라의 위치를 보고 '뒤에 있는 존 서버'에 대신 연결한다.
//    클라가 칸 경계를 넘으면 게이트가 '뒤 연결만 몰래 교체' — 클라 연결은 그대로 유지된다(재접속 소멸).

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, GatePort = 9000, ZonePort0 = 9001;
int ZoneOf(float x, float y) => ((int)y / CellSize) * Cols + ((int)x / CellSize);

var listener = new TcpListener(IPAddress.Loopback, GatePort);
listener.Start();
Console.WriteLine($"[GATE] listen :{GatePort}  (클라는 여기에만 붙는다)");

int nextId = 1;
while (true)
{
    var client = await listener.AcceptTcpClientAsync();
    int cid = nextId++;
    Console.WriteLine($"[GATE] 클라 C{cid} 접속");
    _ = HandleClientAsync(client, cid, ZoneOf, ZonePort0);
}

// 클라 한 명을 담당: 클라↔게이트는 계속 열려 있고, 게이트↔존서버(백엔드)만 필요할 때 갈아끼운다.
static async Task HandleClientAsync(TcpClient client, int cid, Func<float, float, int> ZoneOf, int zonePort0)
{
    NetworkStream cli = client.GetStream();
    int zone = 0;
    TcpClient backend = await ConnectBackend(zonePort0 + zone);
    var downCts = new CancellationTokenSource();
    _ = Pump(backend.GetStream(), cli, downCts.Token);   // 백엔드 → 클라 (방송 전달)

    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(cli);   // 클라 → 게이트
            if (type == PacketType.CM_MOVE)
            {
                var m = Codec.Deserialize<CM_MOVE>(data);
                int nz = ZoneOf(m.X, m.Y);
                if (nz != zone)
                {
                    // ★ 뒤 서버만 몰래 교체 — 클라 연결(cli)은 건드리지 않는다
                    Console.WriteLine($"[GATE] C{cid} 위치 zone {zone} → {nz} : 백엔드 교체 (클라는 그대로!)");
                    downCts.Cancel(); backend.Dispose();
                    zone = nz;
                    backend = await ConnectBackend(zonePort0 + zone);
                    downCts = new CancellationTokenSource();
                    _ = Pump(backend.GetStream(), cli, downCts.Token);
                }
                await Framing.SendFramedAsync(backend.GetStream(), type, data);   // 게이트 → 현재 백엔드
            }
        }
    }
    catch { }
    finally { downCts.Cancel(); backend.Dispose(); client.Dispose(); Console.WriteLine($"[GATE] C{cid} 종료"); }
}

// from 에서 프레임을 읽어 to 로 그대로 전달 (한 방향 파이프)
static async Task Pump(NetworkStream from, NetworkStream to, CancellationToken ct)
{
    try
    {
        while (!ct.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(from, ct);
            await Framing.SendFramedAsync(to, t, d, ct);
        }
    }
    catch { }
}

static async Task<TcpClient> ConnectBackend(int port)
{
    for (int a = 1; ; a++)
    {
        var c = new TcpClient();
        try { await c.ConnectAsync(IPAddress.Loopback, port); return c; }
        catch (SocketException) when (a < 30) { c.Dispose(); await Task.Delay(150); }
    }
}
