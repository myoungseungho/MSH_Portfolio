// ── STEP 0 · 삽 3 — 클라: 3번 이동한 뒤 '멈춰서 서 있는다'.
//    (틱 서버는 매 틱 전원 위치를 방송하니, 내가 안 움직여도 남에게 계속 보여야 정상.) ──

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int Port = 9001;

// 접속 (서버가 늦게 떠도 붙을 때까지 재시도)
TcpClient client = null!;
for (int a = 1; ; a++)
{
    try { client = new TcpClient(); await client.ConnectAsync(IPAddress.Loopback, Port); break; }
    catch (SocketException) when (a < 20) { client.Dispose(); await Task.Delay(200); }
}
var stream = client.GetStream();
Console.WriteLine("[C] connected");

var recv = RecvLoopAsync(stream);   // 남의 이동을 계속 받음
var send = SendLoopAsync(stream);   // 내 이동을 몇 번 보내고 멈춤
await Task.WhenAny(recv, send);
Console.WriteLine("[C] 종료");

// 남의 위치(SM_MOVE)를 받을 때마다 찍는다.
static async Task RecvLoopAsync(NetworkStream s)
{
    try
    {
        while (true)
        {
            var (t, d) = await Framing.ReadFramedAsync(s);
            if (t == PacketType.SM_MOVE)
            {
                var m = Codec.Deserialize<SM_MOVE>(d);
                Console.WriteLine($"[C] 👀 P{m.PlayerId} = ({m.X}, {m.Y})");
            }
        }
    }
    catch (IOException) { }
}

// 3번 이동 후 멈춰서 2초간 서 있는다 (그동안 남의 방송을 계속 받는지 보려고).
static async Task SendLoopAsync(NetworkStream s)
{
    float x = 0, y = 0;
    try
    {
        for (int i = 0; i < 3; i++)
        {
            x++; y++;
            await Framing.SendFramedAsync(s, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(x, y)));
            Console.WriteLine($"[C] → 나 이동 ({x}, {y})");
            await Task.Delay(700);
        }
        Console.WriteLine("[C] 나 멈춤 — 연결은 유지, 남이 계속 보이는지 확인");
        await Task.Delay(2000);
    }
    catch (IOException) { }
}
