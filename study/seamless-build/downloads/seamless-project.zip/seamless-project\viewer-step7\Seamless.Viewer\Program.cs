// ── STEP 7 · Raylib 3D 뷰어 — 경계 걸친 광역기(AoE): 원 하나가 여러 칸에 걸치면, 각 칸 주인이 자기 몬스터만 판정. ──
//    전 월드 자유 이동(관제 지휘관 뷰) + 9개 서버 직접 접속. 크로스헤어가 가리키는 '땅의 점'에 광역기를 터뜨린다.
//    좌클릭 → 내가 선 칸으로 CM_AOE 진입 → 진입 서버가 원이 겹친 칸들에 확산 → 각 주인이 '내 몬스터 중 반경 안'만 판정.
//    → 경계 위에 터뜨리면 다른 색(다른 주인) 몬스터들이 동시에 죽는다 = STEP 5 라우팅의 '공간 버전'.

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Cols = 3, CellSize = 10, ClientPort0 = 9001, W = 1180, H = 760, AOE_DMG = 60;
const float WorldSize = Cols * CellSize, AOE_R = 6f;   // 반경 6 = 경계·모서리에 터뜨리면 2~4칸 몬스터를 함께 덮음
Color[] ZC = { Color.DarkGreen, Color.Brown, Color.DarkBlue, Color.Maroon, Color.DarkGray, Color.Orange, Color.DarkPurple, Color.Green, Color.Blue };
int ZoneOf(float x, float y) => Math.Clamp((int)y / CellSize, 0, Cols - 1) * Cols + Math.Clamp((int)x / CellSize, 0, Cols - 1);
bool CircleHitsZone(float cx, float cy, float r, int z)
{
    float zx = (z % Cols) * CellSize, zy = (z / Cols) * CellSize;
    float px = Math.Clamp(cx, zx, zx + CellSize), py = Math.Clamp(cy, zy, zy + CellSize);
    float dx = cx - px, dy = cy - py; return dx * dx + dy * dy <= r * r;
}

var zones = new ZoneConn[9];
for (int z = 0; z < 9; z++) zones[z] = new ZoneConn { Zone = z };
var killEvents = new ConcurrentQueue<(int Id, Vector2 At, int Owner)>();
var cts = new CancellationTokenSource();
for (int zi = 0; zi < 9; zi++)
{
    int z = zi; var zc = zones[z];
    _ = Task.Run(async () =>
    {
        while (!cts.IsCancellationRequested)
        {
            try
            {
                using var cl = new TcpClient();
                await cl.ConnectAsync("127.0.0.1", ClientPort0 + z);
                var st = cl.GetStream(); zc.Stream = st; zc.Up = true;
                while (!cts.IsCancellationRequested)
                {
                    var (t, d) = await Framing.ReadFramedAsync(st, cts.Token);
                    if (t == PacketType.SM_MONSTER) { var m = Codec.Deserialize<SM_MOVE>(d); zc.Mon[m.PlayerId] = new Vector2(m.X, m.Y); Interlocked.Increment(ref zc.Pkt); }
                    else if (t == PacketType.SM_HP) { var h = Codec.Deserialize<HpMsg>(d); zc.Hp[h.Id] = (h.Hp, h.MaxHp); }
                    else if (t == PacketType.SM_KILL) { var m = Codec.Deserialize<SM_MOVE>(d); var at = zc.Mon.TryGetValue(m.PlayerId, out var p) ? p : new Vector2((z % Cols) * CellSize + 5, (z / Cols) * CellSize + 5); zc.Mon.TryRemove(m.PlayerId, out _); zc.Hp.TryRemove(m.PlayerId, out _); killEvents.Enqueue((m.PlayerId, at, m.PlayerId - 100)); }  // 주인 = id-100 (이웃 중계여도 정확)
                }
            }
            catch { }
            zc.Up = false; zc.Stream = null; zc.Mon.Clear(); zc.Hp.Clear();
            try { await Task.Delay(500, cts.Token); } catch { }
        }
    });
}
async Task FireAoe(int fromZone, float x, float y)
{
    var zc = zones[fromZone]; var st = zc.Stream; if (st == null) return;
    await zc.SendLock.WaitAsync();
    try { await Framing.SendFramedAsync(st, PacketType.CM_AOE, Codec.Serialize(new AoeMsg(x, y, AOE_R, AOE_DMG, -1))); } catch { } finally { zc.SendLock.Release(); }
}

InitWindow(W, H, "Seamless STEP 7 - Area of Effect (cross-cell)");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);
DisableCursor();
var glyphSrc = string.Concat(
    "WASD 이동  |  마우스 시점  |  좌클릭 광역기(AoE)  |  ESC 커서",
    "관제 지휘관 뷰 — 전 월드 자유 이동 + 경계 걸친 광역기 (9개 서버 직접 접속)",
    "현재 내가 선 칸 지상 조준 반경 겹친 칸 각 주인이 자기 몬스터만 판정",
    "광역기 발사 중심 걸친 칸 없음 격추 확산 진입 미니맵 전 월드 정상 다운 몹 연결 여러 것",
    "· → — ()");
var cps = Enumerable.Range(32, 95).Concat(glyphSrc.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

var numTex = new Texture2D[9];
for (int i = 0; i < 9; i++)
{
    var img = GenImageColor(256, 256, new Color((byte)0, (byte)0, (byte)0, (byte)0));
    var txt = i.ToString(); var sz = MeasureTextEx(hud, txt, 190, 1); var tp = new Vector2(128 - sz.X / 2, 128 - sz.Y / 2);
    ImageDrawTextEx(ref img, hud, txt, tp + new Vector2(5, 5), 190, 1, new Color((byte)0, (byte)0, (byte)0, (byte)200));
    ImageDrawTextEx(ref img, hud, txt, tp, 190, 1, new Color((byte)255, (byte)255, (byte)255, (byte)255));
    numTex[i] = LoadTextureFromImage(img); UnloadImage(img);
}
var numMesh = GenMeshPlane(5f, 5f, 1, 1);
var numModels = new Model[9];
for (int i = 0; i < 9; i++) { numModels[i] = LoadModelFromMesh(numMesh); unsafe { numModels[i].Materials[0].Maps[(int)MaterialMapIndex.Albedo].Texture = numTex[i]; } }

var playerPos = new Vector2(15, 15);
float yaw = 0f, pitch = 0.6f; bool captured = true; float cooldown = 0f;
var shocks = new List<Shock>(); var floaties = new List<Floaty>(); var recentKill = new Dictionary<int, double>();
string info = "크로스헤어가 가리키는 땅에 광역기가 미리 보인다. 좌클릭으로 발사 — 경계에 걸치면 여러 칸이 각자 판정.";
long[] pktSnap = new long[9]; double lastPktT = 0; int[] pps = new int[9];

while (!WindowShouldClose())
{
    float dt = GetFrameTime();
    if (captured) { var md = GetMouseDelta(); yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.15f, 1.4f); }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 9f * dt; }
    playerPos = Vector2.Clamp(playerPos, new Vector2(0.3f), new Vector2(WorldSize - 0.3f));
    int curZone = ZoneOf(playerPos.X, playerPos.Y);

    double now = GetTime();
    if (now - lastPktT >= 0.5) { for (int z = 0; z < 9; z++) { long p = Interlocked.Read(ref zones[z].Pkt); pps[z] = (int)((p - pktSnap[z]) / (now - lastPktT)); pktSnap[z] = p; } lastPktT = now; }

    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 11f;
    var camPos = headP + offset;
    var cam = new Camera3D { Position = camPos, Target = headP, Up = new Vector3(0, 1, 0), FovY = 60f, Projection = CameraProjection.Perspective };

    // 지상 조준: 카메라 정면 레이 ∩ 바닥(y=0)
    var look = Vector3.Normalize(headP - camPos);
    Vector2 aim;
    if (look.Y < -0.02f) { float t = -camPos.Y / look.Y; var hit = camPos + look * t; aim = new Vector2(hit.X, hit.Z); }
    else aim = playerPos + fwd * 10f;
    aim = Vector2.Clamp(aim, new Vector2(0.3f), new Vector2(WorldSize - 0.3f));

    if (cooldown > 0) cooldown -= dt;
    if (IsMouseButtonPressed(MouseButton.Left) && cooldown <= 0f)
    {
        _ = FireAoe(curZone, aim.X, aim.Y);
        shocks.Add(new Shock { Center = aim });
        var hitZones = Enumerable.Range(0, 9).Where(z => CircleHitsZone(aim.X, aim.Y, AOE_R, z)).ToList();
        info = $"광역기 발사! 중심({aim.X:0.0},{aim.Y:0.0}) · 걸친 칸 {string.Join(",", hitZones.Select(z => "Z" + z))} — 각 주인이 자기 몬스터만 판정 ({hitZones.Count}칸)";
        cooldown = 0.5f;
    }

    foreach (var s in shocks) s.Age += dt; shocks.RemoveAll(s => s.Age > 0.6f);
    while (killEvents.TryDequeue(out var ke))
    {
        if (recentKill.TryGetValue(ke.Id, out var tk) && now - tk < 1.5) continue;   // 이웃 중계로 온 중복 격추 무시
        recentKill[ke.Id] = now;
        floaties.Add(new Floaty { Pos = new Vector3(ke.At.X, 2.2f, ke.At.Y), Text = "격추!", Col = new Color((byte)255, (byte)90, (byte)90, (byte)255), Life = 1.5f });
        info = $"격추! M{ke.Id} — 주인 Z{ke.Owner}가 판정 (여러 칸이 각자 자기 것만)";
    }
    foreach (var f in floaties) f.Age += dt; floaties.RemoveAll(f => f.Age > f.Life);

    BeginDrawing();
    ClearBackground(new Color((byte)22, (byte)26, (byte)36, (byte)255));
    BeginMode3D(cam);
    for (int r = 0; r < Cols; r++) for (int cc = 0; cc < Cols; cc++)
    {
        int zi = r * Cols + cc; var ctr = new Vector3(cc * CellSize + 5, 0, r * CellSize + 5);
        DrawPlane(ctr, new Vector2(CellSize - 0.2f, CellSize - 0.2f), zones[zi].Up ? ZC[zi] : new Color((byte)45, (byte)45, (byte)50, (byte)255));
        DrawModel(numModels[zi], new Vector3(ctr.X, 0.07f, ctr.Z), 1f, Color.White);
    }
    for (int i = 0; i <= Cols; i++)
    {
        DrawLine3D(new Vector3(i * CellSize, 0.05f, 0), new Vector3(i * CellSize, 0.05f, WorldSize), Color.White);
        DrawLine3D(new Vector3(0, 0.05f, i * CellSize), new Vector3(WorldSize, 0.05f, i * CellSize), Color.White);
    }
    // 조준 원이 걸치는 칸 강조(노란 테두리) — '이 칸들이 각자 판정한다'
    for (int z = 0; z < 9; z++) if (CircleHitsZone(aim.X, aim.Y, AOE_R, z))
    {
        float zx = (z % Cols) * CellSize, zy = (z / Cols) * CellSize; float e = 0.12f; var yl = new Color((byte)255, (byte)225, (byte)60, (byte)230);
        DrawLine3D(new Vector3(zx + e, 0.1f, zy + e), new Vector3(zx + CellSize - e, 0.1f, zy + e), yl);
        DrawLine3D(new Vector3(zx + e, 0.1f, zy + CellSize - e), new Vector3(zx + CellSize - e, 0.1f, zy + CellSize - e), yl);
        DrawLine3D(new Vector3(zx + e, 0.1f, zy + e), new Vector3(zx + e, 0.1f, zy + CellSize - e), yl);
        DrawLine3D(new Vector3(zx + CellSize - e, 0.1f, zy + e), new Vector3(zx + CellSize - e, 0.1f, zy + CellSize - e), yl);
    }
    // 조준 미리보기 원 (반경 AOE_R)
    DrawCylinder(new Vector3(aim.X, 0.08f, aim.Y), AOE_R, AOE_R, 0.02f, 40, new Color((byte)255, (byte)170, (byte)40, (byte)45));
    DrawCylinderWires(new Vector3(aim.X, 0.09f, aim.Y), AOE_R, AOE_R, 0.02f, 40, new Color((byte)255, (byte)200, (byte)60, (byte)220));
    // 폭발 파동
    foreach (var s in shocks)
    {
        float k = s.Age / 0.6f; byte a = (byte)(220 * (1 - k));
        DrawCylinderWires(new Vector3(s.Center.X, 0.12f, s.Center.Y), AOE_R * k * 1.5f + 0.2f, AOE_R * k * 1.5f + 0.2f, 0.02f, 36, new Color((byte)255, (byte)140, (byte)30, a));
        DrawCylinder(new Vector3(s.Center.X, 0.05f, s.Center.Y), AOE_R * (1 - k), AOE_R * (1 - k), 0.02f, 30, new Color((byte)255, (byte)120, (byte)20, (byte)(a / 3)));
    }
    // 플레이어
    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.RayWhite);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.18f, ZC[curZone]);
    // 모든 칸 몬스터
    for (int z = 0; z < 9; z++) foreach (var kv in zones[z].Mon)
    {
        float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
        var p = new Vector3(kv.Value.X, 0.5f + bob, kv.Value.Y);
        DrawCube(p, 0.9f, 0.9f, 0.9f, ZC[z]); DrawCubeWires(p, 0.9f, 0.9f, 0.9f, Color.Black);
    }
    EndMode3D();

    // ── 2D: HP바 · 격추 숫자 · 크로스헤어 ──
    for (int z = 0; z < 9; z++) foreach (var kv in zones[z].Mon)
    {
        if (!zones[z].Hp.TryGetValue(kv.Key, out var h)) continue;
        var sp = GetWorldToScreen(new Vector3(kv.Value.X, 1.4f, kv.Value.Y), cam);
        if (sp.X < -40 || sp.X > W + 40 || sp.Y < -40 || sp.Y > H + 40) continue;
        float frac = Math.Clamp(h.Max <= 0 ? 0 : (float)h.Hp / h.Max, 0, 1);
        int bw = 44, bh = 6, bx = (int)sp.X - bw / 2, by = (int)sp.Y;
        DrawRectangle(bx - 1, by - 1, bw + 2, bh + 2, new Color((byte)0, (byte)0, (byte)0, (byte)170));
        DrawRectangle(bx, by, (int)(bw * frac), bh, ZC[z]);
        DrawTextEx(hud, $"M{kv.Key}", new Vector2(bx, by - 15), 13, 1, Color.White);
    }
    foreach (var f in floaties) { var sp = GetWorldToScreen(f.Pos + new Vector3(0, f.Age * 1.2f, 0), cam); byte al = (byte)(255 * Math.Clamp(1 - f.Age / f.Life, 0, 1)); DrawTextEx(hud, f.Text, new Vector2(sp.X - 14, sp.Y), 28, 1, new Color(f.Col.R, f.Col.G, f.Col.B, al)); }
    var cross = new Color((byte)255, (byte)200, (byte)50, (byte)220);
    DrawLine(W / 2 - 11, H / 2, W / 2 - 4, H / 2, cross); DrawLine(W / 2 + 4, H / 2, W / 2 + 11, H / 2, cross);
    DrawLine(W / 2, H / 2 - 11, W / 2, H / 2 - 4, cross); DrawLine(W / 2, H / 2 + 4, W / 2, H / 2 + 11, cross);

    // ── 미니맵 ──
    int mm = 186, mx = W - mm - 14, my = 14; float sc = mm / (float)WorldSize; int upc = 0;
    DrawRectangle(mx - 6, my - 6, mm + 12, mm + 34, new Color((byte)10, (byte)12, (byte)18, (byte)210));
    DrawTextEx(hud, "전 월드", new Vector2(mx, my - 4 + mm + 8), 15, 1, Color.White);
    for (int z = 0; z < 9; z++)
    {
        if (zones[z].Up) upc++;
        int cxp = (z % Cols) * (mm / Cols), cyp = (z / Cols) * (mm / Cols), csz = mm / Cols;
        DrawRectangle(mx + cxp, my + cyp, csz - 1, csz - 1, zones[z].Up ? new Color(ZC[z].R, ZC[z].G, ZC[z].B, (byte)200) : new Color((byte)50, (byte)50, (byte)56, (byte)220));
    }
    for (int z = 0; z < 9; z++) foreach (var kv in zones[z].Mon)
        DrawCircle(mx + (int)(kv.Value.X * sc), my + (int)(kv.Value.Y * sc), 2.6f, new Color((byte)255, (byte)80, (byte)80, (byte)255));
    DrawCircleLines(mx + (int)(aim.X * sc), my + (int)(aim.Y * sc), AOE_R * sc, new Color((byte)255, (byte)200, (byte)60, (byte)255));   // 조준 원
    DrawCircle(mx + (int)(playerPos.X * sc), my + (int)(playerPos.Y * sc), 4f, Color.White);
    DrawCircleLines(mx + (int)(playerPos.X * sc), my + (int)(playerPos.Y * sc), 5f, Color.Black);
    DrawTextEx(hud, $"연결 {upc}/9", new Vector2(mx + mm - 66, my - 4 + mm + 8), 15, 1, new Color((byte)150, (byte)200, (byte)160, (byte)255));

    // ── HUD ──
    DrawRectangle(0, 0, W - 210, 92, new Color((byte)0, (byte)0, (byte)0, (byte)110));
    DrawTextEx(hud, "관제 지휘관 뷰 — 전 월드 자유 이동 + 경계 걸친 광역기(AoE)", new Vector2(14, 12), 19, 1, Color.White);
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  좌클릭 광역기  |  ESC 커서", new Vector2(14, 40), 17, 1, new Color((byte)180, (byte)200, (byte)230, (byte)255));
    DrawTextEx(hud, $"현재 내가 선 칸 Z{curZone}", new Vector2(14, 66), 18, 1, Color.Gold);
    DrawTextEx(hud, info, new Vector2(14, H - 30), 18, 1, new Color((byte)255, (byte)220, (byte)120, (byte)255));
    EndDrawing();
}

cts.Cancel();
CloseWindow();

sealed class ZoneConn
{
    public int Zone;
    public volatile bool Up;
    public volatile NetworkStream? Stream;
    public long Pkt;
    public readonly ConcurrentDictionary<int, Vector2> Mon = new();
    public readonly ConcurrentDictionary<int, (int Hp, int Max)> Hp = new();
    public readonly SemaphoreSlim SendLock = new(1, 1);
}
sealed class Shock { public Vector2 Center; public float Age; }
sealed class Floaty { public Vector3 Pos; public string Text = ""; public Color Col; public float Age; public float Life = 1.0f; }
