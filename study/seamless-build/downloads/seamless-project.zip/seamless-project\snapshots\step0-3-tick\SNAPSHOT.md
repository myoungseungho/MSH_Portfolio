# STEP 0 · 삽 3 — 틱(심장)

이 스냅샷 = **세상이 스스로 흐르고(심장박동), 게임 로직이 한 스레드로 모인** 상태.

## ✅ 되는 것
- 틱 루프(0.5초마다)가 계속 돎 — **접속자 0명이어도 `tick #1`이 찍힘** (세상이 스스로 흐름)
- 네트워크는 받은 이동을 **큐(inbox)에 넣기만**, 틱이 꺼내 world 갱신 + 전원 방송
- **가만 서 있어도** 매 틱 방송되어 계속 보임 (브로드캐스트 삽의 결핍 해결)

## 🆕 바뀐 것 (당신 회사 서버 방식)
- 여러 스레드 → **한 스레드(틱)로 게임 로직 모음**
- world/conns = **평범한 Dictionary** (ConcurrentDictionary 버림)
- 보내기도 틱 혼자 → **SemaphoreSlim 버림**
- 유일한 '스레드 안전' 지점 = **큐(ConcurrentQueue) 하나** (네트워크→틱 handoff)

## ❌ 아직 안 되는 것 (STEP 0 마지막 조각)
- 몬스터 없음 → **다음 삽: 몬스터** = 스스로 움직이는 것을 world에 얹기 → **STEP 0 완성**

## 실행
```
dotnet build
# 터미널 1:  dotnet run --project Seamless.Server
# 터미널 2~N: dotnet run --project Seamless.Client
```

## 복습
같은 폴더의 `INTERVIEW.md` — 쉬운 버전 면접 Q&A.
