// ── 이 파일도 top-level statements(파일 맨 위 실행문)로 된 '시작점'. 컴파일러가 자동으로 Main 안에 넣어준다. ──

using System.Net;            // IPAddress 이름 가져오기
using System.Net.Sockets;    // TcpClient, SocketException 이름 가져오기
using Seamless.Shared;       // 공용 프로젝트(PacketType, CM_MOVE, Codec, Framing) 이름 가져오기

// STEP 0 첫 삽 — 클라: connect하고 CM_MOVE 하나 보냄.
try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }  // 콘솔 한글 안 깨지게
const int Port = 9001;       // 접속할 서버의 포트

TcpClient client = null!;    // 연결 객체를 담을 변수. null! = "지금은 비었지만 곧 채운다, 경고 꺼라"라는 표시.
for (int attempt = 1; ; attempt++)   // 서버가 아직 안 켜졌을 수 있으니 붙을 때까지 여러 번 시도(가운데 조건 비움=무한, break로 나감)
{
    try
    {
        client = new TcpClient();                            // 새 연결 객체 준비
        await client.ConnectAsync(IPAddress.Loopback, Port); // 127.0.0.1:9001 에 실제로 접속 시도(성공하면 통로 열림)
        break;                                               // 붙었으면 반복 탈출
    }
    catch (SocketException) when (attempt < 20)              // 접속 실패이면서 아직 20번 안 넘었으면(=서버가 아직 준비 전일 것)
    {
        client.Dispose();                                    // 실패한 연결 객체는 버리고
        Console.WriteLine($"[C] connect 재시도 {attempt}...");
        await Task.Delay(200);                               // 0.2초 쉬었다가 → 루프 위로 돌아가 다시 시도
    }
}
Console.WriteLine($"[C] connected 127.0.0.1:{Port}");        // 붙었다는 로그

using (client)                              // 블록이 끝나면 연결을 자동으로 닫는다
using (var stream = client.GetStream())     // 그 연결 위의 '읽고/쓰는 통로'를 꺼낸다(블록 끝나면 자동 정리)
{
    var data = Codec.Serialize(new CM_MOVE(10, 5));                  // 이동 편지(10,5)를 만들어 바이트로 굽는다(직렬화). playerId 안 담음.
    await Framing.SendFramedAsync(stream, PacketType.CM_MOVE, data); // [길이][타입=CM_MOVE][데이터] 로 감싸 보낸다
    Console.WriteLine("[C] → sent CM_MOVE(10, 5)");                  // 보냈다는 로그

    await Task.Delay(800);   // 서버가 받아 로그를 찍을 시간을 잠깐 준다(그다음 블록이 끝나며 연결이 닫히고 프로그램 종료)
}
