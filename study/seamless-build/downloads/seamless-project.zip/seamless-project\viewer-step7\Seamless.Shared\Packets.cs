// 이 파일은 "서버와 클라가 주고받을 편지(패킷)가 어떻게 생겼는지"만 정한다. 로직은 없고 오직 '모양'.

using System.Runtime.InteropServices;   // 아래 [StructLayout]("메모리 배치 지정") 도구를 쓰려고 불러옴

namespace Seamless.Shared;   // 이 코드들의 '주소'. 서버·클라 둘 다 이 주소를 참조해 같은 패킷 정의를 공유한다.

// 메시지 '종류 번호표'. 봉투에 붙는 "이건 무슨 편지" 딱지. 숫자 하나(byte)면 충분해서 : byte 로 둔다.
public enum PacketType : byte
{
    CM_MOVE    = 1,  // 클라 → 서버: "나 이동할래"
    SM_MOVE    = 2,  // 서버 → 클라: "누가(playerId) 어디로 이동" (플레이어 방송)
    SM_MONSTER = 3,  // 서버 → 클라: "몬스터가 어디로" (SM_MOVE와 같은 모양을 재사용, 봉투 타입만 다름)
    SM_GHOST   = 4,  // 서버 → 클라: "옆 칸 액터의 읽기전용 복사본(고스트)" (STEP 3) — 경계 너머가 보이게
    CM_ATTACK  = 5,  // 클라 → 서버: "저 대상(targetId)에게 데미지" (STEP 5). 시스템이 대상의 '주인 서버'로 라우팅.
    SM_KILL    = 6,  // 서버 → 클라: "대상(targetId)이 격추됨". 주인이 판정 후 결과를 전파.
    SM_HP      = 7,  // 서버 → 클라: "대상(id)의 HP는 지금 얼마". 주인이 판정한 진짜 HP를 방송(+경계면 이웃에도) → 뷰어 HP바.
    CM_AOE     = 8,  // 클라/서버 → 서버: "이 중심·반경에 광역 데미지" (STEP 7). 여러 칸에 걸치면 각 칸 주인이 자기 몬스터만 판정.
}

// [StructLayout(Sequential, Pack=1)] = "이 구조체를 메모리에 '빈틈(패딩) 없이, 적은 순서 그대로' 배치하라".
[StructLayout(LayoutKind.Sequential, Pack = 1)]
// 클라→서버 '이동 요청' 편지. 안에는 X, Y 좌표 둘뿐(float=소수 4바이트씩) → 총 8바이트.
public readonly record struct CM_MOVE(float X, float Y);

[StructLayout(LayoutKind.Sequential, Pack = 1)]
// 서버→클라 '이동 방송' 편지. "누가(PlayerId) 어디로(X,Y), 주인이 몇 번 서버(AuthorityServerId)".
public readonly record struct SM_MOVE(int PlayerId, float X, float Y, byte AuthorityServerId);

// 클라 → 서버 (STEP 5): "저 대상에게 데미지". 어느 서버로 보낼지 클라는 모른다 — 시스템이 주인을 찾아 라우팅한다.
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public readonly record struct AttackMsg(int TargetId, int Damage);

// 서버 → 클라 (뷰어용): "대상(Id)의 HP는 Hp/MaxHp". 주인 서버가 판정한 값을 방송 → 클라는 진짜 HP바를 그린다.
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public readonly record struct HpMsg(int Id, int Hp, int MaxHp);

// 광역기(STEP 7): 중심(X,Y)·반경 R·데미지. TargetZone = -1 이면 '진입'(겹친 칸들로 확산), >=0 이면 그 칸 주인이 판정.
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public readonly record struct AoeMsg(float X, float Y, float R, int Damage, int TargetZone);
