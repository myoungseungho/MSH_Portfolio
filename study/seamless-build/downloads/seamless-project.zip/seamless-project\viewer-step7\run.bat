@echo off
rem STEP 7: 9칸 존 서버(광역기 AoE + 멀티홉 + HP) + 관제 지휘관 뷰. 게이트 없음(관제는 9개 직접 접속).
rem 크로스헤어로 땅을 조준, 좌클릭 광역기 → 경계에 걸치면 여러 칸이 각자 자기 몬스터만 판정.
cd /d "%~dp0"
rem 이전 실행에서 남은 좀비 정리
powershell -NoProfile -Command "Get-Process Seamless.Server,Seamless.Gate,Seamless.Viewer -EA SilentlyContinue | Stop-Process -Force -EA SilentlyContinue"
timeout /t 1 /nobreak >nul
for /L %%z in (0,1,8) do start "Zone%%z" dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
timeout /t 4 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
