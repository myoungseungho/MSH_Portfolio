// ── STEP 5 · Raylib 3D 뷰어 — 위치 투명 라우팅(★두 번째 마법): 경계 너머 몬스터를 로켓으로 잡는다. ──
//    조준은 자동(카메라 정면의 대상 소프트락). 좌클릭 → 로켓 발사 + CM_ATTACK(대상id) 전송.
//    나(클라)는 그 대상의 '주인 서버'가 어딘지 몰라도 된다 — 서버가 주인을 찾아 라우팅하고, '주인'만 판정한다.
//    옆 칸(다른 색) 고스트 몬스터를 쏘면, 데미지가 주인 서버로 넘어가 HP가 깎이고, 격추가 온 세계에 전파된다.

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Cols = 3, CellSize = 10, GatePort = 9000, W = 1100, H = 720, DMG = 25;
const float WorldSize = Cols * CellSize;
Color[] ZC = { Color.DarkGreen, Color.Brown, Color.DarkBlue, Color.Maroon, Color.DarkGray, Color.Orange, Color.DarkPurple, Color.Green, Color.Blue };

// ── 게이트 접속 + 수신을 '백그라운드'에서 (창은 무조건 먼저 뜬다. 게이트가 늦어도/좀비여도 무한 재시도) ──
var actors = new ConcurrentDictionary<int, Actor>();
var hp = new ConcurrentDictionary<int, (int Hp, int Max)>();
var dmgEvents = new ConcurrentQueue<(int Raw, int Delta)>();
var killEvents = new ConcurrentQueue<int>();
int authZoneRecv = 0; long pktTotal = 0;
NetworkStream? stream = null;                 // 연결되면 채워짐(끊기면 null) → 메인 루프는 이걸 보고 보냄
var sendLock = new SemaphoreSlim(1, 1);
async Task Send(PacketType t, byte[] d) { var st = stream; if (st == null) return; await sendLock.WaitAsync(); try { await Framing.SendFramedAsync(st, t, d); } catch { } finally { sendLock.Release(); } }
var netCts = new CancellationTokenSource();
_ = Task.Run(async () =>
{
    while (!netCts.IsCancellationRequested)
    {
        try
        {
            using var c = new TcpClient();
            await c.ConnectAsync("127.0.0.1", GatePort);
            var st = c.GetStream(); stream = st;
            Console.WriteLine("[VIEWER] 게이트 접속");
            while (!netCts.IsCancellationRequested)
            {
                var (t, d) = await Framing.ReadFramedAsync(st, netCts.Token);
                if (t == PacketType.SM_HP)
                {
                    var h = Codec.Deserialize<HpMsg>(d);
                    if (hp.TryGetValue(h.Id, out var old) && h.Hp < old.Hp) dmgEvents.Enqueue((h.Id, old.Hp - h.Hp));
                    hp[h.Id] = (h.Hp, h.MaxHp);
                    continue;
                }
                if (t == PacketType.SM_KILL) { var m = Codec.Deserialize<SM_MOVE>(d); killEvents.Enqueue(m.PlayerId); continue; }
                var sm = Codec.Deserialize<SM_MOVE>(d);
                var kind = t switch { PacketType.SM_MONSTER => ActorKind.Monster, PacketType.SM_GHOST => ActorKind.Ghost, _ => ActorKind.Player };
                if (kind == ActorKind.Monster) Volatile.Write(ref authZoneRecv, sm.AuthorityServerId);
                int key = kind == ActorKind.Ghost ? 1_000_000 + sm.PlayerId : sm.PlayerId;
                actors.AddOrUpdate(key,
                    _ => new Actor { Raw = sm.PlayerId, Target = new(sm.X, sm.Y), Cur = new(sm.X, sm.Y), Kind = kind, Zone = sm.AuthorityServerId, LastSeen = Environment.TickCount64 },
                    (_, ac) => { ac.Raw = sm.PlayerId; ac.Target = new(sm.X, sm.Y); ac.Kind = kind; ac.Zone = sm.AuthorityServerId; ac.LastSeen = Environment.TickCount64; return ac; });
                Interlocked.Increment(ref pktTotal);
            }
        }
        catch { }
        stream = null;
        try { await Task.Delay(500, netCts.Token); } catch { }
    }
});

InitWindow(W, H, "Seamless STEP 5 - Location-Transparent Routing");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);
DisableCursor();
// 화면에 실제로 그리는 모든 한글 문장을 그대로 글리프 소스로 삼는다 → 빠진 글자('?') 원천 차단
var glyphSrc = string.Concat(
    "WASD 이동  |  마우스 시점  |  좌클릭/Space 발사(자동 조준)  |  ESC 커서",
    "현재 담당 서버 수신 게이트 연결 대기중",
    "옆 칸(다른 색) 고스트 몬스터를 조준하고 좌클릭!",
    "공격: M — 내 담당 서버 (라우팅 불필요) → 서버가 주인 로 라우팅 (나는 몰라도 됨)",
    "빨강=내 칸 몬스터 · 반투명=옆 칸 고스트(주인 색 테두리). 옆 칸을 쏘면 서버가 주인에게 라우팅.",
    "격추! — 주인 가 판정 (경계 너머 라우팅 성공)");
var cps = Enumerable.Range(32, 95).Concat(glyphSrc.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

var numTex = new Texture2D[9];
for (int i = 0; i < 9; i++)
{
    var img = GenImageColor(256, 256, new Color((byte)0, (byte)0, (byte)0, (byte)0));
    var txt = i.ToString(); var sz = MeasureTextEx(hud, txt, 190, 1); var tp = new Vector2(128 - sz.X / 2, 128 - sz.Y / 2);
    ImageDrawTextEx(ref img, hud, txt, tp + new Vector2(5, 5), 190, 1, new Color((byte)0, (byte)0, (byte)0, (byte)200));
    ImageDrawTextEx(ref img, hud, txt, tp, 190, 1, new Color((byte)255, (byte)255, (byte)255, (byte)255));
    numTex[i] = LoadTextureFromImage(img); UnloadImage(img);
}
var numMesh = GenMeshPlane(5f, 5f, 1, 1);
var numModels = new Model[9];
for (int i = 0; i < 9; i++) { numModels[i] = LoadModelFromMesh(numMesh); unsafe { numModels[i].Materials[0].Maps[(int)MaterialMapIndex.Albedo].Texture = numTex[i]; } }

var playerPos = new Vector2(9.3f, 5f);   // 존0 오른쪽 경계(존1과의 seam) 근처에서 시작 → 바로 옆 칸 몬스터 보임
int curAuth = 0;
float yaw = 0.6f, pitch = 0.5f; bool captured = true; float sendTimer = 0f;
long lastPktSnap = 0; double lastPktT = 0; int pktPerSec = 0;
float cooldown = 0f; string attackText = "옆 칸(다른 색) 고스트 몬스터를 조준하고 좌클릭!"; float killFlash = 0f; string killText = "";
var rockets = new List<Rocket>();
var sparks = new List<Spark>();
var floaties = new List<Floaty>();

while (!WindowShouldClose())
{
    float dt = GetFrameTime();
    if (captured) { var md = GetMouseDelta(); yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.12f, 1.35f); }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 6f * dt; }
    playerPos = Vector2.Clamp(playerPos, new Vector2(0.1f), new Vector2(WorldSize - 0.1f));

    // 담당 서버(백엔드) 교체 감지 → 이전 존 액터 비움
    int authZone = Volatile.Read(ref authZoneRecv);
    if (authZone != curAuth) { curAuth = authZone; foreach (var k in actors.Keys.ToList()) actors.TryRemove(k, out _); hp.Clear(); }

    // 액터 만료 + 보간
    long nowMs = Environment.TickCount64;
    foreach (var k in actors.Where(kv => nowMs - kv.Value.LastSeen > 400).Select(kv => kv.Key).ToList()) actors.TryRemove(k, out _);
    float kl = 1f - MathF.Exp(-14f * dt);
    foreach (var ac in actors.Values) ac.Cur = Vector2.Lerp(ac.Cur, ac.Target, kl);

    // ── 소프트락: 카메라 정면에 가장 가까운 몬스터/고스트를 조준 ──
    int lockedKey = -1; float bestScore = 0.55f;
    foreach (var kv in actors)
    {
        if (kv.Value.Kind != ActorKind.Monster && kv.Value.Kind != ActorKind.Ghost) continue;
        var to = kv.Value.Cur - playerPos; float dist = to.Length();
        if (dist > 15f || dist < 0.05f) continue;
        float score = Vector2.Dot(to / dist, fwd);
        if (score > bestScore) { bestScore = score; lockedKey = kv.Key; }
    }

    // ── 발사 ──
    if (cooldown > 0) cooldown -= dt;
    if ((IsMouseButtonPressed(MouseButton.Left) || IsKeyPressed(KeyboardKey.Space)) && lockedKey != -1 && cooldown <= 0f)
    {
        var tgt = actors[lockedKey]; int raw = tgt.Raw; int owner = tgt.Zone;
        _ = Send(PacketType.CM_ATTACK, Codec.Serialize(new AttackMsg(raw, DMG)));
        rockets.Add(new Rocket { Pos = new Vector3(playerPos.X, 1.4f, playerPos.Y), TargetKey = lockedKey, LastXY = tgt.Cur, Owner = owner, Raw = raw });
        attackText = owner == authZone
            ? $"공격: M{raw} — 내 담당 서버 Z{owner} (라우팅 불필요)"
            : $"공격: M{raw} → 서버가 주인 Z{owner}로 라우팅 (나는 몰라도 됨)";
        cooldown = 0.30f;
    }

    // 로켓 이동(호밍) + 명중
    foreach (var r in rockets)
    {
        Vector3 tp;
        if (actors.TryGetValue(r.TargetKey, out var ta)) { r.LastXY = ta.Cur; tp = new Vector3(ta.Cur.X, 0.9f, ta.Cur.Y); }
        else tp = new Vector3(r.LastXY.X, 0.9f, r.LastXY.Y);
        var dir = tp - r.Pos; float dist = dir.Length(); float stepd = 34f * dt;
        if (dist <= stepd + 0.5f) { r.Done = true; sparks.Add(new Spark { Pos = tp }); }
        else r.Pos += dir / dist * stepd;
    }
    rockets.RemoveAll(r => r.Done);
    foreach (var s in sparks) s.Age += dt; sparks.RemoveAll(s => s.Age > 0.35f);

    // 데미지 숫자 / 격추 처리
    while (dmgEvents.TryDequeue(out var de))
    {
        Vector2 at = actors.TryGetValue(de.Raw, out var a1) ? a1.Cur : (actors.TryGetValue(1_000_000 + de.Raw, out var a2) ? a2.Cur : playerPos);
        floaties.Add(new Floaty { Pos = new Vector3(at.X, 2.2f, at.Y), Text = $"-{de.Delta}", Col = new Color((byte)255, (byte)210, (byte)70, (byte)255) });
    }
    while (killEvents.TryDequeue(out var kid))
    {
        int owner = actors.TryGetValue(kid, out var ka) ? ka.Zone : (actors.TryGetValue(1_000_000 + kid, out var kg) ? kg.Zone : (kid - 100));
        Vector2 at = actors.TryGetValue(kid, out var pa) ? pa.Cur : (actors.TryGetValue(1_000_000 + kid, out var pg) ? pg.Cur : playerPos);
        floaties.Add(new Floaty { Pos = new Vector3(at.X, 2.4f, at.Y), Text = "격추!", Col = new Color((byte)255, (byte)90, (byte)90, (byte)255), Life = 1.6f });
        actors.TryRemove(kid, out _); actors.TryRemove(1_000_000 + kid, out _); hp.TryRemove(kid, out _);
        killFlash = 1.8f; killText = $"격추! M{kid} — 주인 Z{owner}가 판정 (경계 너머 라우팅 성공)";
    }
    foreach (var f in floaties) f.Age += dt; floaties.RemoveAll(f => f.Age > f.Life);
    if (killFlash > 0) killFlash -= dt;

    sendTimer += dt;
    if (sendTimer > 0.05f) { sendTimer = 0f; _ = Send(PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(playerPos.X, playerPos.Y))); }

    double now = GetTime();
    if (now - lastPktT >= 0.5) { pktPerSec = (int)((pktTotal - lastPktSnap) / (now - lastPktT)); lastPktSnap = pktTotal; lastPktT = now; }

    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 9f;
    var cam = new Camera3D { Position = headP + offset, Target = headP, Up = new Vector3(0, 1, 0), FovY = 58f, Projection = CameraProjection.Perspective };

    BeginDrawing();
    ClearBackground(Color.SkyBlue);
    BeginMode3D(cam);
    for (int r = 0; r < Cols; r++) for (int cc = 0; cc < Cols; cc++)
    {
        int zi = r * Cols + cc;
        var center = new Vector3(cc * CellSize + CellSize / 2f, 0, r * CellSize + CellSize / 2f);
        DrawPlane(center, new Vector2(CellSize - 0.15f, CellSize - 0.15f), ZC[zi]);
        DrawModel(numModels[zi], new Vector3(center.X, 0.07f, center.Z), 1f, Color.White);
    }
    for (int i = 0; i <= Cols; i++)
    {
        DrawLine3D(new Vector3(i * CellSize, 0.05f, 0), new Vector3(i * CellSize, 0.05f, WorldSize), Color.White);
        DrawLine3D(new Vector3(0, 0.05f, i * CellSize), new Vector3(WorldSize, 0.05f, i * CellSize), Color.White);
    }
    // 락온 대상 발밑 링
    if (lockedKey != -1 && actors.TryGetValue(lockedKey, out var lk))
        DrawCylinderWires(new Vector3(lk.Cur.X, 0.06f, lk.Cur.Y), 0.85f, 0.85f, 0.02f, 20, new Color((byte)255, (byte)230, (byte)40, (byte)255));

    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.RayWhite);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.18f, ZC[curAuth]);

    foreach (var kv in actors)
    {
        var ac = kv.Value;
        if (ac.Kind == ActorKind.Monster)
        {
            float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
            var p = new Vector3(ac.Cur.X, 0.5f + bob, ac.Cur.Y);
            DrawCube(p, 0.9f, 0.9f, 0.9f, Color.Red); DrawCubeWires(p, 0.9f, 0.9f, 0.9f, Color.Maroon);
        }
        else if (ac.Kind == ActorKind.Ghost)
        {
            var p = new Vector3(ac.Cur.X, 0.5f, ac.Cur.Y);
            DrawCube(p, 0.9f, 0.9f, 0.9f, new Color((byte)200, (byte)210, (byte)255, (byte)90));
            DrawCubeWires(p, 0.9f, 0.9f, 0.9f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);
        }
    }
    foreach (var r in rockets) { DrawSphere(r.Pos, 0.16f, Color.Orange); DrawSphereWires(r.Pos, 0.28f, 6, 6, new Color((byte)255, (byte)180, (byte)60, (byte)160)); }
    foreach (var s in sparks) { float rr = 0.3f + s.Age * 3f; DrawSphereWires(s.Pos, rr, 7, 7, new Color((byte)255, (byte)150, (byte)40, (byte)(int)(200 * (1 - s.Age / 0.35f)))); }
    EndMode3D();

    // ── 2D: HP바 · 데미지 숫자 · 조준선 ──
    foreach (var kv in actors)
    {
        var ac = kv.Value; if (ac.Kind == ActorKind.Player) continue;
        if (!hp.TryGetValue(ac.Raw, out var h)) continue;
        var sp = GetWorldToScreen(new Vector3(ac.Cur.X, 1.5f, ac.Cur.Y), cam);
        if (sp.X < -50 || sp.X > W + 50) continue;
        float frac = Math.Clamp(h.Max <= 0 ? 0 : (float)h.Hp / h.Max, 0, 1);
        int bw = 54, bh = 7; int bx = (int)sp.X - bw / 2, by = (int)sp.Y;
        Color fill = ac.Kind == ActorKind.Ghost ? (ac.Zone < 9 ? ZC[ac.Zone] : Color.White) : Color.Red;
        DrawRectangle(bx - 1, by - 1, bw + 2, bh + 2, new Color((byte)0, (byte)0, (byte)0, (byte)170));
        DrawRectangle(bx, by, (int)(bw * frac), bh, fill);
        DrawTextEx(hud, $"M{ac.Raw}  {h.Hp}/{h.Max}", new Vector2(bx, by - 17), 15, 1, Color.White);
    }
    foreach (var f in floaties)
    {
        var sp = GetWorldToScreen(f.Pos + new Vector3(0, f.Age * 1.2f, 0), cam);
        byte al = (byte)(255 * Math.Clamp(1 - f.Age / f.Life, 0, 1));
        DrawTextEx(hud, f.Text, new Vector2(sp.X - 12, sp.Y), f.Text == "격추!" ? 30 : 24, 1, new Color(f.Col.R, f.Col.G, f.Col.B, al));
    }
    // 조준선(크로스헤어)
    var cross = lockedKey != -1 ? new Color((byte)255, (byte)230, (byte)40, (byte)255) : new Color((byte)255, (byte)255, (byte)255, (byte)180);
    DrawLine(W / 2 - 11, H / 2, W / 2 - 4, H / 2, cross); DrawLine(W / 2 + 4, H / 2, W / 2 + 11, H / 2, cross);
    DrawLine(W / 2, H / 2 - 11, W / 2, H / 2 - 4, cross); DrawLine(W / 2, H / 2 + 4, W / 2, H / 2 + 11, cross);
    DrawCircleLines(W / 2, H / 2, 3, cross);

    // ── HUD ──
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  좌클릭/Space 발사(자동 조준)  |  ESC 커서", new Vector2(14, 12), 20, 1, Color.Black);
    DrawTextEx(hud, $"현재 담당 서버 Z{curAuth}    수신 {pktPerSec} pkt/s", new Vector2(14, 42), 19, 1, Color.Maroon);
    DrawTextEx(hud, attackText, new Vector2(14, 70), 20, 1, new Color((byte)20, (byte)70, (byte)160, (byte)255));
    DrawTextEx(hud, "빨강=내 칸 몬스터 · 반투명=옆 칸 고스트(주인 색 테두리). 옆 칸을 쏘면 서버가 주인에게 라우팅.", new Vector2(14, H - 30), 17, 1, Color.DarkBlue);
    if (stream == null)
    {
        DrawRectangle(0, H / 2 - 24, W, 48, new Color((byte)150, (byte)100, (byte)20, (byte)210));
        DrawTextEx(hud, "게이트 연결 대기중... (서버가 다 뜨면 자동 연결)", new Vector2(W / 2 - 220, H / 2 - 12), 22, 1, Color.White);
    }
    if (killFlash > 0)
    {
        DrawRectangle(0, H / 2 + 40, W, 54, new Color((byte)160, (byte)30, (byte)40, (byte)210));
        DrawTextEx(hud, killText, new Vector2(W / 2 - MeasureTextEx(hud, killText, 24, 1).X / 2, H / 2 + 52), 24, 1, Color.White);
    }
    EndDrawing();
}

netCts.Cancel();
CloseWindow();

enum ActorKind { Player, Monster, Ghost }
sealed class Actor { public int Raw; public Vector2 Target; public Vector2 Cur; public ActorKind Kind; public int Zone; public long LastSeen; }
sealed class Rocket { public Vector3 Pos; public int TargetKey; public Vector2 LastXY; public int Owner; public int Raw; public bool Done; }
sealed class Spark { public Vector3 Pos; public float Age; }
sealed class Floaty { public Vector3 Pos = default; public string Text = ""; public Color Col; public float Age; public float Life = 1.0f; }
