@echo off
rem STEP 5: 9칸 존 서버(공격 라우팅 + HP 방송) + 게이트(H=2, 모든 패킷 전달) + 3D 뷰어.
rem 존0 오른쪽 경계에서 시작 → 옆 칸(존1) 몬스터 고스트를 조준하고 좌클릭 → 로켓 → 주인 Z1이 판정 → 격추.
cd /d "%~dp0"
rem 이전 실행에서 남은 좀비(서버·게이트·뷰어) 정리 — 포트 물고 있으면 새 실행이 막힘
powershell -NoProfile -Command "Get-Process Seamless.Server,Seamless.Gate,Seamless.Viewer -EA SilentlyContinue | Stop-Process -Force -EA SilentlyContinue"
timeout /t 1 /nobreak >nul
for /L %%z in (0,1,8) do start "Zone%%z" /min dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
start "Gate" /min dotnet "Seamless.Gate\bin\Debug\net8.0\Seamless.Gate.dll" 2
timeout /t 4 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
