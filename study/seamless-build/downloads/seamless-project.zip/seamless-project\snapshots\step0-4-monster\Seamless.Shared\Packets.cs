// 이 파일은 "서버와 클라가 주고받을 편지(패킷)가 어떻게 생겼는지"만 정한다. 로직은 없고 오직 '모양'.

using System.Runtime.InteropServices;   // 아래 [StructLayout]("메모리 배치 지정") 도구를 쓰려고 불러옴

namespace Seamless.Shared;   // 이 코드들의 '주소'. 서버·클라 둘 다 이 주소를 참조해 같은 패킷 정의를 공유한다.

// 메시지 '종류 번호표'. 봉투에 붙는 "이건 무슨 편지" 딱지. 숫자 하나(byte)면 충분해서 : byte 로 둔다.
public enum PacketType : byte
{
    CM_MOVE    = 1,  // 클라 → 서버: "나 이동할래"
    SM_MOVE    = 2,  // 서버 → 클라: "누가(playerId) 어디로 이동" (플레이어 방송)
    SM_MONSTER = 3,  // 서버 → 클라: "몬스터가 어디로" (SM_MOVE와 같은 모양을 재사용, 봉투 타입만 다름)
}

// [StructLayout(Sequential, Pack=1)] = "이 구조체를 메모리에 '빈틈(패딩) 없이, 적은 순서 그대로' 배치하라".
//   왜 필요? 아래 Codec이 이 구조체의 메모리를 '통째로 복사'해 바이트로 만드는데, 빈틈이 끼면
//   선으로 나가는 바이트 배치가 흐트러진다. 그래서 배치를 딱 고정해 확정적으로 만든다.
[StructLayout(LayoutKind.Sequential, Pack = 1)]
// 클라→서버 '이동 요청' 편지. 안에는 X, Y 좌표 둘뿐(float=소수 4바이트씩) → 총 8바이트.
//   playerId가 없는 이유: '누가 보냈나'는 서버가 그 연결(소켓)로 이미 안다. 클라가 적게 하면 남을 사칭할 수 있어 일부러 뺀다.
public readonly record struct CM_MOVE(float X, float Y);

[StructLayout(LayoutKind.Sequential, Pack = 1)]
// 서버→클라 '이동 방송' 편지. 서버가 "누가(PlayerId) 어디로(X,Y) 갔고, 그 주인이 몇 번 서버냐(AuthorityServerId)"를 찍어 내려준다.
//   AuthorityServerId는 지금은 늘 0(서버 1대뿐)이라 쓸모없어 보이지만, 나중에 캐릭 머리 위 '주인 색점'을 그릴 때 쓰려고 미리 자리를 만든다.
public readonly record struct SM_MOVE(int PlayerId, float X, float Y, byte AuthorityServerId);
