// ── STEP 6 · Raylib 3D 관제 지휘관 뷰 — 전 월드 자유 이동(TPS) + 아무 칸이나 멀티홉 로켓 타격. ──
//    최종 월드: 플레이어는 30×30 전 세계를 제약 없이 걷는다(경계/이주 문제 없음).
//    9개 서버에 '직접' 붙어 모든 칸 몬스터가 보인다(고스트 경계 없이 = 관제 시야). 우상단 미니맵 = 전 월드.
//    조준(카메라 정면 소프트락) 후 좌클릭/Space → '내가 선 칸'에서 로켓 발사 → 서버들이 owner까지 멀티홉 중계 → 주인만 판정.

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Cols = 3, CellSize = 10, ClientPort0 = 9001, W = 1180, H = 760, DMG = 25;
const float WorldSize = Cols * CellSize;
Color[] ZC = { Color.DarkGreen, Color.Brown, Color.DarkBlue, Color.Maroon, Color.DarkGray, Color.Orange, Color.DarkPurple, Color.Green, Color.Blue };
int ZoneOf(float x, float y) => Math.Clamp((int)y / CellSize, 0, Cols - 1) * Cols + Math.Clamp((int)x / CellSize, 0, Cols - 1);
Vector2 ZoneCenter(int z) => new((z % Cols) * CellSize + 5, (z / Cols) * CellSize + 5);
int NextHop(int from, int owner)
{
    int fc = from % Cols, fr = from / Cols, oc = owner % Cols, orr = owner / Cols;
    if (fc != oc) return fr * Cols + (fc + Math.Sign(oc - fc));
    return (fr + Math.Sign(orr - fr)) * Cols + fc;
}
List<int> PathTo(int from, int owner) { var l = new List<int> { from }; int c = from, g = 0; while (c != owner && g++ < 12) { c = NextHop(c, owner); l.Add(c); } return l; }

var zones = new ZoneConn[9];
for (int z = 0; z < 9; z++) zones[z] = new ZoneConn { Zone = z };
var killEvents = new ConcurrentQueue<(int Id, Vector2 At, int Owner)>();
var cts = new CancellationTokenSource();
for (int zi = 0; zi < 9; zi++)
{
    int z = zi; var zc = zones[z];
    _ = Task.Run(async () =>
    {
        while (!cts.IsCancellationRequested)
        {
            try
            {
                using var cl = new TcpClient();
                await cl.ConnectAsync("127.0.0.1", ClientPort0 + z);
                var st = cl.GetStream(); zc.Stream = st; zc.Up = true;
                while (!cts.IsCancellationRequested)
                {
                    var (t, d) = await Framing.ReadFramedAsync(st, cts.Token);
                    if (t == PacketType.SM_MONSTER) { var m = Codec.Deserialize<SM_MOVE>(d); zc.Mon[m.PlayerId] = new Vector2(m.X, m.Y); Interlocked.Increment(ref zc.Pkt); }
                    else if (t == PacketType.SM_HP) { var h = Codec.Deserialize<HpMsg>(d); zc.Hp[h.Id] = (h.Hp, h.MaxHp); }
                    else if (t == PacketType.SM_KILL) { var m = Codec.Deserialize<SM_MOVE>(d); var at = zc.Mon.TryGetValue(m.PlayerId, out var p) ? p : ZoneCenter(z); zc.Mon.TryRemove(m.PlayerId, out _); zc.Hp.TryRemove(m.PlayerId, out _); killEvents.Enqueue((m.PlayerId, at, z)); }
                }
            }
            catch { }
            zc.Up = false; zc.Stream = null; zc.Mon.Clear(); zc.Hp.Clear();
            try { await Task.Delay(500, cts.Token); } catch { }
        }
    });
}
async Task StrikeFrom(int fromZone, int targetId)
{
    var zc = zones[fromZone]; var st = zc.Stream; if (st == null) return;
    await zc.SendLock.WaitAsync();
    try { await Framing.SendFramedAsync(st, PacketType.CM_ATTACK, Codec.Serialize(new AttackMsg(targetId, DMG))); } catch { } finally { zc.SendLock.Release(); }
}

InitWindow(W, H, "Seamless STEP 6 - Commander View (Free-roam + Multi-hop)");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);
DisableCursor();
var glyphSrc = string.Concat(
    "WASD 이동  |  마우스 시점  |  좌클릭/Space 발사(자동 조준)  |  ESC 커서",
    "관제 지휘관 뷰 — 전 월드 자유 이동 + 아무 칸이나 멀티홉 타격 (9개 서버 직접 접속)",
    "현재 내가 선 칸 수신 연결 대기중 게이트 없음",
    "타격 주인 사령부 홉 격추 판정 라우팅 성공 가 내 칸에서 로켓 발사 멀티홉으로 까지 중계",
    "미니맵 전 월드 정상 다운 몹 없음 여기 지금 위치",
    "· → — ↗ ()");   // 정보줄에 쓰는 기호들(가운뎃점·화살표)까지 포함 → '?' 방지
var cps = Enumerable.Range(32, 95).Concat(glyphSrc.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

var numTex = new Texture2D[9];
for (int i = 0; i < 9; i++)
{
    var img = GenImageColor(256, 256, new Color((byte)0, (byte)0, (byte)0, (byte)0));
    var txt = i.ToString(); var sz = MeasureTextEx(hud, txt, 190, 1); var tp = new Vector2(128 - sz.X / 2, 128 - sz.Y / 2);
    ImageDrawTextEx(ref img, hud, txt, tp + new Vector2(5, 5), 190, 1, new Color((byte)0, (byte)0, (byte)0, (byte)200));
    ImageDrawTextEx(ref img, hud, txt, tp, 190, 1, new Color((byte)255, (byte)255, (byte)255, (byte)255));
    numTex[i] = LoadTextureFromImage(img); UnloadImage(img);
}
var numMesh = GenMeshPlane(5f, 5f, 1, 1);
var numModels = new Model[9];
for (int i = 0; i < 9; i++) { numModels[i] = LoadModelFromMesh(numMesh); unsafe { numModels[i].Materials[0].Maps[(int)MaterialMapIndex.Albedo].Texture = numTex[i]; } }

var playerPos = new Vector2(15, 15);   // 전 월드 정중앙에서 시작
float yaw = 0f, pitch = 0.5f; bool captured = true; float cooldown = 0f;
var strikes = new List<Strike>(); var sparks = new List<Spark>(); var floaties = new List<Floaty>();
string info = "카메라 정면의 몬스터가 자동 조준된다. 좌클릭으로 발사 — 먼 칸도 멀티홉으로 날아간다.";
long[] pktSnap = new long[9]; double lastPktT = 0; int[] pps = new int[9];

while (!WindowShouldClose())
{
    float dt = GetFrameTime();
    if (captured) { var md = GetMouseDelta(); yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.1f, 1.4f); }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 9f * dt; }   // 전 월드 자유 이동
    playerPos = Vector2.Clamp(playerPos, new Vector2(0.3f), new Vector2(WorldSize - 0.3f));
    int curZone = ZoneOf(playerPos.X, playerPos.Y);

    double now = GetTime();
    if (now - lastPktT >= 0.5) { for (int z = 0; z < 9; z++) { long p = Interlocked.Read(ref zones[z].Pkt); pps[z] = (int)((p - pktSnap[z]) / (now - lastPktT)); pktSnap[z] = p; } lastPktT = now; }

    // ── 소프트락: 카메라 정면에 가장 가까운(각도) 몬스터. 전 월드라 사거리 넉넉히 ──
    int lockKey = -1, lockZone = -1; float bestScore = 0.5f; Vector2 lockPos = default;
    for (int z = 0; z < 9; z++) foreach (var kv in zones[z].Mon)
    {
        var to = kv.Value - playerPos; float dist = to.Length();
        if (dist > 50f || dist < 0.05f) continue;
        float score = Vector2.Dot(to / dist, fwd);
        if (score > bestScore) { bestScore = score; lockKey = kv.Key; lockZone = z; lockPos = kv.Value; }
    }

    if (cooldown > 0) cooldown -= dt;
    if ((IsMouseButtonPressed(MouseButton.Left) || IsKeyPressed(KeyboardKey.Space)) && lockKey != -1 && cooldown <= 0f)
    {
        _ = StrikeFrom(curZone, lockKey);
        var path = PathTo(curZone, lockZone);
        strikes.Add(new Strike { TargetId = lockKey, Owner = lockZone, Path = path, RocketPos = new Vector3(playerPos.X, 1.5f, playerPos.Y), LastXY = lockPos, Glow = 2.2f });
        info = curZone == lockZone
            ? $"타격 M{lockKey} — 내 칸(Z{curZone}) 소유, 라우팅 불필요"
            : $"타격 M{lockKey}(주인 Z{lockZone}) · 내 칸 Z{curZone}에서 발사 → {string.Join(" → ", path.ConvertAll(p => "Z" + p))}  ({path.Count - 1}홉)";
        cooldown = 0.30f;
    }

    // 로켓/경로
    foreach (var s in strikes)
    {
        Vector3 tp = zones[s.Owner].Mon.TryGetValue(s.TargetId, out var mp) ? new Vector3(mp.X, 0.6f, mp.Y) : new Vector3(s.LastXY.X, 0.6f, s.LastXY.Y);
        if (zones[s.Owner].Mon.TryGetValue(s.TargetId, out var mp2)) s.LastXY = mp2;
        if (!s.Landed) { var dir = tp - s.RocketPos; float dd = dir.Length(); float step = 26f * dt; if (dd <= step + 0.4f) { s.Landed = true; sparks.Add(new Spark { Pos = tp }); } else s.RocketPos += dir / dd * step; }
        s.Glow -= dt * 0.5f;
    }
    strikes.RemoveAll(s => s.Landed && s.Glow <= 0);
    foreach (var sp in sparks) sp.Age += dt; sparks.RemoveAll(sp => sp.Age > 0.4f);

    while (killEvents.TryDequeue(out var ke))
    {
        floaties.Add(new Floaty { Pos = new Vector3(ke.At.X, 2.2f, ke.At.Y), Text = "격추!", Col = new Color((byte)255, (byte)90, (byte)90, (byte)255), Life = 1.6f });
        info = $"격추! M{ke.Id} — 주인 Z{ke.Owner}가 판정 (멀티홉 라우팅 성공)";
    }
    foreach (var f in floaties) f.Age += dt; floaties.RemoveAll(f => f.Age > f.Life);

    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 11f;
    var cam = new Camera3D { Position = headP + offset, Target = headP, Up = new Vector3(0, 1, 0), FovY = 60f, Projection = CameraProjection.Perspective };

    BeginDrawing();
    ClearBackground(new Color((byte)22, (byte)26, (byte)36, (byte)255));
    BeginMode3D(cam);
    for (int r = 0; r < Cols; r++) for (int cc = 0; cc < Cols; cc++)
    {
        int zi = r * Cols + cc; var ctr = new Vector3(cc * CellSize + 5, 0, r * CellSize + 5);
        DrawPlane(ctr, new Vector2(CellSize - 0.2f, CellSize - 0.2f), zones[zi].Up ? ZC[zi] : new Color((byte)45, (byte)45, (byte)50, (byte)255));
        DrawModel(numModels[zi], new Vector3(ctr.X, 0.07f, ctr.Z), 1f, Color.White);
    }
    for (int i = 0; i <= Cols; i++)
    {
        DrawLine3D(new Vector3(i * CellSize, 0.05f, 0), new Vector3(i * CellSize, 0.05f, WorldSize), Color.White);
        DrawLine3D(new Vector3(0, 0.05f, i * CellSize), new Vector3(WorldSize, 0.05f, i * CellSize), Color.White);
    }
    // 멀티홉 빔 + 홉 노드
    foreach (var s in strikes)
    {
        byte a = (byte)(200 * Math.Clamp(s.Glow, 0, 1));
        for (int i = 0; i < s.Path.Count - 1; i++)
        {
            var c0 = ZoneCenter(s.Path[i]); var c1 = ZoneCenter(s.Path[i + 1]);
            DrawCylinderEx(new Vector3(c0.X, 0.4f, c0.Y), new Vector3(c1.X, 0.4f, c1.Y), 0.14f, 0.14f, 6, new Color((byte)255, (byte)190, (byte)50, a));
        }
        foreach (var z in s.Path) { var c = ZoneCenter(z); DrawSphere(new Vector3(c.X, 0.4f, c.Y), 0.28f, new Color((byte)255, (byte)210, (byte)80, a)); }
    }
    // 락온 링
    if (lockKey != -1) DrawCylinderWires(new Vector3(lockPos.X, 0.06f, lockPos.Y), 0.85f, 0.85f, 0.02f, 18, new Color((byte)255, (byte)230, (byte)40, (byte)255));
    // 플레이어
    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.RayWhite);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.18f, ZC[curZone]);
    // 모든 칸 몬스터 (owner 색)
    for (int z = 0; z < 9; z++) foreach (var kv in zones[z].Mon)
    {
        float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
        var p = new Vector3(kv.Value.X, 0.5f + bob, kv.Value.Y);
        DrawCube(p, 0.9f, 0.9f, 0.9f, ZC[z]); DrawCubeWires(p, 0.9f, 0.9f, 0.9f, Color.Black);
    }
    foreach (var s in strikes) if (!s.Landed) { DrawSphere(s.RocketPos, 0.18f, Color.Orange); DrawSphereWires(s.RocketPos, 0.3f, 6, 6, new Color((byte)255, (byte)180, (byte)60, (byte)160)); }
    foreach (var sp in sparks) { float rr = 0.3f + sp.Age * 3.5f; DrawSphereWires(sp.Pos, rr, 7, 7, new Color((byte)255, (byte)150, (byte)40, (byte)(int)(200 * (1 - sp.Age / 0.4f)))); }
    EndMode3D();

    // ── 2D: HP바 · 격추 숫자 · 크로스헤어 ──
    for (int z = 0; z < 9; z++) foreach (var kv in zones[z].Mon)
    {
        if (!zones[z].Hp.TryGetValue(kv.Key, out var h)) continue;
        var sp = GetWorldToScreen(new Vector3(kv.Value.X, 1.4f, kv.Value.Y), cam);
        if (sp.X < -40 || sp.X > W + 40 || sp.Y < -40 || sp.Y > H + 40) continue;
        float frac = Math.Clamp(h.Max <= 0 ? 0 : (float)h.Hp / h.Max, 0, 1);
        int bw = 44, bh = 6, bx = (int)sp.X - bw / 2, by = (int)sp.Y;
        DrawRectangle(bx - 1, by - 1, bw + 2, bh + 2, new Color((byte)0, (byte)0, (byte)0, (byte)170));
        DrawRectangle(bx, by, (int)(bw * frac), bh, ZC[z]);
        DrawTextEx(hud, $"M{kv.Key}", new Vector2(bx, by - 15), 13, 1, Color.White);
    }
    foreach (var f in floaties) { var sp = GetWorldToScreen(f.Pos + new Vector3(0, f.Age * 1.2f, 0), cam); byte al = (byte)(255 * Math.Clamp(1 - f.Age / f.Life, 0, 1)); DrawTextEx(hud, f.Text, new Vector2(sp.X - 14, sp.Y), 28, 1, new Color(f.Col.R, f.Col.G, f.Col.B, al)); }
    var cross = lockKey != -1 ? new Color((byte)255, (byte)230, (byte)40, (byte)255) : new Color((byte)255, (byte)255, (byte)255, (byte)180);
    DrawLine(W / 2 - 11, H / 2, W / 2 - 4, H / 2, cross); DrawLine(W / 2 + 4, H / 2, W / 2 + 11, H / 2, cross);
    DrawLine(W / 2, H / 2 - 11, W / 2, H / 2 - 4, cross); DrawLine(W / 2, H / 2 + 4, W / 2, H / 2 + 11, cross);
    DrawCircleLines(W / 2, H / 2, 3, cross);

    // ── 미니맵(전 월드) 우상단 ──
    int mm = 186, mx = W - mm - 14, my = 14; float sc = mm / (float)WorldSize; int upc = 0;
    DrawRectangle(mx - 6, my - 6, mm + 12, mm + 34, new Color((byte)10, (byte)12, (byte)18, (byte)210));
    DrawTextEx(hud, "전 월드 (관제)", new Vector2(mx, my - 4 + mm + 8), 15, 1, Color.White);
    for (int z = 0; z < 9; z++)
    {
        if (zones[z].Up) upc++;
        int cxp = (z % Cols) * (mm / Cols), cyp = (z / Cols) * (mm / Cols), cs = mm / Cols;
        DrawRectangle(mx + cxp, my + cyp, cs - 1, cs - 1, zones[z].Up ? new Color(ZC[z].R, ZC[z].G, ZC[z].B, (byte)200) : new Color((byte)50, (byte)50, (byte)56, (byte)220));
        if (!zones[z].Up) DrawTextEx(hud, "다운", new Vector2(mx + cxp + 8, my + cyp + 18), 14, 1, new Color((byte)240, (byte)90, (byte)90, (byte)255));
    }
    for (int z = 0; z < 9; z++) foreach (var kv in zones[z].Mon)
        DrawCircle(mx + (int)(kv.Value.X * sc), my + (int)(kv.Value.Y * sc), 2.6f, new Color((byte)255, (byte)80, (byte)80, (byte)255));
    // 플레이어 위치
    DrawCircle(mx + (int)(playerPos.X * sc), my + (int)(playerPos.Y * sc), 4f, Color.White);
    DrawCircleLines(mx + (int)(playerPos.X * sc), my + (int)(playerPos.Y * sc), 5f, Color.Black);
    DrawTextEx(hud, $"연결 {upc}/9", new Vector2(mx + mm - 66, my - 4 + mm + 8), 15, 1, new Color((byte)150, (byte)200, (byte)160, (byte)255));

    // ── HUD ──
    DrawRectangle(0, 0, W - 210, 92, new Color((byte)0, (byte)0, (byte)0, (byte)110));
    DrawTextEx(hud, "관제 지휘관 뷰 — 전 월드 자유 이동 + 아무 칸이나 멀티홉 타격 (9개 서버 직접 접속)", new Vector2(14, 12), 19, 1, Color.White);
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  좌클릭/Space 발사(자동 조준)  |  ESC 커서", new Vector2(14, 40), 17, 1, new Color((byte)180, (byte)200, (byte)230, (byte)255));
    DrawTextEx(hud, $"현재 내가 선 칸 Z{curZone}", new Vector2(14, 66), 18, 1, Color.Gold);
    DrawTextEx(hud, info, new Vector2(14, H - 30), 18, 1, new Color((byte)255, (byte)220, (byte)120, (byte)255));
    EndDrawing();
}

cts.Cancel();
CloseWindow();

sealed class ZoneConn
{
    public int Zone;
    public volatile bool Up;
    public volatile NetworkStream? Stream;
    public long Pkt;
    public readonly ConcurrentDictionary<int, Vector2> Mon = new();
    public readonly ConcurrentDictionary<int, (int Hp, int Max)> Hp = new();
    public readonly SemaphoreSlim SendLock = new(1, 1);
}
sealed class Strike { public int TargetId; public int Owner; public List<int> Path = new(); public Vector3 RocketPos; public Vector2 LastXY; public bool Landed; public float Glow; }
sealed class Spark { public Vector3 Pos; public float Age; }
sealed class Floaty { public Vector3 Pos; public string Text = ""; public Color Col; public float Age; public float Life = 1.0f; }
