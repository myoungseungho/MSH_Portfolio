// ── STEP 0 뷰어용 서버 — 단일 서버 + 몬스터 여러 마리. (뷰어가 직접 :9001에 접속) ──
//    STEP 0 구조 그대로: 네트워크는 큐에 넣기만, 틱 스레드가 world 갱신·방송. 뷰어를 위해 틱을 빠르게(20Hz).

using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int Port = 9001;
const int TickMs = 50;      // 20Hz (뷰어가 부드럽게)
const float WorldSize = 40; // 월드 0~40

var rng = new Random();
var inbox = new ConcurrentQueue<GameCmd>();
var world = new Dictionary<int, (float X, float Y)>();     // 플레이어 위치
var conns = new Dictionary<int, ClientConn>();

// 몬스터 6마리 — 퍼져서 배회 (0~40 안에서 벽 튕김)
var monsters = new Dictionary<int, (float X, float Y, float VX, float VY)>();
for (int i = 0; i < 6; i++)
{
    float ang = (float)(rng.NextDouble() * Math.PI * 2), spd = 3f; // 3 units/sec
    monsters[100 + i] = ((float)rng.NextDouble() * WorldSize, (float)rng.NextDouble() * WorldSize,
                         MathF.Cos(ang) * spd, MathF.Sin(ang) * spd);
}

var listener = new TcpListener(IPAddress.Loopback, Port);
listener.Start();
Console.WriteLine($"[S0] listen :{Port}, tick {TickMs}ms, 몬스터 {monsters.Count}마리, 월드 {WorldSize}");

int nextId = 1;
_ = Task.Run(async () =>
{
    while (true)
    {
        var tcp = await listener.AcceptTcpClientAsync();
        var conn = new ClientConn(nextId++, tcp);
        inbox.Enqueue(new GameCmd(CmdKind.Join, conn.PlayerId, conn, 0, 0));
        Console.WriteLine($"[S0] 뷰어 P{conn.PlayerId} 접속");
        _ = RecvLoopAsync(conn, inbox);
    }
});

float dt = TickMs / 1000f;
while (true)
{
    while (inbox.TryDequeue(out var cmd))
    {
        if (cmd.Kind == CmdKind.Join) { conns[cmd.PlayerId] = cmd.Conn!; world[cmd.PlayerId] = (WorldSize / 2, WorldSize / 2); }
        else if (cmd.Kind == CmdKind.Move && world.ContainsKey(cmd.PlayerId)) world[cmd.PlayerId] = (cmd.X, cmd.Y);
        else if (cmd.Kind == CmdKind.Leave) { conns.Remove(cmd.PlayerId); world.Remove(cmd.PlayerId); Console.WriteLine($"[S0] P{cmd.PlayerId} 퇴장"); }
    }

    // 몬스터 이동 (연속 시간 dt로, 벽 튕김)
    foreach (var id in monsters.Keys.ToList())
    {
        var m = monsters[id];
        float nx = m.X + m.VX * dt, ny = m.Y + m.VY * dt, vx = m.VX, vy = m.VY;
        if (nx < 0 || nx > WorldSize) { vx = -vx; nx = Math.Clamp(nx, 0, WorldSize); }
        if (ny < 0 || ny > WorldSize) { vy = -vy; ny = Math.Clamp(ny, 0, WorldSize); }
        monsters[id] = (nx, ny, vx, vy);
    }

    // 방송: 플레이어(본인 제외) + 몬스터
    foreach (var (id, pos) in world) { var sm = Codec.Serialize(new SM_MOVE(id, pos.X, pos.Y, 0)); foreach (var c in conns.Values) if (c.PlayerId != id) try { await c.SendAsync(PacketType.SM_MOVE, sm); } catch { } }
    foreach (var (id, mo) in monsters) { var sm = Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, 0)); foreach (var c in conns.Values) try { await c.SendAsync(PacketType.SM_MONSTER, sm); } catch { } }

    await Task.Delay(TickMs);
}

static async Task RecvLoopAsync(ClientConn conn, ConcurrentQueue<GameCmd> inbox)
{
    try { while (true) { var (type, data) = await Framing.ReadFramedAsync(conn.Stream); if (type == PacketType.CM_MOVE) { var m = Codec.Deserialize<CM_MOVE>(data); inbox.Enqueue(new GameCmd(CmdKind.Move, conn.PlayerId, null, m.X, m.Y)); } } }
    catch { } finally { inbox.Enqueue(new GameCmd(CmdKind.Leave, conn.PlayerId, null, 0, 0)); conn.Dispose(); }
}

enum CmdKind { Join, Move, Leave }
readonly record struct GameCmd(CmdKind Kind, int PlayerId, ClientConn? Conn, float X, float Y);

sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    public ClientConn(int id, TcpClient tcp) { PlayerId = id; _tcp = tcp; Stream = tcp.GetStream(); }
    public Task SendAsync(PacketType t, byte[] d) => Framing.SendFramedAsync(Stream, t, d);
    public void Dispose() => _tcp.Dispose();
}
