// ── STEP 3 · 클라 — 게이트에 붙어 존1로 걸어간 뒤, 경계(x≈10) 근처에 '서서' 옆 칸을 지켜본다.
//    STEP 2까진 지금 칸 것만 보였다. STEP 3에선 옆 칸(존0)의 몬스터가 '고스트(👻)'로 보여야 한다. ──

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int GatePort = 9000;

TcpClient client = new();
for (int a = 1; ; a++) { try { await client.ConnectAsync(IPAddress.Loopback, GatePort); break; } catch (SocketException) when (a < 30) { client.Dispose(); client = new(); await Task.Delay(150); } }
var stream = client.GetStream();
Console.WriteLine($"[C] 게이트(:{GatePort}) 접속");

var cts = new CancellationTokenSource();
var recv = RecvLoopAsync(stream, cts.Token);

// 존0 끝(x=9)까지 걸어간 뒤 → 존1 경계 근처(x=11)로 넘어가 '선다'
float[] path = { 5, 7, 9, 11, 11, 11, 11, 11, 11, 11 };  // 9→11에서 존0→존1, 이후 정지
float y = 5;
foreach (var x in path)
{
    await Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(x, y)));
    int zone = ((int)x / 10);
    Console.WriteLine($"[C] → 위치 ({x},{y})  [지금 zone {zone}]");
    await Task.Delay(700);
}
cts.Cancel(); client.Dispose();
Console.WriteLine("[C] 끝 — 존1에 서서 옆 칸(존0) 고스트를 봤는가?");

static async Task RecvLoopAsync(NetworkStream s, CancellationToken ct)
{
    try
    {
        while (!ct.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(s, ct);
            var m = Codec.Deserialize<SM_MOVE>(d);
            if (t == PacketType.SM_MOVE) Console.WriteLine($"[C]    👀 P{m.PlayerId} = ({m.X},{m.Y})");
            else if (t == PacketType.SM_MONSTER) Console.WriteLine($"[C]    🐺 M{m.PlayerId} = ({m.X},{m.Y})  [내 칸 zone {m.AuthorityServerId}]");
            else if (t == PacketType.SM_GHOST) Console.WriteLine($"[C]    👻 (고스트) M{m.PlayerId} = ({m.X},{m.Y})  [옆 칸 zone {m.AuthorityServerId}]");
        }
    }
    catch { }
}
