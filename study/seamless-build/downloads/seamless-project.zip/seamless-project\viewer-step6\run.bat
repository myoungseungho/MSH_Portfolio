@echo off
rem STEP 6: 9칸 존 서버(멀티홉 라우팅 + HP 방송) + 관제(God) 뷰. 게이트는 필요 없음(관제는 9개에 직접 접속).
rem 좌클릭으로 아무 칸 몬스터나 타격 → 사령부 Z0에서 로켓이 멀티홉으로 주인까지 날아가 격추.
rem 칸 하나를 창에서 닫으면(강제 킬) 대시보드에 '다운' → 다시 켜면 자동 복구.
cd /d "%~dp0"
rem 이전 실행에서 남은 좀비 정리
powershell -NoProfile -Command "Get-Process Seamless.Server,Seamless.Gate,Seamless.Viewer -EA SilentlyContinue | Stop-Process -Force -EA SilentlyContinue"
timeout /t 1 /nobreak >nul
for /L %%z in (0,1,8) do start "Zone%%z" dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
timeout /t 4 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
