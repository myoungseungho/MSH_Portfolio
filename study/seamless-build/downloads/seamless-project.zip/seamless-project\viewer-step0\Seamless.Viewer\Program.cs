// ── STEP 0 · Raylib 3D 뷰어 — 내가 조종하는 TPS 캡슐 + 몬스터 렌더 + '서버' 시각화. ──
//    몬스터는 이 PC가 아니라 '서버'가 만들어 매 틱(20Hz) 네트워크로 보내준다.
//    HUD에 서버 주소·수신율·하트비트를 띄워 "이건 로컬 게임이 아니라 서버-클라"임을 드러낸다.
//    서버 코드는 한 줄도 안 바꿨다. 이 파일은 "콘솔에 찍기"를 "3D로 그리기"로 바꾼 것뿐.

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Port = 9001, W = 1100, H = 720;
const float WorldSize = 40f;
long pktTotal = 0;   // 서버에서 받은 패킷 누적(수신율 계산용)

// ── 서버 접속 (STEP 0: 게이트 없이 서버에 직접) ──
var client = new TcpClient();
for (int a = 1; ; a++) { try { client.Connect("127.0.0.1", Port); break; } catch (SocketException) when (a < 60) { Thread.Sleep(150); } }
var stream = client.GetStream();
Console.WriteLine("[VIEWER] 서버 접속됨 — 창을 여는 중...");

var actors = new ConcurrentDictionary<int, Actor>();
var recvCts = new CancellationTokenSource();
_ = Task.Run(async () =>
{
    try
    {
        while (!recvCts.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(stream, recvCts.Token);
            var m = Codec.Deserialize<SM_MOVE>(d);
            var kind = t == PacketType.SM_MONSTER ? ActorKind.Monster : ActorKind.Player;
            actors.AddOrUpdate(m.PlayerId,
                _ => new Actor { Target = new Vector2(m.X, m.Y), Cur = new Vector2(m.X, m.Y), Kind = kind },
                (_, ac) => { ac.Target = new Vector2(m.X, m.Y); ac.Kind = kind; return ac; });
            Interlocked.Increment(ref pktTotal);
        }
    }
    catch { }
});

// ── 창/렌더 ──
InitWindow(W, H, "Seamless STEP 0 - 3D Viewer");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);   // ESC로 창이 닫히지 않게(ESC는 커서 토글). 종료는 창 X.
DisableCursor();

// 한글 폰트 로드(맑은 고딕) — raylib 기본 폰트엔 한글이 없어 깨진다. DrawTextEx로 그린다.
var koreanChars = "이동마우스시점커서몬스터마리서버가스폰여기선받아그림수신틱연결풀중배회위치내";
var cps = Enumerable.Range(32, 95).Concat(koreanChars.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

var playerPos = new Vector2(WorldSize / 2, WorldSize / 2);
float yaw = 0f, pitch = 0.5f;
bool captured = true;
float sendTimer = 0f;
Task lastSend = Task.CompletedTask;
long lastPktSnap = 0; double lastPktT = 0; int pktPerSec = 0;

while (!WindowShouldClose())
{
    float dt = GetFrameTime();

    // 마우스 시점
    if (captured)
    {
        var md = GetMouseDelta();
        yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.12f, 1.35f);
    }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    // WASD 이동 (카메라 방향 기준, XZ 평면)
    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 9f * dt; }
    playerPos = Vector2.Clamp(playerPos, Vector2.Zero, new Vector2(WorldSize, WorldSize));

    // 서버에 내 위치 보고 (~15Hz)
    sendTimer += dt;
    if (sendTimer > 0.066f && lastSend.IsCompleted)
    {
        sendTimer = 0f;
        try { lastSend = Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(playerPos.X, playerPos.Y))); } catch { }
    }

    // 수신율(pkt/s) 갱신
    double now = GetTime();
    if (now - lastPktT >= 0.5) { pktPerSec = (int)((pktTotal - lastPktSnap) / (now - lastPktT)); lastPktSnap = pktTotal; lastPktT = now; }

    // 몬스터 부드럽게 보간
    float kl = 1f - MathF.Exp(-12f * dt);
    foreach (var ac in actors.Values) ac.Cur = Vector2.Lerp(ac.Cur, ac.Target, kl);

    // 3인칭 카메라
    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 9f;
    var cam = new Camera3D { Position = headP + offset, Target = headP, Up = new Vector3(0, 1, 0), FovY = 55f, Projection = CameraProjection.Perspective };

    BeginDrawing();
    ClearBackground(Color.SkyBlue);
    BeginMode3D(cam);

    DrawPlane(new Vector3(WorldSize / 2, 0, WorldSize / 2), new Vector2(WorldSize, WorldSize), Color.DarkGreen);
    for (int i = 0; i <= (int)WorldSize; i += 4)
    {
        DrawLine3D(new Vector3(i, 0.02f, 0), new Vector3(i, 0.02f, WorldSize), Color.DarkGray);
        DrawLine3D(new Vector3(0, 0.02f, i), new Vector3(WorldSize, 0.02f, i), Color.DarkGray);
    }

    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.Blue);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.16f, Color.White);

    int monCount = 0;
    foreach (var kv in actors)
    {
        var ac = kv.Value;
        if (ac.Kind == ActorKind.Monster)
        {
            monCount++;
            float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
            var p = new Vector3(ac.Cur.X, 0.5f + bob, ac.Cur.Y);
            DrawCube(p, 1f, 1f, 1f, Color.Red);
            DrawCubeWires(p, 1f, 1f, 1f, Color.Maroon);
            DrawSphere(new Vector3(ac.Cur.X, 1.5f + bob, ac.Cur.Y), 0.12f, Color.White);
        }
        else DrawCapsule(new Vector3(ac.Cur.X, 0.5f, ac.Cur.Y), new Vector3(ac.Cur.X, 1.9f, ac.Cur.Y), 0.5f, 14, 8, Color.Green);
    }

    EndMode3D();

    // ── HUD (서버 시각화) ──
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  ESC 커서", new Vector2(14, 12), 22, 1, Color.Black);
    DrawTextEx(hud, $"몬스터 {monCount}마리 = 서버가 스폰·이동 (여기선 받아서 그림)", new Vector2(14, 44), 20, 1, Color.DarkBlue);
    DrawTextEx(hud, $"SERVER 127.0.0.1:9001   수신 {pktPerSec} pkt/s   틱 20Hz", new Vector2(14, 72), 20, 1, Color.Maroon);
    float pulse = 7f + 4f * MathF.Abs(MathF.Sin((float)GetTime() * 6f));
    DrawCircle(W - 34, 34, pulse, pktPerSec > 0 ? Color.Green : Color.Red);
    DrawTextEx(hud, "서버 연결", new Vector2(W - 150, 24), 18, 1, Color.DarkGreen);

    EndDrawing();
}

recvCts.Cancel();
try { client.Dispose(); } catch { }
CloseWindow();

enum ActorKind { Player, Monster }
sealed class Actor { public Vector2 Target; public Vector2 Cur; public ActorKind Kind; }
