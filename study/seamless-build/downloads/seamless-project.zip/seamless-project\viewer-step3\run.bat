@echo off
rem STEP 3: 9칸 존 서버(클라 9001~9009 / 피어 9101~9109, 서로 고스팅) + 게이트(9000) + 3D 뷰어.
cd /d "%~dp0"
for /L %%z in (0,1,8) do start "Zone%%z" /min dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
start "Gate" /min dotnet "Seamless.Gate\bin\Debug\net8.0\Seamless.Gate.dll"
timeout /t 4 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
