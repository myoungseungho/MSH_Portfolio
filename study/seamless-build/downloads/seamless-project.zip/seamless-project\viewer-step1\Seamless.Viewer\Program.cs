// ── STEP 1 · Raylib 3D 뷰어 — 9칸 존 색(체커보드) + 경계 넘으면 재접속(프리즈) + 옆 칸 텅 빔. ──
//    STEP 1엔 게이트가 없다. 뷰어가 자기 위치의 존 서버에 '직접' 접속하고, 칸을 넘으면 끊고 재접속한다.
//    각 존 서버는 자기 칸만 방송하므로, 지금 붙은 칸의 몬스터만 보인다(옆 칸은 텅 빔).

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Cols = 3, CellSize = 10, Port0 = 9001, W = 1100, H = 720;
const float WorldSize = Cols * CellSize;   // 30
int ZoneOf(float x, float y) => Math.Clamp((int)y / CellSize, 0, Cols - 1) * Cols + Math.Clamp((int)x / CellSize, 0, Cols - 1);

// 9칸 색 (존 = 담당 서버). 바닥·머리 위 점을 이 색으로 → "어느 서버가 담당인지"가 보인다.
Color[] ZC = { Color.DarkGreen, Color.Brown, Color.DarkBlue, Color.Maroon, Color.DarkGray, Color.Orange, Color.DarkPurple, Color.Green, Color.Blue };

var actors = new ConcurrentDictionary<int, Actor>();
long pktTotal = 0;
TcpClient? client = null; CancellationTokenSource? recvCts = null; NetworkStream? stream = null;
int curZone = -1;

void ConnectZone(int zone)
{
    recvCts?.Cancel();
    try { client?.Dispose(); } catch { }
    actors.Clear();                                 // 옆 칸 안 보임: 이전 존 액터가 즉시 사라진다
    var c = new TcpClient();
    for (int a = 1; ; a++) { try { c.Connect("127.0.0.1", Port0 + zone); break; } catch (SocketException) when (a < 50) { Thread.Sleep(80); } }
    client = c; stream = c.GetStream();
    var cts = new CancellationTokenSource(); recvCts = cts; var s = stream;
    _ = Task.Run(async () =>
    {
        try
        {
            while (!cts.IsCancellationRequested)
            {
                var (t, d) = await Framing.ReadFramedAsync(s, cts.Token);
                var m = Codec.Deserialize<SM_MOVE>(d);
                var kind = t == PacketType.SM_MONSTER ? ActorKind.Monster : ActorKind.Player;
                actors.AddOrUpdate(m.PlayerId,
                    _ => new Actor { Target = new(m.X, m.Y), Cur = new(m.X, m.Y), Kind = kind, Zone = m.AuthorityServerId },
                    (_, ac) => { ac.Target = new(m.X, m.Y); ac.Kind = kind; ac.Zone = m.AuthorityServerId; return ac; });
                Interlocked.Increment(ref pktTotal);
            }
        }
        catch { }
    });
    curZone = zone;
}

var playerPos = new Vector2(5, 5);   // 존 0에서 시작
ConnectZone(ZoneOf(playerPos.X, playerPos.Y));

InitWindow(W, H, "Seamless STEP 1 - Zone Viewer");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);
DisableCursor();
var koreanChars = "이동마우스시점커서존담당서버경계넘으면재접속프리즈옆칸텅빔지금수신틱마리몬스터연결현재위치";
var cps = Enumerable.Range(32, 95).Concat(koreanChars.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

// 존 번호를 '바닥에' 깔기: 번호 텍스처 9개 + 바닥에 눕힌 평면 모델 9개
var numTex = new Texture2D[9];
for (int i = 0; i < 9; i++)
{
    var img = GenImageColor(256, 256, new Color((byte)0, (byte)0, (byte)0, (byte)0));
    var txt = i.ToString();
    var sz = MeasureTextEx(hud, txt, 190, 1);
    var tp = new Vector2(128 - sz.X / 2, 128 - sz.Y / 2);
    ImageDrawTextEx(ref img, hud, txt, tp + new Vector2(5, 5), 190, 1, new Color((byte)0, (byte)0, (byte)0, (byte)200));   // 그림자(외곽선)
    ImageDrawTextEx(ref img, hud, txt, tp, 190, 1, new Color((byte)255, (byte)255, (byte)255, (byte)255));                 // 흰 숫자
    numTex[i] = LoadTextureFromImage(img);
    UnloadImage(img);
}
var numMesh = GenMeshPlane(5f, 5f, 1, 1);
var numModels = new Model[9];
for (int i = 0; i < 9; i++)
{
    numModels[i] = LoadModelFromMesh(numMesh);
    unsafe { numModels[i].Materials[0].Maps[(int)MaterialMapIndex.Albedo].Texture = numTex[i]; }   // 재질에 번호 텍스처
}

float yaw = 0f, pitch = 0.55f; bool captured = true; float sendTimer = 0f; Task lastSend = Task.CompletedTask;
long lastPktSnap = 0; double lastPktT = 0; int pktPerSec = 0; float reconnectFlash = 0f; int fromZone = 0;

while (!WindowShouldClose())
{
    float dt = GetFrameTime();
    if (captured) { var md = GetMouseDelta(); yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.12f, 1.35f); }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 7f * dt; }
    playerPos = Vector2.Clamp(playerPos, new Vector2(0.1f), new Vector2(WorldSize - 0.1f));

    // ★ 경계를 넘었으면 끊고 재접속 (프리즈)
    int z = ZoneOf(playerPos.X, playerPos.Y);
    if (z != curZone) { fromZone = curZone; reconnectFlash = 0.6f; ConnectZone(z); }
    if (reconnectFlash > 0) reconnectFlash -= dt;

    sendTimer += dt;
    if (sendTimer > 0.066f && lastSend.IsCompleted && stream != null)
    { sendTimer = 0f; try { lastSend = Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(playerPos.X, playerPos.Y))); } catch { } }

    double now = GetTime();
    if (now - lastPktT >= 0.5) { pktPerSec = (int)((pktTotal - lastPktSnap) / (now - lastPktT)); lastPktSnap = pktTotal; lastPktT = now; }

    float kl = 1f - MathF.Exp(-14f * dt);
    foreach (var ac in actors.Values) ac.Cur = Vector2.Lerp(ac.Cur, ac.Target, kl);

    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 9f;
    var cam = new Camera3D { Position = headP + offset, Target = headP, Up = new Vector3(0, 1, 0), FovY = 58f, Projection = CameraProjection.Perspective };

    BeginDrawing();
    ClearBackground(Color.SkyBlue);
    BeginMode3D(cam);

    // 9칸 바닥 (존 색) + 존 식별용 '깃발' 큐브
    for (int r = 0; r < Cols; r++) for (int cc = 0; cc < Cols; cc++)
    {
        int zi = r * Cols + cc;
        var center = new Vector3(cc * CellSize + CellSize / 2f, 0, r * CellSize + CellSize / 2f);
        DrawPlane(center, new Vector2(CellSize - 0.15f, CellSize - 0.15f), ZC[zi]);
        DrawModel(numModels[zi], new Vector3(center.X, 0.07f, center.Z), 1f, Color.White);   // 바닥에 존 번호
    }
    // 경계선(칸 사이) 흰색 강조
    for (int i = 0; i <= Cols; i++)
    {
        DrawLine3D(new Vector3(i * CellSize, 0.05f, 0), new Vector3(i * CellSize, 0.05f, WorldSize), Color.White);
        DrawLine3D(new Vector3(0, 0.05f, i * CellSize), new Vector3(WorldSize, 0.05f, i * CellSize), Color.White);
    }

    // 내 캐릭터 + 머리 위 점(현재 담당 존 색)
    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.RayWhite);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.18f, curZone >= 0 ? ZC[curZone] : Color.Gray);

    // 몬스터 (지금 붙은 칸 것만) — 머리 위 점 = 그 몬스터 주인 존 색
    int monCount = 0;
    foreach (var kv in actors)
    {
        var ac = kv.Value; if (ac.Kind != ActorKind.Monster) continue; monCount++;
        float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
        var p = new Vector3(ac.Cur.X, 0.5f + bob, ac.Cur.Y);
        DrawCube(p, 0.9f, 0.9f, 0.9f, Color.Red); DrawCubeWires(p, 0.9f, 0.9f, 0.9f, Color.Maroon);
        DrawSphere(new Vector3(ac.Cur.X, 1.4f + bob, ac.Cur.Y), 0.13f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);
    }

    EndMode3D();

    // HUD
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  ESC 커서", new Vector2(14, 12), 22, 1, Color.Black);
    DrawTextEx(hud, $"현재 담당 존: {(curZone >= 0 ? curZone : 0)}번 서버 (:{Port0 + Math.Max(curZone, 0)})   수신 {pktPerSec} pkt/s", new Vector2(14, 44), 20, 1, Color.Maroon);
    DrawTextEx(hud, $"몬스터 {monCount}마리 (지금 칸 것만 보임 = 옆 칸은 텅 빔)   위치 ({playerPos.X:0.0}, {playerPos.Y:0.0})", new Vector2(14, 72), 19, 1, Color.DarkBlue);
    // 담당 존 색 스와치
    DrawRectangle(W - 60, 20, 36, 36, curZone >= 0 ? ZC[curZone] : Color.Gray);
    DrawTextEx(hud, "담당 서버 색", new Vector2(W - 175, 60), 16, 1, Color.DarkGray);
    // 재접속(경계=벽) 배너
    if (reconnectFlash > 0)
    {
        DrawRectangle(0, H / 2 - 34, W, 68, new Color((byte)200, (byte)40, (byte)40, (byte)220));
        DrawTextEx(hud, $"⛔ 경계! 존 {fromZone} → {curZone} : 연결 끊고 재접속 (프리즈)", new Vector2(W / 2 - 260, H / 2 - 14), 26, 1, Color.White);
    }

    EndDrawing();
}

recvCts?.Cancel();
try { client?.Dispose(); } catch { }
CloseWindow();

enum ActorKind { Player, Monster }
sealed class Actor { public Vector2 Target; public Vector2 Cur; public ActorKind Kind; public int Zone; }
