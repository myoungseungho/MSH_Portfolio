// ── STEP 4 · Raylib 3D 뷰어 — 심리스 이주 + 히스테리시스: 경계를 '확실히' 넘어야 담당 서버가 바뀐다. ──
//    담당 서버(권한)는 서버가 내려주는 몬스터 패킷의 AuthorityServerId로 실시간 파악(= 진짜 백엔드).
//    경계에 노란 '여유 폭(dead band)'을 그린다. 그 안에서 진동해도 담당 서버는 안 바뀐다(이주 폭풍 방지).
//    화면의 세 카운터: [H=0이면 폭풍] vs [H=2면 잠잠] vs [실제 게이트 교체] — 대비가 한눈에.

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Cols = 3, CellSize = 10, GatePort = 9000, W = 1100, H = 720;
const float WorldSize = Cols * CellSize;
const int Hviz = 2;   // 뷰어가 그리는 여유 폭(권장 게이트 H와 동일)
int ZoneOf(float x, float y) => Math.Clamp((int)y / CellSize, 0, Cols - 1) * Cols + Math.Clamp((int)x / CellSize, 0, Cols - 1);
Color[] ZC = { Color.DarkGreen, Color.Brown, Color.DarkBlue, Color.Maroon, Color.DarkGray, Color.Orange, Color.DarkPurple, Color.Green, Color.Blue };

// 게이트와 똑같은 히스테리시스 규칙 (뷰어에서 'H=0이면/H=2면'을 계산해 대비 보여주기용)
int NextZone(int cur, float x, float y, int h)
{
    int nz = ZoneOf(x, y);
    if (nz == cur) return cur;
    int cc = cur % Cols, cr = cur / Cols, nc = nz % Cols, nr = nz / Cols;
    if (nr == cr) { if (nc == cc + 1) return x >= (cc + 1) * CellSize + h ? nz : cur; if (nc == cc - 1) return x <= cc * CellSize - h ? nz : cur; }
    if (nc == cc) { if (nr == cr + 1) return y >= (cr + 1) * CellSize + h ? nz : cur; if (nr == cr - 1) return y <= cr * CellSize - h ? nz : cur; }
    return nz;
}

// ── 게이트에 '한 번' 접속하고 그 연결을 끝까지 유지 ──
var client = new TcpClient();
for (int a = 1; ; a++) { try { client.Connect("127.0.0.1", GatePort); break; } catch (SocketException) when (a < 60) { Thread.Sleep(120); } }
var stream = client.GetStream();
Console.WriteLine("[VIEWER] 게이트 접속 — 연결 하나 유지");

var actors = new ConcurrentDictionary<int, Actor>();
int authZoneRecv = 0;     // 최근 SM_MONSTER의 주인 존 = 현재 진짜 백엔드
long pktTotal = 0;
var recvCts = new CancellationTokenSource();
_ = Task.Run(async () =>
{
    try
    {
        while (!recvCts.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(stream, recvCts.Token);
            var m = Codec.Deserialize<SM_MOVE>(d);
            var kind = t switch { PacketType.SM_MONSTER => ActorKind.Monster, PacketType.SM_GHOST => ActorKind.Ghost, _ => ActorKind.Player };
            if (kind == ActorKind.Monster) Volatile.Write(ref authZoneRecv, m.AuthorityServerId);  // 진짜 담당 서버
            int key = kind == ActorKind.Ghost ? 1_000_000 + m.PlayerId : m.PlayerId;
            actors.AddOrUpdate(key,
                _ => new Actor { Target = new(m.X, m.Y), Cur = new(m.X, m.Y), Kind = kind, Zone = m.AuthorityServerId, LastSeen = Environment.TickCount64 },
                (_, ac) => { ac.Target = new(m.X, m.Y); ac.Kind = kind; ac.Zone = m.AuthorityServerId; ac.LastSeen = Environment.TickCount64; return ac; });
            Interlocked.Increment(ref pktTotal);
        }
    }
    catch { }
});

InitWindow(W, H, "Seamless STEP 4 - Migration & Hysteresis");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);
DisableCursor();
var koreanChars = "이동마우스시점커서게이트연결담당서버물리적칸히스테리시스여유폭이주폭풍잠잠교체회경계넘었지만아직실제기준없다면있으면안전지대진동밴드권한전현재존위치번세계칸없음몬스터고스트옆수신확실히넘어야바뀐다여기선안했을";
var cps = Enumerable.Range(32, 95).Concat(koreanChars.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

var numTex = new Texture2D[9];
for (int i = 0; i < 9; i++)
{
    var img = GenImageColor(256, 256, new Color((byte)0, (byte)0, (byte)0, (byte)0));
    var txt = i.ToString(); var sz = MeasureTextEx(hud, txt, 190, 1); var tp = new Vector2(128 - sz.X / 2, 128 - sz.Y / 2);
    ImageDrawTextEx(ref img, hud, txt, tp + new Vector2(5, 5), 190, 1, new Color((byte)0, (byte)0, (byte)0, (byte)200));
    ImageDrawTextEx(ref img, hud, txt, tp, 190, 1, new Color((byte)255, (byte)255, (byte)255, (byte)255));
    numTex[i] = LoadTextureFromImage(img); UnloadImage(img);
}
var numMesh = GenMeshPlane(5f, 5f, 1, 1);
var numModels = new Model[9];
for (int i = 0; i < 9; i++) { numModels[i] = LoadModelFromMesh(numMesh); unsafe { numModels[i].Materials[0].Maps[(int)MaterialMapIndex.Albedo].Texture = numTex[i]; } }

var playerPos = new Vector2(5, 5);
float yaw = 0f, pitch = 0.55f; bool captured = true; float sendTimer = 0f; Task lastSend = Task.CompletedTask;
long lastPktSnap = 0; double lastPktT = 0; int pktPerSec = 0;

int authZone = 0, prevAuth = 0, realSwitches = 0;                       // 실제 게이트 기준 교체
int simZone0 = 0, stormSwitches = 0, simZone2 = 0, calmSwitches = 0;    // 로컬 시뮬 대비
float migFlash = 0f; int migFrom = 0, migTo = 0;
float stormPulse = 0f;                                                  // 폭풍 카운터가 방금 올랐을 때 강조

while (!WindowShouldClose())
{
    float dt = GetFrameTime();
    if (captured) { var md = GetMouseDelta(); yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.12f, 1.35f); }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 6f * dt; }
    playerPos = Vector2.Clamp(playerPos, new Vector2(0.1f), new Vector2(WorldSize - 0.1f));

    int geoZone = ZoneOf(playerPos.X, playerPos.Y);

    // 실제 담당 서버 (서버가 내려준 몬스터의 주인 존) — 진짜 백엔드 반영
    authZone = Volatile.Read(ref authZoneRecv);
    if (authZone != prevAuth) { realSwitches++; migFrom = prevAuth; migTo = authZone; migFlash = 1.2f; prevAuth = authZone; foreach (var k in actors.Keys.ToList()) actors.TryRemove(k, out _); }
    if (migFlash > 0) migFlash -= dt;

    // 로컬 시뮬: 같은 경로를 H=0 / H=2 게이트에 태웠다면 교체가 몇 번?
    int n0 = NextZone(simZone0, playerPos.X, playerPos.Y, 0);    if (n0 != simZone0) { simZone0 = n0; stormSwitches++; stormPulse = 0.5f; }
    int n2 = NextZone(simZone2, playerPos.X, playerPos.Y, Hviz); if (n2 != simZone2) { simZone2 = n2; calmSwitches++; }
    if (stormPulse > 0) stormPulse -= dt;

    sendTimer += dt;
    if (sendTimer > 0.05f && lastSend.IsCompleted)
    { sendTimer = 0f; try { lastSend = Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(playerPos.X, playerPos.Y))); } catch { } }

    double now = GetTime();
    if (now - lastPktT >= 0.5) { pktPerSec = (int)((pktTotal - lastPktSnap) / (now - lastPktT)); lastPktSnap = pktTotal; lastPktT = now; }

    long nowMs = Environment.TickCount64;
    foreach (var k in actors.Where(kv => nowMs - kv.Value.LastSeen > 400).Select(kv => kv.Key).ToList()) actors.TryRemove(k, out _);
    float kl = 1f - MathF.Exp(-14f * dt);
    foreach (var ac in actors.Values) ac.Cur = Vector2.Lerp(ac.Cur, ac.Target, kl);

    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 9f;
    var cam = new Camera3D { Position = headP + offset, Target = headP, Up = new Vector3(0, 1, 0), FovY = 58f, Projection = CameraProjection.Perspective };

    BeginDrawing();
    ClearBackground(Color.SkyBlue);
    BeginMode3D(cam);
    for (int r = 0; r < Cols; r++) for (int cc = 0; cc < Cols; cc++)
    {
        int zi = r * Cols + cc;
        var center = new Vector3(cc * CellSize + CellSize / 2f, 0, r * CellSize + CellSize / 2f);
        DrawPlane(center, new Vector2(CellSize - 0.15f, CellSize - 0.15f), ZC[zi]);
        DrawModel(numModels[zi], new Vector3(center.X, 0.07f, center.Z), 1f, Color.White);
    }
    // 히스테리시스 여유 폭(dead band) — 노란 반투명 띠. 이 안에서 진동해도 담당 서버 안 바뀜.
    var band = new Color((byte)255, (byte)225, (byte)70, (byte)70);
    for (int b = 1; b < Cols; b++)
    {
        float bx = b * CellSize, by = b * CellSize;
        DrawCube(new Vector3(bx, 0.09f, WorldSize / 2f), Hviz * 2f, 0.02f, WorldSize, band);          // 세로 경계 띠
        DrawCube(new Vector3(WorldSize / 2f, 0.09f, by), WorldSize, 0.02f, Hviz * 2f, band);          // 가로 경계 띠
    }
    for (int i = 0; i <= Cols; i++)
    {
        DrawLine3D(new Vector3(i * CellSize, 0.05f, 0), new Vector3(i * CellSize, 0.05f, WorldSize), Color.White);
        DrawLine3D(new Vector3(0, 0.05f, i * CellSize), new Vector3(WorldSize, 0.05f, i * CellSize), Color.White);
    }

    // 내 발밑 원반 = 물리적 칸 색 / 머리 위 점 = 담당 서버 색 (둘이 다르면 = 여유 폭 안)
    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCylinder(new Vector3(playerPos.X, 0.10f, playerPos.Y), 0.9f, 0.9f, 0.03f, 20, new Color(ZC[geoZone].R, ZC[geoZone].G, ZC[geoZone].B, (byte)160));
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.RayWhite);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.20f, ZC[authZone]);   // 담당 서버 색

    int monCount = 0, ghostCount = 0;
    foreach (var kv in actors)
    {
        var ac = kv.Value;
        if (ac.Kind == ActorKind.Monster)
        {
            monCount++;
            float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
            var p = new Vector3(ac.Cur.X, 0.5f + bob, ac.Cur.Y);
            DrawCube(p, 0.9f, 0.9f, 0.9f, Color.Red); DrawCubeWires(p, 0.9f, 0.9f, 0.9f, Color.Maroon);
            DrawSphere(new Vector3(ac.Cur.X, 1.4f + bob, ac.Cur.Y), 0.13f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);
        }
        else if (ac.Kind == ActorKind.Ghost)
        {
            ghostCount++;
            var p = new Vector3(ac.Cur.X, 0.5f, ac.Cur.Y);
            DrawCube(p, 0.9f, 0.9f, 0.9f, new Color((byte)200, (byte)210, (byte)255, (byte)90));
            DrawCubeWires(p, 0.9f, 0.9f, 0.9f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);
        }
    }
    EndMode3D();

    // ── HUD ──
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  ESC 커서", new Vector2(14, 12), 22, 1, Color.Black);
    DrawTextEx(hud, $"물리적 칸 {geoZone}번    담당 서버 {authZone}번    수신 {pktPerSec} pkt/s", new Vector2(14, 44), 20, 1, Color.Maroon);
    if (geoZone != authZone)
        DrawTextEx(hud, "경계를 넘었지만 담당 서버는 아직 그대로 — 여유 폭(히스테리시스) 안!", new Vector2(14, 72), 19, 1, new Color((byte)20, (byte)120, (byte)40, (byte)255));
    else
        DrawTextEx(hud, "노란 띠 = 여유 폭. 이 안에서 왔다갔다 해도 담당 서버는 안 바뀐다.", new Vector2(14, 72), 19, 1, Color.DarkBlue);

    // 세 카운터 대비 (우측 상단)
    int bx0 = W - 372, by0 = 12;
    DrawRectangle(bx0, by0, 360, 116, new Color((byte)0, (byte)0, (byte)0, (byte)120));
    var stormCol = stormPulse > 0 ? new Color((byte)255, (byte)90, (byte)90, (byte)255) : new Color((byte)235, (byte)120, (byte)120, (byte)255);
    DrawTextEx(hud, $"H=0 이면 (여유 폭 없음): 교체 {stormSwitches}회", new Vector2(bx0 + 12, by0 + 10), 19, 1, stormCol);
    DrawTextEx(hud, "  경계에서 진동하면 폭발 = 이주 폭풍", new Vector2(bx0 + 12, by0 + 33), 15, 1, new Color((byte)235, (byte)150, (byte)150, (byte)255));
    DrawTextEx(hud, $"H={Hviz} 이면 (있음): 교체 {calmSwitches}회", new Vector2(bx0 + 12, by0 + 56), 19, 1, new Color((byte)120, (byte)235, (byte)140, (byte)255));
    DrawTextEx(hud, $"실제 게이트 교체 {realSwitches}회 (서버 기준)", new Vector2(bx0 + 12, by0 + 84), 19, 1, Color.White);

    if (migFlash > 0)
    {
        DrawRectangle(0, H / 2 - 34, W, 68, new Color((byte)30, (byte)140, (byte)60, (byte)210));
        DrawTextEx(hud, $"이주! 담당 서버 {migFrom} → {migTo}  (권한 이전 — 확실히 넘었을 때만)", new Vector2(W / 2 - 320, H / 2 - 14), 24, 1, Color.White);
    }
    EndDrawing();
}

recvCts.Cancel();
try { client.Dispose(); } catch { }
CloseWindow();

enum ActorKind { Player, Monster, Ghost }
sealed class Actor { public Vector2 Target; public Vector2 Cur; public ActorKind Kind; public int Zone; public long LastSeen; }
