# STEP 3 — 고스팅: 이웃이 보인다 (★첫 마법)

이 스냅샷 = 서버들이 **서로 통신**해, 경계 부근 액터를 이웃에 **고스트(읽기전용 복사본)**로 흘린다. 옆 칸이 보인다 → 세계가 하나로 붙는다.

## ✅ 되는 것
- 각 서버가 클라용 포트(9001+z)와 **피어용 포트(9101+z)** 둘 다 listen + 이웃에게 connect (서버가 listen·connect 둘 다)
- 매 틱, 내 '경계 폭 N=3' 안의 액터를 이웃에게 push
- 받은 고스트를 내 클라들에게 **SM_GHOST**로 함께 방송
- 클라: 👀 플레이어 / 🐺 내 칸 몬스터 / **👻 옆 칸 고스트**

## 실제 로그(핵심)
```
[C] → 위치 (11,5) [지금 zone 1]
[C]    🐺 M101 = (17,5) [내 칸 zone 1]
[C]    👻 (고스트) M100 = (7,5) [옆 칸 zone 0]   ← 옆 칸 몬스터가 보인다!
```

## ❌ 안 되는 것 (= 다음 스텝)
- **고스트는 읽기전용** — 때려도 무반응(그 액터의 주인은 이웃 서버라 판정을 못 함) → STEP 5 위치 투명 라우팅
- **경계 통과 순간 여전히 어색** — 넘는 순간 아바타가 원 서버에 잠깐 남아 고스트로 뜨는 등 → STEP 4 심리스 이주

## 구조 요점
- 피어 토폴로지: 각 서버가 4방향 이웃의 피어 포트에 connect해 '내 경계 액터 push' 전용 통로를 만듦. 받는 건 별도 listen.
- 단일 스레드 유지: 게임 상태(world·ghosts)는 틱 스레드 전용. 피어 입출력은 큐(ghostInbox) + ConcurrentDictionary(peerOut)로 handoff.
- 고스트 TTL: 2틱 이상 갱신 안 되면 제거(이웃이 매 틱 push하므로, 멀어지면 자동 소멸).

## 실행 (9존 + 게이트 + 클라)
```
for z in 0..8: dotnet run --project Seamless.Server -- $z    # client:9001+z, peer:9101+z
dotnet run --project Seamless.Gate
dotnet run --project Seamless.Client                          # 존1로 걸어가 경계에 서서 옆 칸 고스트 확인
```

복습: `INTERVIEW.md`.
