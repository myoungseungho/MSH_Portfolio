// ── STEP 3 · 고스팅 — 서버들이 서로 통신해, 경계 부근 액터를 이웃에 '고스트(읽기전용 복사본)'로 흘린다. ──
//    각 서버는 (1) 클라용 포트(9001+z)로 listen (2) 피어용 포트(9101+z)로도 listen (이웃의 고스트를 받음)
//    (3) 이웃의 피어 포트로 connect (내 경계 액터를 보냄). = "서버는 listen과 connect 둘 다 한다".
//    받은 고스트는 내 클라들에게 SM_GHOST로 함께 방송 → 클라는 옆 칸이 보인다.

using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, ClientPort0 = 9001, PeerPort0 = 9101, TickMs = 500, N = 3; // N = 경계 폭
int zoneIdx = args.Length > 0 ? int.Parse(args[0]) : 0;
int col = zoneIdx % Cols, row = zoneIdx / Cols;
float zx0 = col * CellSize, zy0 = row * CellSize;

// 4방향 이웃
var neighbors = new List<int>();
if (col > 0) neighbors.Add(zoneIdx - 1);
if (col < Cols - 1) neighbors.Add(zoneIdx + 1);
if (row > 0) neighbors.Add(zoneIdx - Cols);
if (row < Cols - 1) neighbors.Add(zoneIdx + Cols);

var inbox = new ConcurrentQueue<GameCmd>();
var ghostInbox = new ConcurrentQueue<Ghost>();                 // 이웃이 보낸 고스트가 들어오는 곳
var peerOut = new ConcurrentDictionary<int, NetworkStream>();  // 이웃 zone → 그 이웃에게 push하는 통로
var world = new Dictionary<int, (float X, float Y)>();
var conns = new Dictionary<int, ClientConn>();
var monsters = new Dictionary<int, (float X, float Y, float VX, float VY)> { [100 + zoneIdx] = (zx0 + 5, zy0 + 5, 1, 0) };
var ghosts = new Dictionary<int, (float X, float Y, int Src, long Tick)>();   // 틱 스레드 전용

// 이 칸의 특정 위치가 이웃 nb와의 '경계 폭 N' 안인가?
bool NearBoundary(float x, float y, int nb)
{
    if (nb == zoneIdx + 1) return x >= zx0 + CellSize - N;       // 오른쪽 이웃
    if (nb == zoneIdx - 1) return x < zx0 + N;                   // 왼쪽
    if (nb == zoneIdx + Cols) return y >= zy0 + CellSize - N;    // 위
    if (nb == zoneIdx - Cols) return y < zy0 + N;                // 아래
    return false;
}

// 클라용 listen
var listener = new TcpListener(IPAddress.Loopback, ClientPort0 + zoneIdx); listener.Start();
// 피어용 listen (이웃의 고스트 push를 받음)
var peerListener = new TcpListener(IPAddress.Loopback, PeerPort0 + zoneIdx); peerListener.Start();
Console.WriteLine($"[Z{zoneIdx}] client:{ClientPort0 + zoneIdx} peer:{PeerPort0 + zoneIdx} 이웃={string.Join(",", neighbors)}");

int nextId = 1;
_ = Task.Run(async () => { while (true) { var tcp = await listener.AcceptTcpClientAsync(); var conn = new ClientConn(zoneIdx * 100 + nextId++, tcp); inbox.Enqueue(new GameCmd(CmdKind.Join, conn.PlayerId, conn, 0, 0)); _ = ClientRecvAsync(conn, inbox); } });
_ = Task.Run(async () => { while (true) { var pc = await peerListener.AcceptTcpClientAsync(); _ = PeerRecvAsync(pc, ghostInbox); } });
// 이웃에게 connect (내 경계 액터를 push할 통로)
foreach (var nb in neighbors) _ = Task.Run(async () => { var s = await ConnectPeer(PeerPort0 + nb); peerOut[nb] = s; });

long tick = 0;
while (true)
{
    tick++;
    while (inbox.TryDequeue(out var cmd))
    {
        if (cmd.Kind == CmdKind.Join) { conns[cmd.PlayerId] = cmd.Conn!; world[cmd.PlayerId] = (zx0 + 1, zy0 + 1); }
        else if (cmd.Kind == CmdKind.Move && world.ContainsKey(cmd.PlayerId)) world[cmd.PlayerId] = (cmd.X, cmd.Y);
        else if (cmd.Kind == CmdKind.Leave) { conns.Remove(cmd.PlayerId); world.Remove(cmd.PlayerId); }
    }
    while (ghostInbox.TryDequeue(out var g)) ghosts[g.Id] = (g.X, g.Y, g.Src, tick);   // 이웃 고스트 갱신
    foreach (var k in ghosts.Where(kv => tick - kv.Value.Tick > 2).Select(kv => kv.Key).ToList()) ghosts.Remove(k); // 오래된 고스트 제거

    // 몬스터 이동 (이 칸 안에서)
    foreach (var id in monsters.Keys.ToList()) { var mo = monsters[id]; float vx = mo.VX, nx = mo.X + vx; if (nx < zx0 || nx >= zx0 + CellSize) { vx = -vx; nx = mo.X + vx; } monsters[id] = (nx, mo.Y, vx, mo.VY); }

    // ★ 내 경계 액터를 이웃에게 고스트로 push
    foreach (var nb in neighbors)
    {
        if (!peerOut.TryGetValue(nb, out var ps)) continue;
        foreach (var (id, mo) in monsters) if (NearBoundary(mo.X, mo.Y, nb)) try { await Framing.SendFramedAsync(ps, PacketType.SM_MOVE, Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, (byte)zoneIdx))); } catch { }
        foreach (var (id, p) in world) if (NearBoundary(p.X, p.Y, nb)) try { await Framing.SendFramedAsync(ps, PacketType.SM_MOVE, Codec.Serialize(new SM_MOVE(id, p.X, p.Y, (byte)zoneIdx))); } catch { }
    }

    // 방송: 내 플레이어 + 내 몬스터 + 이웃 고스트
    foreach (var (id, pos) in world) { var sm = Codec.Serialize(new SM_MOVE(id, pos.X, pos.Y, (byte)zoneIdx)); foreach (var c in conns.Values) if (c.PlayerId != id) try { await c.SendAsync(PacketType.SM_MOVE, sm); } catch { } }
    foreach (var (id, mo) in monsters) { var sm = Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, (byte)zoneIdx)); foreach (var c in conns.Values) try { await c.SendAsync(PacketType.SM_MONSTER, sm); } catch { } }
    foreach (var (id, g) in ghosts) { var sm = Codec.Serialize(new SM_MOVE(id, g.X, g.Y, (byte)g.Src)); foreach (var c in conns.Values) try { await c.SendAsync(PacketType.SM_GHOST, sm); } catch { } }

    if (tick % 4 == 1) Console.WriteLine($"[Z{zoneIdx}] tick #{tick} | {conns.Count}명 | 몬스터 {monsters.Count} | 고스트 {ghosts.Count}");
    await Task.Delay(TickMs);
}

static async Task ClientRecvAsync(ClientConn conn, ConcurrentQueue<GameCmd> inbox)
{
    try { while (true) { var (type, data) = await Framing.ReadFramedAsync(conn.Stream); if (type == PacketType.CM_MOVE) { var m = Codec.Deserialize<CM_MOVE>(data); inbox.Enqueue(new GameCmd(CmdKind.Move, conn.PlayerId, null, m.X, m.Y)); } } }
    catch { } finally { inbox.Enqueue(new GameCmd(CmdKind.Leave, conn.PlayerId, null, 0, 0)); conn.Dispose(); }
}
static async Task PeerRecvAsync(TcpClient pc, ConcurrentQueue<Ghost> gi)
{
    try { using var s = pc.GetStream(); while (true) { var (_, d) = await Framing.ReadFramedAsync(s); var m = Codec.Deserialize<SM_MOVE>(d); gi.Enqueue(new Ghost(m.PlayerId, m.X, m.Y, m.AuthorityServerId)); } }
    catch { }
}
static async Task<NetworkStream> ConnectPeer(int port)
{
    for (int a = 1; ; a++) { var c = new TcpClient(); try { await c.ConnectAsync(IPAddress.Loopback, port); return c.GetStream(); } catch (SocketException) when (a < 40) { c.Dispose(); await Task.Delay(150); } }
}

enum CmdKind { Join, Move, Leave }
readonly record struct GameCmd(CmdKind Kind, int PlayerId, ClientConn? Conn, float X, float Y);
readonly record struct Ghost(int Id, float X, float Y, int Src);

sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    public ClientConn(int id, TcpClient tcp) { PlayerId = id; _tcp = tcp; Stream = tcp.GetStream(); }
    public Task SendAsync(PacketType t, byte[] d) => Framing.SendFramedAsync(Stream, t, d);
    public void Dispose() => _tcp.Dispose();
}
