@echo off
rem STEP 4: 9칸 존 서버 + 게이트(히스테리시스 H=2, 잠잠) + 3D 뷰어.
rem 경계 노란 띠(여유 폭) 안에서 왔다갔다 해도 담당 서버가 안 바뀐다 → 이주 폭풍 없음.
cd /d "%~dp0"
for /L %%z in (0,1,8) do start "Zone%%z" /min dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
start "Gate H=2" /min dotnet "Seamless.Gate\bin\Debug\net8.0\Seamless.Gate.dll" 2
timeout /t 4 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
