// ── STEP 4 · 심리스 이주 — 게이트에 '히스테리시스'를 넣어 '이주 폭풍(진동)'을 막는다. ──
//    STEP 2 게이트는 경계를 넘으면 바로 백엔드를 바꿨다. 그런데 경계에 딱 걸쳐 왔다갔다 하면
//    매번 서버가 갈아타는 '이주 폭풍'이 난다. 온도조절기처럼 '넘는 기준'과 '되돌아오는 기준'에
//    여유 폭(H)을 두면, 확실히 넘어갔을 때만 교체해서 잠잠해진다.
//    실행 인자로 H를 받는다: 0 = 히스테리시스 없음(폭풍), 2 = 있음(잠잠).

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, GatePort = 9000, ZonePort0 = 9001;
int H = args.Length > 0 ? int.Parse(args[0]) : 2;   // 히스테리시스 폭 (0이면 없음)
int ZoneOf(float x, float y) => ((int)y / CellSize) * Cols + ((int)x / CellSize);

// 현재 칸(cur)에서, 위치가 '경계를 H만큼 확실히 넘었을 때만' 새 칸을 반환. 아니면 cur 유지(dead band).
int NextZone(int cur, float x, float y)
{
    int nz = ZoneOf(x, y);
    if (nz == cur) return cur;
    int cc = cur % Cols, cr = cur / Cols, nc = nz % Cols, nr = nz / Cols;
    if (nr == cr) {   // 좌우 이동
        if (nc == cc + 1) return x >= (cc + 1) * CellSize + H ? nz : cur;   // 오른쪽으로 H 이상 넘어야
        if (nc == cc - 1) return x <= cc * CellSize - H ? nz : cur;         // 왼쪽으로 H 이상 넘어야
    }
    if (nc == cc) {   // 상하 이동
        if (nr == cr + 1) return y >= (cr + 1) * CellSize + H ? nz : cur;
        if (nr == cr - 1) return y <= cr * CellSize - H ? nz : cur;
    }
    return nz;   // 대각선/원거리는 그냥 교체
}

var listener = new TcpListener(IPAddress.Loopback, GatePort);
listener.Start();
Console.WriteLine($"[GATE] listen :{GatePort}  히스테리시스 H={H} {(H == 0 ? "(없음 → 폭풍 예상)" : "(있음 → 잠잠 예상)")}");

int nextId = 1;
while (true)
{
    var client = await listener.AcceptTcpClientAsync();
    int cid = nextId++;
    _ = HandleClientAsync(client, cid, NextZone, ZonePort0);
}

static async Task HandleClientAsync(TcpClient client, int cid, Func<int, float, float, int> NextZone, int zonePort0)
{
    NetworkStream cli = client.GetStream();
    int zone = 0, switches = 0;
    TcpClient backend = await ConnectBackend(zonePort0 + zone);
    var downCts = new CancellationTokenSource();
    _ = Pump(backend.GetStream(), cli, downCts.Token);
    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(cli);
            if (type == PacketType.CM_MOVE)
            {
                var m = Codec.Deserialize<CM_MOVE>(data);
                int nz = NextZone(zone, m.X, m.Y);
                if (nz != zone)
                {
                    switches++;
                    Console.WriteLine($"[GATE] C{cid} 이주! zone {zone} → {nz} (위치 {m.X})  [누적 교체 {switches}회]");
                    downCts.Cancel(); backend.Dispose();
                    zone = nz;
                    backend = await ConnectBackend(zonePort0 + zone);
                    downCts = new CancellationTokenSource();
                    _ = Pump(backend.GetStream(), cli, downCts.Token);
                }
                await Framing.SendFramedAsync(backend.GetStream(), type, data);
            }
        }
    }
    catch { }
    finally { downCts.Cancel(); backend.Dispose(); client.Dispose(); Console.WriteLine($"[GATE] C{cid} 종료 — 총 백엔드 교체 {switches}회"); }
}

static async Task Pump(NetworkStream from, NetworkStream to, CancellationToken ct)
{
    try { while (!ct.IsCancellationRequested) { var (t, d) = await Framing.ReadFramedAsync(from, ct); await Framing.SendFramedAsync(to, t, d, ct); } } catch { }
}
static async Task<TcpClient> ConnectBackend(int port)
{
    for (int a = 1; ; a++) { var c = new TcpClient(); try { await c.ConnectAsync(IPAddress.Loopback, port); return c; } catch (SocketException) when (a < 30) { c.Dispose(); await Task.Delay(150); } }
}
