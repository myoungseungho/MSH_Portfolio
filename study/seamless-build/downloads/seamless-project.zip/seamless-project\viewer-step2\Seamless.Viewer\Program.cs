// ── STEP 2 · Raylib 3D 뷰어 — 게이트(:9000)에 '연결 1개'로 끝까지. 재접속 없음. ──
//    STEP 1은 경계 넘을 때마다 끊고 재접속(프리즈)했다. STEP 2는 게이트가 뒤에서 담당 서버를 몰래 바꾼다.
//    그래서 클라(뷰어)는 게이트 연결 하나를 계속 유지 — 존 색은 바뀌지만 '재접속'은 안 한다.

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Cols = 3, CellSize = 10, GatePort = 9000, W = 1100, H = 720;
const float WorldSize = Cols * CellSize;
int ZoneOf(float x, float y) => Math.Clamp((int)y / CellSize, 0, Cols - 1) * Cols + Math.Clamp((int)x / CellSize, 0, Cols - 1);
Color[] ZC = { Color.DarkGreen, Color.Brown, Color.DarkBlue, Color.Maroon, Color.DarkGray, Color.Orange, Color.DarkPurple, Color.Green, Color.Blue };

// ── 게이트에 '한 번' 접속하고 그 연결을 끝까지 유지 ──
var client = new TcpClient();
for (int a = 1; ; a++) { try { client.Connect("127.0.0.1", GatePort); break; } catch (SocketException) when (a < 60) { Thread.Sleep(120); } }
var stream = client.GetStream();
Console.WriteLine("[VIEWER] 게이트 접속 — 이 연결 하나로 끝까지 (재접속 없음)");

var actors = new ConcurrentDictionary<int, Actor>();
long pktTotal = 0;
var recvCts = new CancellationTokenSource();
_ = Task.Run(async () =>
{
    try
    {
        while (!recvCts.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(stream, recvCts.Token);
            var m = Codec.Deserialize<SM_MOVE>(d);
            var kind = t == PacketType.SM_MONSTER ? ActorKind.Monster : ActorKind.Player;
            actors.AddOrUpdate(m.PlayerId,
                _ => new Actor { Target = new(m.X, m.Y), Cur = new(m.X, m.Y), Kind = kind, Zone = m.AuthorityServerId },
                (_, ac) => { ac.Target = new(m.X, m.Y); ac.Kind = kind; ac.Zone = m.AuthorityServerId; return ac; });
            Interlocked.Increment(ref pktTotal);
        }
    }
    catch { }
});

InitWindow(W, H, "Seamless STEP 2 - Gate Viewer");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);
DisableCursor();
var koreanChars = "이동마우스시점커서게이트연결개유지재접속회담당서버몰래교체옆칸텅빔수신틱마리몬스터현재존위치번";
var cps = Enumerable.Range(32, 95).Concat(koreanChars.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

// 바닥 존 번호 (STEP 1과 동일)
var numTex = new Texture2D[9];
for (int i = 0; i < 9; i++)
{
    var img = GenImageColor(256, 256, new Color((byte)0, (byte)0, (byte)0, (byte)0));
    var txt = i.ToString(); var sz = MeasureTextEx(hud, txt, 190, 1); var tp = new Vector2(128 - sz.X / 2, 128 - sz.Y / 2);
    ImageDrawTextEx(ref img, hud, txt, tp + new Vector2(5, 5), 190, 1, new Color((byte)0, (byte)0, (byte)0, (byte)200));
    ImageDrawTextEx(ref img, hud, txt, tp, 190, 1, new Color((byte)255, (byte)255, (byte)255, (byte)255));
    numTex[i] = LoadTextureFromImage(img); UnloadImage(img);
}
var numMesh = GenMeshPlane(5f, 5f, 1, 1);
var numModels = new Model[9];
for (int i = 0; i < 9; i++) { numModels[i] = LoadModelFromMesh(numMesh); unsafe { numModels[i].Materials[0].Maps[(int)MaterialMapIndex.Albedo].Texture = numTex[i]; } }

var playerPos = new Vector2(5, 5);
int curZone = ZoneOf(playerPos.X, playerPos.Y);
float yaw = 0f, pitch = 0.55f; bool captured = true; float sendTimer = 0f; Task lastSend = Task.CompletedTask;
long lastPktSnap = 0; double lastPktT = 0; int pktPerSec = 0; float switchFlash = 0f; int fromZone = 0;

while (!WindowShouldClose())
{
    float dt = GetFrameTime();
    if (captured) { var md = GetMouseDelta(); yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.12f, 1.35f); }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 7f * dt; }
    playerPos = Vector2.Clamp(playerPos, new Vector2(0.1f), new Vector2(WorldSize - 0.1f));

    // ★ 경계를 넘어도 '재접속 안 함'. 게이트가 뒤에서 백엔드를 교체할 뿐. 존만 바뀐다.
    int z = ZoneOf(playerPos.X, playerPos.Y);
    if (z != curZone) { fromZone = curZone; curZone = z; switchFlash = 0.6f; actors.Clear(); }   // 옆 칸 텅 빔(새 백엔드 것으로 교체)
    if (switchFlash > 0) switchFlash -= dt;

    sendTimer += dt;
    if (sendTimer > 0.066f && lastSend.IsCompleted)
    { sendTimer = 0f; try { lastSend = Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(playerPos.X, playerPos.Y))); } catch { } }

    double now = GetTime();
    if (now - lastPktT >= 0.5) { pktPerSec = (int)((pktTotal - lastPktSnap) / (now - lastPktT)); lastPktSnap = pktTotal; lastPktT = now; }

    float kl = 1f - MathF.Exp(-14f * dt);
    foreach (var ac in actors.Values) ac.Cur = Vector2.Lerp(ac.Cur, ac.Target, kl);

    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 9f;
    var cam = new Camera3D { Position = headP + offset, Target = headP, Up = new Vector3(0, 1, 0), FovY = 58f, Projection = CameraProjection.Perspective };

    BeginDrawing();
    ClearBackground(Color.SkyBlue);
    BeginMode3D(cam);
    for (int r = 0; r < Cols; r++) for (int cc = 0; cc < Cols; cc++)
    {
        int zi = r * Cols + cc;
        var center = new Vector3(cc * CellSize + CellSize / 2f, 0, r * CellSize + CellSize / 2f);
        DrawPlane(center, new Vector2(CellSize - 0.15f, CellSize - 0.15f), ZC[zi]);
        DrawModel(numModels[zi], new Vector3(center.X, 0.07f, center.Z), 1f, Color.White);
    }
    for (int i = 0; i <= Cols; i++)
    {
        DrawLine3D(new Vector3(i * CellSize, 0.05f, 0), new Vector3(i * CellSize, 0.05f, WorldSize), Color.White);
        DrawLine3D(new Vector3(0, 0.05f, i * CellSize), new Vector3(WorldSize, 0.05f, i * CellSize), Color.White);
    }
    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.RayWhite);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.18f, ZC[curZone]);

    int monCount = 0;
    foreach (var kv in actors)
    {
        var ac = kv.Value; if (ac.Kind != ActorKind.Monster) continue; monCount++;
        float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
        var p = new Vector3(ac.Cur.X, 0.5f + bob, ac.Cur.Y);
        DrawCube(p, 0.9f, 0.9f, 0.9f, Color.Red); DrawCubeWires(p, 0.9f, 0.9f, 0.9f, Color.Maroon);
        DrawSphere(new Vector3(ac.Cur.X, 1.4f + bob, ac.Cur.Y), 0.13f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);
    }
    EndMode3D();

    // HUD
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  ESC 커서", new Vector2(14, 12), 22, 1, Color.Black);
    DrawTextEx(hud, $"게이트(:{GatePort}) 연결 1개 유지 · 재접속 0회   현재 담당 존 {curZone}번   수신 {pktPerSec} pkt/s", new Vector2(14, 44), 19, 1, Color.Maroon);
    DrawTextEx(hud, $"담당 서버 교체는 게이트가 몰래 (연결은 그대로!)   몬스터 {monCount}마리 = 옆 칸은 텅 빔", new Vector2(14, 72), 19, 1, Color.DarkBlue);
    DrawRectangle(W - 60, 20, 36, 36, ZC[curZone]);
    DrawTextEx(hud, "담당 서버 색", new Vector2(W - 175, 60), 16, 1, Color.DarkGray);
    if (switchFlash > 0)   // STEP 1의 빨간 '재접속'과 달리 초록 '몰래 교체'
    {
        DrawRectangle(0, H / 2 - 32, W, 64, new Color((byte)30, (byte)140, (byte)60, (byte)210));
        DrawTextEx(hud, $"게이트가 담당 서버 교체: 존 {fromZone} → {curZone}  (연결은 그대로, 재접속 없음)", new Vector2(W / 2 - 300, H / 2 - 13), 24, 1, Color.White);
    }
    EndDrawing();
}

recvCts.Cancel();
try { client.Dispose(); } catch { }
CloseWindow();

enum ActorKind { Player, Monster }
sealed class Actor { public Vector2 Target; public Vector2 Cur; public ActorKind Kind; public int Zone; }
