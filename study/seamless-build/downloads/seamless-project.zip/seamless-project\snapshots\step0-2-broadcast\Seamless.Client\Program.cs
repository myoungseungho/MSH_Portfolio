// ── STEP 0 · 삽 2 — 클라: 이제 '두 가지를 동시에' 한다.
//    (1) 내 이동을 주기적으로 보내고  (2) 남의 이동(SM_MOVE)을 계속 받아 찍는다. ──

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int Port = 9001;

// 접속 (서버가 늦게 떠도 붙을 때까지 재시도)
TcpClient client = null!;
for (int attempt = 1; ; attempt++)
{
    try { client = new TcpClient(); await client.ConnectAsync(IPAddress.Loopback, Port); break; }
    catch (SocketException) when (attempt < 20) { client.Dispose(); await Task.Delay(200); }
}
var stream = client.GetStream();
Console.WriteLine($"[C] connected 127.0.0.1:{Port}");

// ★ 두 루프를 '동시에' 시작. async라 한 프로세스가 보내기·받기를 같이 굴린다.
//   같은 stream이라도 '읽기 하나 + 쓰기 하나'는 동시에 안전하다(전이중).
var recvLoop = ReceiveLoopAsync(stream);   // 받기 담당
var sendLoop = SendLoopAsync(stream);      // 보내기 담당
await Task.WhenAny(recvLoop, sendLoop);     // 둘 중 하나라도 끝나면(보내기 완료/연결 끊김) 프로그램 종료
Console.WriteLine("[C] 종료");

// 남의 이동(SM_MOVE)을 계속 받아 화면에 찍는다.
static async Task ReceiveLoopAsync(NetworkStream stream)
{
    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(stream);   // 방송 편지 한 통
            if (type == PacketType.SM_MOVE)
            {
                var s = Codec.Deserialize<SM_MOVE>(data);
                Console.WriteLine($"[C] 👀 P{s.PlayerId} 이(가) ({s.X}, {s.Y}) 로 이동  (주인=S{s.AuthorityServerId})");
            }
        }
    }
    catch (IOException) { /* 연결 끊김 = 받기 끝 */ }
}

// 내 이동을 주기적으로 보낸다. (데모용 자동 이동 — 진짜 게임이면 키 입력에서 나온다)
static async Task SendLoopAsync(NetworkStream stream)
{
    float x = 0, y = 0;
    try
    {
        for (int i = 0; i < 5; i++)            // 5번 이동하고 멈춘다 (테스트가 끝나게)
        {
            x += 1; y += 1;                    // 대각선으로 한 칸씩
            var data = Codec.Serialize(new CM_MOVE(x, y));
            await Framing.SendFramedAsync(stream, PacketType.CM_MOVE, data);
            Console.WriteLine($"[C] → 나 이동 ({x}, {y})");
            await Task.Delay(700);             // 0.7초마다
        }
        await Task.Delay(1500);               // 마지막 이동 뒤, 남의 방송을 조금 더 받고 종료
    }
    catch (IOException) { }
}
