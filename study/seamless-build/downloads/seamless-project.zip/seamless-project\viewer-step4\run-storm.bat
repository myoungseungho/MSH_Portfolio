@echo off
rem STEP 4 (폭풍판): 게이트 히스테리시스 H=0 (여유 폭 없음).
rem 경계에 딱 걸쳐 왔다갔다 하면 담당 서버가 매 순간 갈아탄다 → '이주 폭풍'.
rem 뷰어 머리 위 점(담당 서버 색)이 두 색 사이에서 깜빡이고, '실제 게이트 교체' 카운터가 폭발한다.
cd /d "%~dp0"
for /L %%z in (0,1,8) do start "Zone%%z" /min dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
start "Gate H=0" /min dotnet "Seamless.Gate\bin\Debug\net8.0\Seamless.Gate.dll" 0
timeout /t 4 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
