@echo off
rem STEP 1: 9칸 존 서버(0~8, 포트 9001~9009) + 3D 뷰어 실행.
rem 존 서버 9개는 최소화 창으로 뜬다(작업표시줄에서 닫으면 됨).
cd /d "%~dp0"
for /L %%z in (0,1,8) do start "Zone%%z" /min dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
timeout /t 3 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
