// ── STEP 0 · 삽 2 — 브로드캐스트: 서버가 받은 이동을 '접속한 모두'에게 되뿌린다. ──
//    새로 생기는 것: (1) 접속 목록(공유 레지스트리) (2) 그로 인한 '동시성' (3) SM_MOVE 첫 사용

using System.Collections.Concurrent;   // ConcurrentDictionary (여러 스레드가 동시에 써도 안전한 딕셔너리)
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int Port = 9001;

var listener = new TcpListener(IPAddress.Loopback, Port);
listener.Start();
Console.WriteLine($"[S0] listen 127.0.0.1:{Port}");

// ★ 공유 레지스트리: playerId → 그 클라와의 연결. 여러 손님의 핸들러(다른 스레드)가 동시에
//   추가(접속)·제거(퇴장)·순회(방송)하므로, 평범한 Dictionary가 아니라 스레드 안전한 것을 쓴다.
var clients = new ConcurrentDictionary<int, ClientConn>();
int nextId = 1;   // 이 accept 루프(한 스레드)에서만 올리므로 평범한 int로 충분

while (true)
{
    var tcp = await listener.AcceptTcpClientAsync();   // 접속 대기
    int playerId = nextId++;                            // 신원은 서버가 배정 (삽1과 동일)
    var conn = new ClientConn(playerId, tcp);           // 그 연결을 '보내기 안전' 래퍼로 감쌈
    clients[playerId] = conn;                           // 레지스트리에 등록
    Console.WriteLine($"[S0] accept → P{playerId} 접속 (현재 {clients.Count}명)");
    _ = HandleClientAsync(conn, clients);               // 이 손님 처리는 따로 던져두고(저글링) 다음 손님 받으러
}

// 한 손님의 편지를 계속 받아, 이동이면 '나 빼고 전원'에게 전파한다.
static async Task HandleClientAsync(ClientConn self, ConcurrentDictionary<int, ClientConn> clients)
{
    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(self.Stream);   // 편지 한 통을 온전히 받음
            if (type == PacketType.CM_MOVE)
            {
                var m = Codec.Deserialize<CM_MOVE>(data);                    // 이동 요청 되살림
                Console.WriteLine($"[S0] ← P{self.PlayerId} move({m.X},{m.Y}) → 전파 ({clients.Count - 1}명)");

                // 방송 편지: 서버가 '누가(PlayerId)' 움직였는지 찍어 SM_MOVE로 만든다. (주인은 이 서버 S0 = 0)
                var sm = Codec.Serialize(new SM_MOVE(self.PlayerId, m.X, m.Y, 0));
                foreach (var other in clients.Values)          // 지금 접속한 모두를 순회 (ConcurrentDictionary라 순회 중 변경돼도 안전)
                {
                    if (other.PlayerId == self.PlayerId) continue;   // 나 자신에겐 안 보냄 (내 이동은 내가 이미 아니까)
                    try { await other.SendAsync(PacketType.SM_MOVE, sm); }
                    catch { /* 그 사이 끊긴 클라면 무시 — 걔 핸들러가 알아서 정리한다 */ }
                }
            }
        }
    }
    catch (IOException) { /* 상대가 연결을 닫음 = 정상 종료 */ }
    catch (Exception ex) { Console.WriteLine($"[S0] P{self.PlayerId} 오류: {ex.GetType().Name}: {ex.Message}"); }
    finally
    {
        clients.TryRemove(self.PlayerId, out _);   // 나가면 레지스트리에서 뺀다 (안 그러면 죽은 연결에 계속 방송 시도)
        self.Dispose();
        Console.WriteLine($"[S0] P{self.PlayerId} 연결 종료 (현재 {clients.Count}명)");
    }
}

// 한 클라 연결 + '그 연결로의 안전한 보내기'.
//   왜 래퍼가 필요? 손님이 3명 이상이면 한 클라의 stream에 여러 핸들러가 '동시에' 쓸 수 있는데,
//   같은 stream에 동시 쓰기는 바이트가 뒤섞인다 → 보내기를 세마포어로 '한 번에 하나씩' 직렬화한다.
sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    readonly SemaphoreSlim _sendLock = new(1, 1);   // 이 연결로의 보내기를 한 번에 하나만 허용

    public ClientConn(int playerId, TcpClient tcp)
    {
        PlayerId = playerId;
        _tcp = tcp;
        Stream = tcp.GetStream();
    }

    public async Task SendAsync(PacketType type, byte[] data)
    {
        await _sendLock.WaitAsync();                 // 순서표 뽑기 (다른 보내기가 진행 중이면 끝날 때까지 기다림)
        try { await Framing.SendFramedAsync(Stream, type, data); }
        finally { _sendLock.Release(); }             // 다음 보내기에게 순서 넘김
    }

    public void Dispose() { _sendLock.Dispose(); _tcp.Dispose(); }
}
