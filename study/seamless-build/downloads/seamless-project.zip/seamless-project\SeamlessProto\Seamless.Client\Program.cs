// ── STEP 5 · 클라 — 존1에 서서, 옆 칸(존0)의 몬스터 M100에게 '로켓(데미지)'을 쏜다. ──
//    클라는 M100이 어느 서버 소유인지 '모른다'. 그냥 "M100에게 15 데미지"만 보낸다(위치 투명).
//    시스템이 주인(Z0)을 찾아 판정하고, 격추 결과(💥)가 돌아온다.

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int GatePort = 9000;
const int TargetMonster = 100;   // 존0 소유 몬스터 M100 (클라는 '어느 서버'인지 모른 채 ID만 안다)

TcpClient client = new();
for (int a = 1; ; a++) { try { await client.ConnectAsync(IPAddress.Loopback, GatePort); break; } catch (SocketException) when (a < 30) { client.Dispose(); client = new(); await Task.Delay(150); } }
var stream = client.GetStream();
Console.WriteLine("[C] 게이트 접속");
var cts = new CancellationTokenSource();
_ = RecvLoopAsync(stream, cts.Token);

// 1) 존1 경계로 걸어가 선다 (여기서 M100이 고스트로 보인다)
foreach (var x in new float[] { 5, 9, 13, 13, 13 })   // x=13 이면 히스테리시스(H=2)를 넘어 확실히 존1
{
    await Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(x, 5)));
    Console.WriteLine($"[C] → 이동 ({x},5)  [zone {(int)x / 10}]");
    await Task.Delay(600);
}
// 2) 옆 칸 몬스터 M100에게 로켓 발사 (HP 30, 15씩 → 2발이면 격추)
for (int shot = 1; shot <= 2; shot++)
{
    await Framing.SendFramedAsync(stream, PacketType.CM_ATTACK, Codec.Serialize(new AttackMsg(TargetMonster, 15)));
    Console.WriteLine($"[C] 🚀 로켓 발사 #{shot} → M{TargetMonster} (어느 서버인지 나는 모름)");
    await Task.Delay(800);
}
await Task.Delay(800);
cts.Cancel(); client.Dispose();
Console.WriteLine("[C] 끝");

static async Task RecvLoopAsync(NetworkStream s, CancellationToken ct)
{
    try
    {
        while (!ct.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(s, ct);
            var m = Codec.Deserialize<SM_MOVE>(d);
            if (t == PacketType.SM_MONSTER) Console.WriteLine($"[C]    🐺 M{m.PlayerId} = ({m.X},{m.Y}) [내 칸]");
            else if (t == PacketType.SM_GHOST) Console.WriteLine($"[C]    👻 (고스트) M{m.PlayerId} = ({m.X},{m.Y}) [옆 칸 zone {m.AuthorityServerId}]");
            else if (t == PacketType.SM_KILL) Console.WriteLine($"[C]    💥💥 M{m.PlayerId} 격추됨! (옆 칸 몬스터를 잡았다)");
        }
    }
    catch { }
}
