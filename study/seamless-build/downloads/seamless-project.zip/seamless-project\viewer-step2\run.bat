@echo off
rem STEP 2: 9칸 존 서버(9001~9009) + 게이트(9000) + 3D 뷰어. 서버·게이트는 최소화 창.
cd /d "%~dp0"
for /L %%z in (0,1,8) do start "Zone%%z" /min dotnet "Seamless.Server\bin\Debug\net8.0\Seamless.Server.dll" %%z
start "Gate" /min dotnet "Seamless.Gate\bin\Debug\net8.0\Seamless.Gate.dll"
timeout /t 3 /nobreak >nul
start "" "Seamless.Viewer\bin\Debug\net8.0\Seamless.Viewer.exe"
