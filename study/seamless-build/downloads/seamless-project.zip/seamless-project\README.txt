심리스(Seamless) 분산 서버 프로토타입 — 소스 전체
====================================================
9개 프로세스(3×3)가 나눠 담당하는 하나의 오픈월드. 경계 로딩 없이 걸어 넘고,
한 칸의 유저가 먼 칸의 몬스터를 로켓/광역기로 격추해도 이질감 없는 프로토타입.
문서: https://myoungseungho.github.io/MSH_Portfolio/study/seamless-build/

■ 필요한 것
  - .NET 8 SDK (dotnet --version 으로 확인)
  - Windows (뷰어는 Raylib GL 창)

■ 폴더 구성
  snapshots/            STEP별 서버 진화 스냅샷(공부용 핵심 코드 + 주석 + SNAPSHOT.md/INTERVIEW.md)
    step0-1-connection ~ step5-location-transparent-routing
  viewer-step0 ~ 7/     각 STEP을 3D로 보는 Raylib 뷰어(실행 데모). run.bat 더블클릭.
  SeamlessProto/        STEP 5까지 이어 만든 라이브 프로젝트(Shared/Server/Gate/Client)
  심리스_원본스펙.txt      원본 핸드오프 스펙

■ 3D 뷰어 실행 (예: STEP 7 광역기)
  cd viewer-step7
  dotnet build
  run.bat        (서버 9개 + 뷰어가 뜬다. WASD 이동 · 마우스 시점 · 좌클릭 광역기)

■ 로드맵
  STEP 0 단일서버 → 1 3×3분할 → 2 게이트 → 3 고스팅 → 4 이주(히스테리시스)
  → 5 위치투명 라우팅 → 6 멀티홉 + 관제 뷰 → 7 경계 걸친 광역기(AoE)

개인 학습/포트폴리오 목적. NDC SPICA(심리스 서버) 발표를 구현자 눈으로 재현.
