// ── STEP 1 뷰어용 존 서버 — '자기 칸(zone)'만 담당. 같은 exe를 zone 인자(0~8)로 9번 띄운다. ──
//    각 서버는 자기 칸의 플레이어·몬스터만 알고 방송한다(옆 칸은 모름). 뷰어용으로 틱을 빠르게(20Hz).

using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, Port0 = 9001, TickMs = 50;
int zoneIdx = args.Length > 0 ? int.Parse(args[0]) : 0;
int col = zoneIdx % Cols, row = zoneIdx / Cols;
int Port = Port0 + zoneIdx;
float zx0 = col * CellSize, zy0 = row * CellSize;
var rng = new Random(zoneIdx + 1);

var inbox = new ConcurrentQueue<GameCmd>();
var world = new Dictionary<int, (float X, float Y)>();
var conns = new Dictionary<int, ClientConn>();
// 이 칸의 몬스터 2마리 (칸 안에서 배회)
var monsters = new Dictionary<int, (float X, float Y, float VX, float VY)>();
for (int i = 0; i < 2; i++)
{
    float ang = (float)(rng.NextDouble() * Math.PI * 2), spd = 2.2f;
    monsters[100 + zoneIdx * 10 + i] = (zx0 + 2 + (float)rng.NextDouble() * 6, zy0 + 2 + (float)rng.NextDouble() * 6, MathF.Cos(ang) * spd, MathF.Sin(ang) * spd);
}

var listener = new TcpListener(IPAddress.Loopback, Port); listener.Start();
Console.WriteLine($"[Z{zoneIdx} c{col}r{row}] listen :{Port}  region x[{zx0}~{zx0 + CellSize}) y[{zy0}~{zy0 + CellSize})");

int nextId = 1;
_ = Task.Run(async () =>
{
    while (true) { var tcp = await listener.AcceptTcpClientAsync(); var conn = new ClientConn(zoneIdx * 100 + nextId++, tcp); inbox.Enqueue(new GameCmd(CmdKind.Join, conn.PlayerId, conn, 0, 0)); _ = RecvLoopAsync(conn, inbox); }
});

float dt = TickMs / 1000f;
while (true)
{
    while (inbox.TryDequeue(out var cmd))
    {
        if (cmd.Kind == CmdKind.Join) { conns[cmd.PlayerId] = cmd.Conn!; world[cmd.PlayerId] = (zx0 + 1, zy0 + 1); }
        else if (cmd.Kind == CmdKind.Move && world.ContainsKey(cmd.PlayerId)) world[cmd.PlayerId] = (cmd.X, cmd.Y);
        else if (cmd.Kind == CmdKind.Leave) { conns.Remove(cmd.PlayerId); world.Remove(cmd.PlayerId); }
    }

    // 몬스터: 이 칸 안에서 배회 (벽 튕김)
    foreach (var id in monsters.Keys.ToList())
    {
        var m = monsters[id];
        float nx = m.X + m.VX * dt, ny = m.Y + m.VY * dt, vx = m.VX, vy = m.VY;
        if (nx < zx0 || nx > zx0 + CellSize) { vx = -vx; nx = Math.Clamp(nx, zx0, zx0 + CellSize); }
        if (ny < zy0 || ny > zy0 + CellSize) { vy = -vy; ny = Math.Clamp(ny, zy0, zy0 + CellSize); }
        monsters[id] = (nx, ny, vx, vy);
    }

    // 방송: 이 칸의 플레이어 + 몬스터 (이 칸에 접속한 사람에게만). AuthorityServerId = 이 칸 번호.
    foreach (var (id, pos) in world) { var sm = Codec.Serialize(new SM_MOVE(id, pos.X, pos.Y, (byte)zoneIdx)); foreach (var c in conns.Values) if (c.PlayerId != id) try { await c.SendAsync(PacketType.SM_MOVE, sm); } catch { } }
    foreach (var (id, mo) in monsters) { var sm = Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, (byte)zoneIdx)); foreach (var c in conns.Values) try { await c.SendAsync(PacketType.SM_MONSTER, sm); } catch { } }

    await Task.Delay(TickMs);
}

static async Task RecvLoopAsync(ClientConn conn, ConcurrentQueue<GameCmd> inbox)
{
    try { while (true) { var (type, data) = await Framing.ReadFramedAsync(conn.Stream); if (type == PacketType.CM_MOVE) { var m = Codec.Deserialize<CM_MOVE>(data); inbox.Enqueue(new GameCmd(CmdKind.Move, conn.PlayerId, null, m.X, m.Y)); } } }
    catch { } finally { inbox.Enqueue(new GameCmd(CmdKind.Leave, conn.PlayerId, null, 0, 0)); conn.Dispose(); }
}

enum CmdKind { Join, Move, Leave }
readonly record struct GameCmd(CmdKind Kind, int PlayerId, ClientConn? Conn, float X, float Y);

sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    public ClientConn(int id, TcpClient tcp) { PlayerId = id; _tcp = tcp; Stream = tcp.GetStream(); }
    public Task SendAsync(PacketType t, byte[] d) => Framing.SendFramedAsync(Stream, t, d);
    public void Dispose() => _tcp.Dispose();
}
