// ── STEP 3 · Raylib 3D 뷰어 — 고스팅(첫 마법): 경계에 서면 옆 칸 몬스터가 👻 반투명으로 보인다. ──
//    게이트에 연결 1개(STEP 2 그대로). 각 존 서버는 경계 부근 이웃 액터를 SM_GHOST로 함께 내려준다.
//    → 경계 근처에 서면, 옆 칸(다른 색) 몬스터가 반투명 고스트로 보인다 = 9개 서버가 하나의 세계로 붙었다.

using System.Net.Sockets;
using System.Numerics;
using System.Collections.Concurrent;
using Raylib_cs;
using Seamless.Shared;
using static Raylib_cs.Raylib;

const int Cols = 3, CellSize = 10, GatePort = 9000, W = 1100, H = 720;
const float WorldSize = Cols * CellSize;
int ZoneOf(float x, float y) => Math.Clamp((int)y / CellSize, 0, Cols - 1) * Cols + Math.Clamp((int)x / CellSize, 0, Cols - 1);
Color[] ZC = { Color.DarkGreen, Color.Brown, Color.DarkBlue, Color.Maroon, Color.DarkGray, Color.Orange, Color.DarkPurple, Color.Green, Color.Blue };

// ── 게이트에 '한 번' 접속하고 그 연결을 끝까지 유지 (STEP 2와 동일) ──
var client = new TcpClient();
for (int a = 1; ; a++) { try { client.Connect("127.0.0.1", GatePort); break; } catch (SocketException) when (a < 60) { Thread.Sleep(120); } }
var stream = client.GetStream();
Console.WriteLine("[VIEWER] 게이트 접속 — 연결 하나 유지 (재접속 없음)");

var actors = new ConcurrentDictionary<int, Actor>();
long pktTotal = 0;
var recvCts = new CancellationTokenSource();
_ = Task.Run(async () =>
{
    try
    {
        while (!recvCts.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(stream, recvCts.Token);
            var m = Codec.Deserialize<SM_MOVE>(d);
            var kind = t switch { PacketType.SM_MONSTER => ActorKind.Monster, PacketType.SM_GHOST => ActorKind.Ghost, _ => ActorKind.Player };
            // 고스트는 옆 존 것이라 몬스터 id와 겹칠 수 있어 키를 분리한다
            int key = kind == ActorKind.Ghost ? 1_000_000 + m.PlayerId : m.PlayerId;
            actors.AddOrUpdate(key,
                _ => new Actor { Target = new(m.X, m.Y), Cur = new(m.X, m.Y), Kind = kind, Zone = m.AuthorityServerId, LastSeen = Environment.TickCount64 },
                (_, ac) => { ac.Target = new(m.X, m.Y); ac.Kind = kind; ac.Zone = m.AuthorityServerId; ac.LastSeen = Environment.TickCount64; return ac; });
            Interlocked.Increment(ref pktTotal);
        }
    }
    catch { }
});

InitWindow(W, H, "Seamless STEP 3 - Ghost Viewer");
SetTargetFPS(60);
SetExitKey(KeyboardKey.Null);
DisableCursor();
var koreanChars = "이동마우스시점커서게이트연결개유지재접속회담당서버옆칸고스트반투명읽기전용경계너머보인다수신틱마리몬스터현재존위치번세계가붙었다칸이제세계";
var cps = Enumerable.Range(32, 95).Concat(koreanChars.Select(c => (int)c)).Distinct().ToArray();
Font hud = LoadFontEx("C:/Windows/Fonts/malgun.ttf", 32, cps, cps.Length);

// 바닥 존 번호 (STEP 1·2와 동일)
var numTex = new Texture2D[9];
for (int i = 0; i < 9; i++)
{
    var img = GenImageColor(256, 256, new Color((byte)0, (byte)0, (byte)0, (byte)0));
    var txt = i.ToString(); var sz = MeasureTextEx(hud, txt, 190, 1); var tp = new Vector2(128 - sz.X / 2, 128 - sz.Y / 2);
    ImageDrawTextEx(ref img, hud, txt, tp + new Vector2(5, 5), 190, 1, new Color((byte)0, (byte)0, (byte)0, (byte)200));
    ImageDrawTextEx(ref img, hud, txt, tp, 190, 1, new Color((byte)255, (byte)255, (byte)255, (byte)255));
    numTex[i] = LoadTextureFromImage(img); UnloadImage(img);
}
var numMesh = GenMeshPlane(5f, 5f, 1, 1);
var numModels = new Model[9];
for (int i = 0; i < 9; i++) { numModels[i] = LoadModelFromMesh(numMesh); unsafe { numModels[i].Materials[0].Maps[(int)MaterialMapIndex.Albedo].Texture = numTex[i]; } }

var playerPos = new Vector2(5, 5);
int curZone = ZoneOf(playerPos.X, playerPos.Y);
float yaw = 0f, pitch = 0.55f; bool captured = true; float sendTimer = 0f; Task lastSend = Task.CompletedTask;
long lastPktSnap = 0; double lastPktT = 0; int pktPerSec = 0;

while (!WindowShouldClose())
{
    float dt = GetFrameTime();
    if (captured) { var md = GetMouseDelta(); yaw -= md.X * 0.003f; pitch += md.Y * 0.003f; pitch = Math.Clamp(pitch, 0.12f, 1.35f); }
    if (IsKeyPressed(KeyboardKey.Escape)) { captured = !captured; if (captured) DisableCursor(); else EnableCursor(); }

    var fwd = new Vector2(MathF.Sin(yaw), MathF.Cos(yaw));
    var right = new Vector2(-fwd.Y, fwd.X);
    var move = Vector2.Zero;
    if (IsKeyDown(KeyboardKey.W)) move += fwd;
    if (IsKeyDown(KeyboardKey.S)) move -= fwd;
    if (IsKeyDown(KeyboardKey.D)) move += right;
    if (IsKeyDown(KeyboardKey.A)) move -= right;
    bool moving = move != Vector2.Zero;
    if (moving) { move = Vector2.Normalize(move); playerPos += move * 7f * dt; }
    playerPos = Vector2.Clamp(playerPos, new Vector2(0.1f), new Vector2(WorldSize - 0.1f));

    // 경계를 넘으면 게이트가 백엔드 교체 → 이전 존 것 비움 (STEP 2와 동일)
    int z = ZoneOf(playerPos.X, playerPos.Y);
    if (z != curZone) { curZone = z; foreach (var k in actors.Keys.ToList()) actors.TryRemove(k, out _); }

    sendTimer += dt;
    if (sendTimer > 0.066f && lastSend.IsCompleted)
    { sendTimer = 0f; try { lastSend = Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(playerPos.X, playerPos.Y))); } catch { } }

    double now = GetTime();
    if (now - lastPktT >= 0.5) { pktPerSec = (int)((pktTotal - lastPktSnap) / (now - lastPktT)); lastPktSnap = pktTotal; lastPktT = now; }

    // 오래 안 들어온 액터(멀어진 고스트 등) 제거 + 보간
    long nowMs = Environment.TickCount64;
    foreach (var k in actors.Where(kv => nowMs - kv.Value.LastSeen > 400).Select(kv => kv.Key).ToList()) actors.TryRemove(k, out _);
    float kl = 1f - MathF.Exp(-14f * dt);
    foreach (var ac in actors.Values) ac.Cur = Vector2.Lerp(ac.Cur, ac.Target, kl);

    var headP = new Vector3(playerPos.X, 1.6f, playerPos.Y);
    var offset = new Vector3(-MathF.Sin(yaw) * MathF.Cos(pitch), MathF.Sin(pitch), -MathF.Cos(yaw) * MathF.Cos(pitch)) * 9f;
    var cam = new Camera3D { Position = headP + offset, Target = headP, Up = new Vector3(0, 1, 0), FovY = 58f, Projection = CameraProjection.Perspective };

    BeginDrawing();
    ClearBackground(Color.SkyBlue);
    BeginMode3D(cam);
    for (int r = 0; r < Cols; r++) for (int cc = 0; cc < Cols; cc++)
    {
        int zi = r * Cols + cc;
        var center = new Vector3(cc * CellSize + CellSize / 2f, 0, r * CellSize + CellSize / 2f);
        DrawPlane(center, new Vector2(CellSize - 0.15f, CellSize - 0.15f), ZC[zi]);
        DrawModel(numModels[zi], new Vector3(center.X, 0.07f, center.Z), 1f, Color.White);
    }
    for (int i = 0; i <= Cols; i++)
    {
        DrawLine3D(new Vector3(i * CellSize, 0.05f, 0), new Vector3(i * CellSize, 0.05f, WorldSize), Color.White);
        DrawLine3D(new Vector3(0, 0.05f, i * CellSize), new Vector3(WorldSize, 0.05f, i * CellSize), Color.White);
    }
    float myBob = moving ? 0.08f * MathF.Sin((float)GetTime() * 12f) : 0f;
    DrawCapsule(new Vector3(playerPos.X, 0.5f + myBob, playerPos.Y), new Vector3(playerPos.X, 1.9f + myBob, playerPos.Y), 0.5f, 14, 8, Color.RayWhite);
    DrawSphere(new Vector3(playerPos.X, 2.4f + myBob, playerPos.Y), 0.18f, ZC[curZone]);

    int monCount = 0, ghostCount = 0;
    foreach (var kv in actors)
    {
        var ac = kv.Value;
        if (ac.Kind == ActorKind.Monster)
        {
            monCount++;
            float bob = 0.12f * MathF.Sin((float)GetTime() * 4f + kv.Key);
            var p = new Vector3(ac.Cur.X, 0.5f + bob, ac.Cur.Y);
            DrawCube(p, 0.9f, 0.9f, 0.9f, Color.Red); DrawCubeWires(p, 0.9f, 0.9f, 0.9f, Color.Maroon);
            DrawSphere(new Vector3(ac.Cur.X, 1.4f + bob, ac.Cur.Y), 0.13f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);
        }
        else if (ac.Kind == ActorKind.Ghost)
        {
            ghostCount++;
            var p = new Vector3(ac.Cur.X, 0.5f, ac.Cur.Y);
            DrawCube(p, 0.9f, 0.9f, 0.9f, new Color((byte)200, (byte)210, (byte)255, (byte)90));    // 반투명 고스트(읽기전용 복사본)
            DrawCubeWires(p, 0.9f, 0.9f, 0.9f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);            // 외곽선 = 주인 존 색
            DrawSphere(new Vector3(ac.Cur.X, 1.4f, ac.Cur.Y), 0.13f, ac.Zone < 9 ? ZC[ac.Zone] : Color.White);
        }
    }
    EndMode3D();

    // HUD
    DrawTextEx(hud, "WASD 이동  |  마우스 시점  |  ESC 커서", new Vector2(14, 12), 22, 1, Color.Black);
    DrawTextEx(hud, $"현재 존 {curZone}번   내 칸 몬스터 {monCount}마리   옆 칸 고스트 {ghostCount}   수신 {pktPerSec} pkt/s", new Vector2(14, 44), 19, 1, Color.Maroon);
    DrawTextEx(hud, "경계 근처에 서면 옆 칸(다른 색) 몬스터가 반투명 고스트로 보인다 = 세계가 붙었다", new Vector2(14, 72), 18, 1, Color.DarkBlue);
    if (ghostCount > 0)
    {
        DrawRectangle(W - 300, 12, 288, 38, new Color((byte)40, (byte)90, (byte)160, (byte)210));
        DrawTextEx(hud, $"옆 칸이 보인다  ({ghostCount})", new Vector2(W - 280, 18), 24, 1, Color.White);
    }
    EndDrawing();
}

recvCts.Cancel();
try { client.Dispose(); } catch { }
CloseWindow();

enum ActorKind { Player, Monster, Ghost }
sealed class Actor { public Vector2 Target; public Vector2 Cur; public ActorKind Kind; public int Zone; public long LastSeen; }
