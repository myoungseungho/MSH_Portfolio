// ── STEP 0 · 삽 4 — 몬스터: '스스로 움직이는 것'을 world에 얹는다. → STEP 0 완성! ──
//    틱이 이미 매 프레임 world를 갱신·방송하니, 몬스터는 그 안에서 '매 틱 조금씩 움직이기'만 하면 된다.

using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int Port = 9001;
const int TickMs = 500;   // 데모라 느리게(초당 2번)

var inbox = new ConcurrentQueue<GameCmd>();
var world = new Dictionary<int, (float X, float Y)>();   // 플레이어 위치 (틱 스레드 전용)
var conns = new Dictionary<int, ClientConn>();

// ★ 몬스터 몇 마리. (id → 위치 + 속도) 아무도 조종 안 해도 매 틱 스스로 움직인다.
var monsters = new Dictionary<int, (float X, float Y, float VX, float VY)>
{
    [1] = (5, 5, 1, 0),    // 가로로 배회
    [2] = (10, 8, 0, 1),   // 세로로 배회
};

var listener = new TcpListener(IPAddress.Loopback, Port);
listener.Start();
Console.WriteLine($"[S0] listen :{Port}, tick {TickMs}ms, 몬스터 {monsters.Count}마리");

int nextId = 1;
_ = Task.Run(async () =>
{
    while (true)
    {
        var tcp = await listener.AcceptTcpClientAsync();
        var conn = new ClientConn(nextId++, tcp);
        inbox.Enqueue(new GameCmd(CmdKind.Join, conn.PlayerId, conn, 0, 0));
        _ = RecvLoopAsync(conn, inbox);
    }
});

long tick = 0;
while (true)
{
    tick++;

    // 1) 플레이어 이벤트 처리 (입장/이동/퇴장)
    while (inbox.TryDequeue(out var cmd))
    {
        if (cmd.Kind == CmdKind.Join) { conns[cmd.PlayerId] = cmd.Conn!; world[cmd.PlayerId] = (0, 0); Console.WriteLine($"[S0] +P{cmd.PlayerId} 입장 ({conns.Count}명)"); }
        else if (cmd.Kind == CmdKind.Move && world.ContainsKey(cmd.PlayerId)) { world[cmd.PlayerId] = (cmd.X, cmd.Y); }
        else if (cmd.Kind == CmdKind.Leave) { conns.Remove(cmd.PlayerId); world.Remove(cmd.PlayerId); Console.WriteLine($"[S0] -P{cmd.PlayerId} 퇴장 ({conns.Count}명)"); }
    }

    // 2) ★ 몬스터를 '스스로' 움직인다 (입력 없이!). 0~20 범위, 벽에 닿으면 튕김.
    foreach (var id in monsters.Keys.ToList())
    {
        var mo = monsters[id];
        float vx = mo.VX, vy = mo.VY;
        float nx = mo.X + vx, ny = mo.Y + vy;
        if (nx < 0 || nx > 20) { vx = -vx; nx = mo.X + vx; }   // 벽 튕김
        if (ny < 0 || ny > 20) { vy = -vy; ny = mo.Y + vy; }
        monsters[id] = (nx, ny, vx, vy);
    }

    // 3) 방송: 플레이어(SM_MOVE, 본인 제외) + 몬스터(SM_MONSTER, 전원에게)
    foreach (var (id, pos) in world)
    {
        var sm = Codec.Serialize(new SM_MOVE(id, pos.X, pos.Y, 0));
        foreach (var c in conns.Values) if (c.PlayerId != id) try { await c.SendAsync(PacketType.SM_MOVE, sm); } catch { }
    }
    foreach (var (id, mo) in monsters)
    {
        var sm = Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, 0));   // 몬스터도 SM_MOVE 모양 재사용
        foreach (var c in conns.Values) try { await c.SendAsync(PacketType.SM_MONSTER, sm); } catch { }
    }

    // 4) 심장박동 + 몬스터 위치 (스스로 움직이는 게 로그로 보인다)
    var ms = string.Join(" ", monsters.Select(kv => $"M{kv.Key}({kv.Value.X},{kv.Value.Y})"));
    Console.WriteLine($"[S0] tick #{tick} | {conns.Count}명 | {ms}");
    await Task.Delay(TickMs);
}

// 네트워크 수신: world를 '직접 안 만지고' 받은 이동을 inbox에 넣기만 한다.
static async Task RecvLoopAsync(ClientConn conn, ConcurrentQueue<GameCmd> inbox)
{
    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(conn.Stream);
            if (type == PacketType.CM_MOVE)
            {
                var m = Codec.Deserialize<CM_MOVE>(data);
                inbox.Enqueue(new GameCmd(CmdKind.Move, conn.PlayerId, null, m.X, m.Y));
            }
        }
    }
    catch { }
    finally { inbox.Enqueue(new GameCmd(CmdKind.Leave, conn.PlayerId, null, 0, 0)); conn.Dispose(); }
}

enum CmdKind { Join, Move, Leave }
readonly record struct GameCmd(CmdKind Kind, int PlayerId, ClientConn? Conn, float X, float Y);

sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    public ClientConn(int id, TcpClient tcp) { PlayerId = id; _tcp = tcp; Stream = tcp.GetStream(); }
    public Task SendAsync(PacketType t, byte[] d) => Framing.SendFramedAsync(Stream, t, d);
    public void Dispose() => _tcp.Dispose();
}
