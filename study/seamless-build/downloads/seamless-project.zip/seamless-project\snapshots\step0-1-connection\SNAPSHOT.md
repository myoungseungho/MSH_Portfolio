# STEP 0 · 삽 1 — 파이프 뚫기 (연결)

이 스냅샷 = **"두 프로세스가 바이트를 주고받는다"**까지 완성된 상태.
STEP 0의 가장 추상적 목적인 **연결(Connection)** 하나를 증명하려고 최소한만 넣었다.

## ✅ 되는 것
- 클라가 서버에 connect → `CM_MOVE(x, y)` 한 통을 `[길이][타입][데이터]`로 감싸 보냄
- 서버가 accept(그 순간 신원 P번 배정) → 프레임 수신 → 역직렬화 → 콘솔에
  `[S0] ← from P1: move(10, 5) owner=S0`

## ❌ 아직 안 되는 것 (= 다음 삽의 동기)
- 클라 둘이면 서로 못 봄 (브로드캐스트 없음) → **다음 삽: 브로드캐스트**
- 가만있으면 세상이 안 흐름 (틱 없음)
- 몬스터 없음

## 구성 (5부품)
- `Seamless.Shared/Packets.cs` — ① 패킷 모양 + 종류번호 (CM_MOVE / SM_MOVE)
- `Seamless.Shared/Codec.cs` — ② 직렬화 ↔ 역직렬화 (제네릭 하나로 전부, `where T : unmanaged`)
- `Seamless.Shared/Framing.cs` — ③ 프레이밍 `[길이][타입][데이터]` (TCP 스트림에 경계 긋기)
- `Seamless.Server/Program.cs` — ④⑤ 우편+분류 (listen·accept·수신·디스패치)
- `Seamless.Client/Program.cs` — ④ 우편 (connect·send)

## 관통 사고
- 신원·권위는 **서버가 소유** (playerId는 패킷에 안 넣음, accept 때 배정)
- TCP 스트림엔 **경계를 우리가 긋는다** (길이 접두사)
- **올 게 확실한 건 지금 판다** (AuthorityServerId 미리)
- 한 스레드가 안 막히고 **저글링** (`_ = HandleClientAsync(...)`)

## 빌드 / 실행
```
dotnet build
# 터미널 1:  dotnet run --project Seamless.Server
# 터미널 2:  dotnet run --project Seamless.Client
```
또는 VS에서 SeamlessProto.sln 열고 F5.
