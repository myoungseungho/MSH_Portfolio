// ── STEP 1 · 3×3 정적 분할 — 서버는 '자기 칸(zone)'만 담당한다. ──
//    같은 exe를 zone 인자(0~8)만 바꿔 9번 띄운다. 각 서버는 자기 칸의 플레이어·몬스터만 안다.
//    (옆 칸은 모른다 = 다음 스텝의 결핍.)

using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, Port0 = 9001, TickMs = 500;
int zoneIdx = args.Length > 0 ? int.Parse(args[0]) : 0;   // 어느 칸인지
int col = zoneIdx % Cols, row = zoneIdx / Cols;
int Port = Port0 + zoneIdx;
float zx0 = col * CellSize, zy0 = row * CellSize;          // 이 칸의 좌하단 (region: [zx0,zx0+10) x [zy0,zy0+10))

var inbox = new ConcurrentQueue<GameCmd>();
var world = new Dictionary<int, (float X, float Y)>();
var conns = new Dictionary<int, ClientConn>();
// 이 칸의 몬스터 1마리 (칸 중앙에서 좌우 배회, 칸 밖으로 안 나감)
var monsters = new Dictionary<int, (float X, float Y, float VX, float VY)>
{
    [100 + zoneIdx] = (zx0 + 5, zy0 + 5, 1, 0),
};

var listener = new TcpListener(IPAddress.Loopback, Port);
listener.Start();
Console.WriteLine($"[Z{zoneIdx} c{col}r{row}] listen :{Port}  region x[{zx0}~{zx0 + CellSize}) y[{zy0}~{zy0 + CellSize})");

int nextId = 1;
_ = Task.Run(async () =>
{
    while (true)
    {
        var tcp = await listener.AcceptTcpClientAsync();
        var conn = new ClientConn(zoneIdx * 100 + nextId++, tcp);   // 칸별로 구분되는 playerId
        inbox.Enqueue(new GameCmd(CmdKind.Join, conn.PlayerId, conn, 0, 0));
        _ = RecvLoopAsync(conn, inbox);
    }
});

long tick = 0;
while (true)
{
    tick++;
    while (inbox.TryDequeue(out var cmd))
    {
        if (cmd.Kind == CmdKind.Join) { conns[cmd.PlayerId] = cmd.Conn!; world[cmd.PlayerId] = (0, 0); Console.WriteLine($"[Z{zoneIdx}] +P{cmd.PlayerId} 입장 ({conns.Count}명)"); }
        else if (cmd.Kind == CmdKind.Move && world.ContainsKey(cmd.PlayerId)) { world[cmd.PlayerId] = (cmd.X, cmd.Y); }
        else if (cmd.Kind == CmdKind.Leave) { conns.Remove(cmd.PlayerId); world.Remove(cmd.PlayerId); Console.WriteLine($"[Z{zoneIdx}] -P{cmd.PlayerId} 퇴장 ({conns.Count}명)"); }
    }

    // 몬스터: 이 칸 안에서만 좌우 배회
    foreach (var id in monsters.Keys.ToList())
    {
        var mo = monsters[id];
        float vx = mo.VX, nx = mo.X + vx;
        if (nx < zx0 || nx >= zx0 + CellSize) { vx = -vx; nx = mo.X + vx; }
        monsters[id] = (nx, mo.Y, vx, mo.VY);
    }

    // 방송: 이 칸의 플레이어 + 몬스터 (이 칸에 접속한 사람들에게만)
    foreach (var (id, pos) in world)
    {
        var sm = Codec.Serialize(new SM_MOVE(id, pos.X, pos.Y, (byte)zoneIdx));
        foreach (var c in conns.Values) if (c.PlayerId != id) try { await c.SendAsync(PacketType.SM_MOVE, sm); } catch { }
    }
    foreach (var (id, mo) in monsters)
    {
        var sm = Codec.Serialize(new SM_MOVE(id, mo.X, mo.Y, (byte)zoneIdx));
        foreach (var c in conns.Values) try { await c.SendAsync(PacketType.SM_MONSTER, sm); } catch { }
    }

    if (tick % 4 == 1)   // 심장박동은 가끔만 (로그 절약)
    {
        var ms = string.Join(" ", monsters.Select(kv => $"M{kv.Key}({kv.Value.X},{kv.Value.Y})"));
        Console.WriteLine($"[Z{zoneIdx}] tick #{tick} | {conns.Count}명 | {ms}");
    }
    await Task.Delay(TickMs);
}

static async Task RecvLoopAsync(ClientConn conn, ConcurrentQueue<GameCmd> inbox)
{
    try
    {
        while (true)
        {
            var (type, data) = await Framing.ReadFramedAsync(conn.Stream);
            if (type == PacketType.CM_MOVE)
            {
                var m = Codec.Deserialize<CM_MOVE>(data);
                inbox.Enqueue(new GameCmd(CmdKind.Move, conn.PlayerId, null, m.X, m.Y));
            }
        }
    }
    catch { }
    finally { inbox.Enqueue(new GameCmd(CmdKind.Leave, conn.PlayerId, null, 0, 0)); conn.Dispose(); }
}

enum CmdKind { Join, Move, Leave }
readonly record struct GameCmd(CmdKind Kind, int PlayerId, ClientConn? Conn, float X, float Y);

sealed class ClientConn : IDisposable
{
    public int PlayerId { get; }
    public NetworkStream Stream { get; }
    readonly TcpClient _tcp;
    public ClientConn(int id, TcpClient tcp) { PlayerId = id; _tcp = tcp; Stream = tcp.GetStream(); }
    public Task SendAsync(PacketType t, byte[] d) => Framing.SendFramedAsync(Stream, t, d);
    public void Dispose() => _tcp.Dispose();
}
