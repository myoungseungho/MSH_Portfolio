// ── STEP 2 · 클라 — 이제 게이트(:9000) 하나에만 붙는다. 칸 로직도, 재접속도 없다. ──
//    걷다가 칸을 넘어도 클라는 아무것도 안 한다. 뒤에서 게이트가 담당 서버를 몰래 바꿔준다.

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int GatePort = 9000;

TcpClient client = new();
for (int a = 1; ; a++)
{
    try { await client.ConnectAsync(IPAddress.Loopback, GatePort); break; }
    catch (SocketException) when (a < 30) { client.Dispose(); client = new(); await Task.Delay(150); }
}
var stream = client.GetStream();
Console.WriteLine($"[C] 게이트(:{GatePort})에 접속 — 이 연결 하나로 끝까지 간다");

var cts = new CancellationTokenSource();
var recv = RecvLoopAsync(stream, cts.Token);

// 오른쪽으로 쭉 걷는다. 칸을 넘든 말든 클라는 그냥 이동만 보낸다(재접속 없음).
float x = 5, y = 5;
while (x <= 25)
{
    await Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(x, y)));
    Console.WriteLine($"[C] → 이동 ({x}, {y})   (연결은 그대로)");
    await Task.Delay(500);
    x += 2;
}
cts.Cancel();
client.Dispose();
Console.WriteLine("[C] 산책 끝 — 한 번도 재접속 안 했다");

static async Task RecvLoopAsync(NetworkStream s, CancellationToken ct)
{
    try
    {
        while (!ct.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(s, ct);
            var m = Codec.Deserialize<SM_MOVE>(d);
            if (t == PacketType.SM_MOVE) Console.WriteLine($"[C]    👀 P{m.PlayerId} = ({m.X}, {m.Y})");
            else if (t == PacketType.SM_MONSTER) Console.WriteLine($"[C]    🐺 M{m.PlayerId} = ({m.X}, {m.Y})  [zone {m.AuthorityServerId}]");
        }
    }
    catch { }
}
