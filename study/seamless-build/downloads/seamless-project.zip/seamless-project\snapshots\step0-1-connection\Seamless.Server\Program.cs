// ── 이 파일은 서버의 '시작점(entry point)'이다. C#은 파일 맨 위에 바로 실행문을 둘 수 있고(top-level statements),
//    컴파일러가 이걸 자동으로 'Main() 함수 안'에 넣어준다. 그래서 함수 바깥처럼 보여도 사실은 Main 속이다.
//    (프로젝트에서 이렇게 top-level 문을 쓸 수 있는 파일은 딱 하나 = 진짜 시작점.) ──

using System.Net;            // IPAddress 를 짧게 쓰려는 '이름 가져오기' (C++의 #include 와 달리 파일을 붙이는 게 아님)
using System.Net.Sockets;    // TcpListener, TcpClient, NetworkStream 이름 가져오기
using Seamless.Shared;       // 우리 공용 프로젝트(PacketType, CM_MOVE, Codec, Framing)의 이름 가져오기

// STEP 0 첫 삽 — 서버: listen하고, 접속마다 async 수신 루프.
try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }  // 콘솔 한글 안 깨지게(안 되는 환경이면 그냥 넘어감)
const int Port = 9001;       // 이 서버가 귀 기울일 포트 번호. const = 절대 안 바뀌는 상수.

var listener = new TcpListener(IPAddress.Loopback, Port);  // 127.0.0.1:9001 로 들어오는 접속을 받을 '문'을 준비한다
listener.Start();                                          // 그 문을 실제로 연다(이제 OS가 이 포트의 접속을 받기 시작)
Console.WriteLine($"[S0] listen 127.0.0.1:{Port}  (클라용 포트)");  // 눈으로 확인용 로그. $"...{변수}..." = 문자열에 값 끼워넣기.

int nextId = 1;              // 다음에 접속하는 사람에게 줄 번호. 1번부터.
while (true)                 // 서버는 안 꺼지고 계속 손님을 받아야 하니 무한 반복
{
    var client = await listener.AcceptTcpClientAsync();   // 누가 접속할 때까지 기다렸다가(await), 오면 그 연결 하나를 받는다
    int playerId = nextId++;                              // 그 손님에게 번호를 배정하고 nextId를 +1. '신원은 서버가 정한다'.
    Console.WriteLine($"[S0] accept → P{playerId} 배정  (from {client.Client.RemoteEndPoint})");  // 누가 어디서 붙었는지 로그
    _ = HandleClientAsync(client, playerId);             // 이 손님 처리를 '따로' 시작시킨다. await를 안 붙임 = 기다리지 않고
                                                         //   곧장 위 while로 돌아가 '다음 손님'을 받는다(한 스레드로 여러 명 저글링).
                                                         //   맨 앞 _ = 는 "돌아온 Task 안 쓸게"라는 표시(경고 끄기용).
}

// 아래는 '지역 함수'. top-level 문들 뒤에 함수를 선언하면 컴파일러가 위 Main 안의 함수로 넣어준다.
// 한 손님과의 대화를 끝까지 담당한다(그 연결이 닫힐 때까지 편지를 계속 받음).
static async Task HandleClientAsync(TcpClient client, int playerId)
{
    Console.WriteLine($"[S0] P{playerId} 수신 루프 시작");   // 이 손님 담당 시작 로그
    try                                                     // 아래에서 예외(연결 끊김 등)가 날 수 있어 try로 감싼다
    {
        using (client)                          // using = 이 블록이 끝나면 client(연결)를 자동으로 닫아라(자원 정리). C++의 소멸자/RAII 느낌.
        using (var stream = client.GetStream()) // 그 연결 위의 '읽고/쓰는 통로'를 꺼낸다. 이것도 블록 끝나면 자동 정리.
        {
            while (true)                        // 이 손님이 보내는 편지를 계속 받는다
            {
                Console.WriteLine($"[S0] P{playerId} 프레임 대기...");            // 지금 편지를 기다리는 중이라는 로그
                var (type, data) = await Framing.ReadFramedAsync(stream);         // 편지 한 통을 온전히 받아 (종류, 데이터)로 푼다
                Console.WriteLine($"[S0] frame recv: type={type}, {data.Length}B");  // 무슨 종류 몇 바이트 왔는지 로그
                if (type == PacketType.CM_MOVE)                                   // 이동 편지라면
                {
                    var m = Codec.Deserialize<CM_MOVE>(data);                     // 데이터 바이트를 CM_MOVE 구조체로 되살린다(역직렬화)
                    // 신원은 '연결'이 증명 → playerId는 서버가 안다. 주인도 이 서버(S0).
                    Console.WriteLine($"[S0] ← from P{playerId}: move({m.X}, {m.Y}) owner=S0");
                }
            }
        }
    }
    catch (IOException)                          // 연결이 끊긴 경우(상대가 나감) → 정상적인 종료로 취급
    {
        Console.WriteLine($"[S0] P{playerId} 연결 종료");
    }
    catch (Exception ex)                         // 그 외 예상 못한 오류. 한 손님 문제로 서버 전체가 죽지 않게 여기서 받아 로그만 남긴다.
    {
        Console.WriteLine($"[S0] P{playerId} 처리 오류: {ex.GetType().Name}: {ex.Message}");
    }
}
