// ── STEP 0 · 삽 4 — 클라: 플레이어(👀)와 몬스터(🐺)를 둘 다 받아 찍는다.
//    이 클라는 1번만 이동하고 멈춘다 — 그래도 몬스터가 스스로 움직이는 게 계속 보여야 정상. ──

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }
const int Port = 9001;

TcpClient client = null!;
for (int a = 1; ; a++)
{
    try { client = new TcpClient(); await client.ConnectAsync(IPAddress.Loopback, Port); break; }
    catch (SocketException) when (a < 20) { client.Dispose(); await Task.Delay(200); }
}
var stream = client.GetStream();
Console.WriteLine("[C] connected");

var recv = RecvLoopAsync(stream);
var send = SendLoopAsync(stream);
await Task.WhenAny(recv, send);
Console.WriteLine("[C] 종료");

// 남의 위치(플레이어=SM_MOVE, 몬스터=SM_MONSTER)를 받을 때마다 찍는다.
static async Task RecvLoopAsync(NetworkStream s)
{
    try
    {
        while (true)
        {
            var (t, d) = await Framing.ReadFramedAsync(s);
            if (t == PacketType.SM_MOVE)
            {
                var m = Codec.Deserialize<SM_MOVE>(d);
                Console.WriteLine($"[C] 👀 P{m.PlayerId} = ({m.X}, {m.Y})");
            }
            else if (t == PacketType.SM_MONSTER)
            {
                var m = Codec.Deserialize<SM_MOVE>(d);
                Console.WriteLine($"[C] 🐺 M{m.PlayerId} = ({m.X}, {m.Y})");
            }
        }
    }
    catch (IOException) { }
}

// 1번만 이동하고 멈춰서 3초 서 있는다 (그동안 몬스터가 스스로 움직이는지 확인).
static async Task SendLoopAsync(NetworkStream s)
{
    try
    {
        await Framing.SendFramedAsync(s, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(1, 1)));
        Console.WriteLine("[C] → 나 이동 (1, 1)");
        Console.WriteLine("[C] 나 멈춤 — 이제 몬스터만 지켜본다");
        await Task.Delay(3000);
    }
    catch (IOException) { }
}
