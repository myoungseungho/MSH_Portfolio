// ── STEP 1 · 클라 — 월드를 오른쪽으로 걸어간다. 칸 경계를 넘을 때마다 '끊고 재접속'한다.
//    이게 "경계 = 벽" — 넘는 순간 프리즈 + 재접속. 그리고 한 칸에선 그 칸 서버만 아니, 옆 칸은 안 보인다. ──

using System.Net;
using System.Net.Sockets;
using Seamless.Shared;

try { Console.OutputEncoding = System.Text.Encoding.UTF8; } catch { }

const int Cols = 3, CellSize = 10, Port0 = 9001;
int ZoneOf(float x, float y) => ((int)y / CellSize) * Cols + ((int)x / CellSize);
int PortOf(int z) => Port0 + z;

float x = 5, y = 5;                 // 시작: 칸0 (좌하단)
int curZone = ZoneOf(x, y);

while (x <= 25)
{
    // 1) 현재 칸 서버에 접속
    TcpClient client = new();
    for (int a = 1; ; a++)
    {
        try { await client.ConnectAsync(IPAddress.Loopback, PortOf(curZone)); break; }
        catch (SocketException) when (a < 30) { client.Dispose(); client = new(); await Task.Delay(150); }
    }
    var stream = client.GetStream();
    Console.WriteLine($"[C] ===== zone {curZone} 접속 (:{PortOf(curZone)}) =====");
    var cts = new CancellationTokenSource();
    var recv = RecvLoopAsync(stream, cts.Token);   // 이 칸에서 보이는 것만 받아 찍음

    // 2) 이 칸 안에서 걷는다
    while (ZoneOf(x, y) == curZone && x <= 25)
    {
        await Framing.SendFramedAsync(stream, PacketType.CM_MOVE, Codec.Serialize(new CM_MOVE(x, y)));
        Console.WriteLine($"[C] → 이동 ({x}, {y})  [zone {curZone}]");
        await Task.Delay(500);
        x += 2;
    }

    // 3) 경계! 끊고 다음 칸으로 (프리즈+재접속)
    cts.Cancel();
    client.Dispose();
    if (x > 25) break;
    int next = ZoneOf(x, y);
    Console.WriteLine($"[C] ⛔ 경계! zone {curZone} → {next} : 연결 끊고 재접속 (프리즈)");
    curZone = next;
}
Console.WriteLine("[C] 산책 끝 (칸 0 → 1 → 2)");

static async Task RecvLoopAsync(NetworkStream s, CancellationToken ct)
{
    try
    {
        while (!ct.IsCancellationRequested)
        {
            var (t, d) = await Framing.ReadFramedAsync(s, ct);
            var m = Codec.Deserialize<SM_MOVE>(d);
            if (t == PacketType.SM_MOVE) Console.WriteLine($"[C]    👀 P{m.PlayerId} = ({m.X}, {m.Y})");
            else if (t == PacketType.SM_MONSTER) Console.WriteLine($"[C]    🐺 M{m.PlayerId} = ({m.X}, {m.Y})  [zone {m.AuthorityServerId}]");
        }
    }
    catch { }
}
