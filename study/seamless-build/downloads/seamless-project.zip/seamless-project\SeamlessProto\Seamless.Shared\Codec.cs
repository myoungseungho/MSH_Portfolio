// 이 파일 하나가 "구조체 ↔ 바이트" 변환(직렬화/역직렬화)을 '모든 패킷에 대해' 담당한다. 타입마다 새로 안 짜도 된다.

using System.Runtime.CompilerServices;   // Unsafe.SizeOf ("이 구조체가 몇 바이트냐"를 재는 도구)를 쓰려고
using System.Runtime.InteropServices;    // MemoryMarshal ("메모리를 바이트로 들여다보는" 도구)을 쓰려고

namespace Seamless.Shared;   // 서버·클라 공용 주소

// static = 이 클래스는 자기 데이터(상태)가 없는 '순수 함수 모음'이라 객체로 안 만들고 이름으로 바로 부른다: Codec.Serialize(...)
public static class Codec
{
    // <T> = "어떤 타입이 오든 T라고 부르겠다"(제네릭). where T : unmanaged = "단, T는 원시필드(float/int/byte…)로만 된 구조체여야 함".
    //   이 계약만 지키면 CM_MOVE든 SM_MOVE든 뭐든 이 함수 '하나'로 처리된다. → 새 패킷은 struct만 정의하면 직렬화 공짜.
    public static byte[] Serialize<T>(in T value) where T : unmanaged
    {
        var buf = new byte[Unsafe.SizeOf<T>()];   // 이 구조체가 차지하는 바이트 수만큼 빈 바이트배열을 만든다 (CM_MOVE면 8칸)
        // 아래 한 줄: value(구조체)가 메모리에 놓인 모습을 '바이트들로 본 뒤' buf에 그대로 복사한다. = 구조체를 바이트로 '굽는' 순간.
        MemoryMarshal.AsBytes(MemoryMarshal.CreateReadOnlySpan(ref Unsafe.AsRef(in value), 1)).CopyTo(buf);
        return buf;   // 다 구운 바이트배열을 돌려준다
    }

    // 위의 정반대: 바이트배열을 받아 다시 구조체 T로 되살린다(역직렬화).
    public static T Deserialize<T>(ReadOnlySpan<byte> data) where T : unmanaged
    {
        int size = Unsafe.SizeOf<T>();   // T가 원래 몇 바이트여야 하는지
        if (data.Length < size)          // 온 바이트가 그보다 적으면 = 편지가 덜 왔거나 깨진 것 → 잘못 읽으면 위험하니 여기서 막는다
            throw new ArgumentException($"{typeof(T).Name}: 바이트 부족 ({data.Length} < {size})");
        return MemoryMarshal.Read<T>(data);   // 바이트들을 T 구조체 모양으로 '해석'해 되살린다
    }
}
